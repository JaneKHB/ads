import os
import time

import requests

USER_SCRIPTS_PATH = 'test'


def run():
    import config.config as config

    print('\t> run test scripts')

    file_list = [os.path.join(USER_SCRIPTS_PATH, f) for f in os.listdir(USER_SCRIPTS_PATH) if f.endswith('.py')]
    files = list()
    for f in file_list:
        base = os.path.basename(f)
        print('\t> append the script %s' % base)
        files.append(('files', (base, open(f, 'rb'), 'text/plain')))

    client_header = {'client-id': 'writer'}

    # Create url
    url = f"http://{config.CRAS_SERVER_HOST}:{config.CRAS_SERVER_PORT}/api/v1/exec/py"

    # Request a test
    res = requests.post(url,
                        headers=client_header,
                        files=files,
                        data={})

    if res.status_code != 200:
        print('\t> failed to connect Cras-Server(host=%s:%d)' % (config.CRAS_SERVER_HOST, config.CRAS_SERVER_PORT))
        exit(1)

    rid = res.json()['rid']

    # Wait for the processing done
    print('\t> waiting for testing process done')
    while True:
        time.sleep(0.5)

        res = requests.get(f'{url}/{rid}', headers=client_header)
        if res.status_code != 200:
            print('\t> failed to get the test status')
            print('\t> response_code = %d (msg=%s)' % (res.status_code, str(res.json())))
            exit(1)

        resp = res.json()
        if resp['status'] not in ['error', 'success', 'halt', 'nodata']:
            continue

        if resp['status'] in ['error', 'halt']:
            print('\t> testing error occurs. (status=%s)' % resp['status'])
            if resp['error'] is not None and type(resp['error']) == list:
                for e in resp['error']:
                    print('\t> %s' % str(e))
            exit(1)
        elif resp['status'] == 'nodata':
            print('\t> response nodata?')
            exit(1)
        elif resp['status'] == 'success':
            print('\t> testing done')
            break

    # Retrieve the output
    cnt = 0
    while 'output' not in resp or resp['output'] == '':
        time.sleep(1)
        res = requests.get(f'{url}/{rid}', headers=client_header)
        if res.status_code != 200:
            print('\t> failed to get output data')
            exit(1)

        resp = res.json()
        if cnt > 30:
            print('\t> timeout to get output data')
            exit(1)

    print('=================================================')
    print(resp['output'])


if __name__ == '__main__':
    run()
