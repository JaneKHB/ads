#!/bin/bash

python tester.py