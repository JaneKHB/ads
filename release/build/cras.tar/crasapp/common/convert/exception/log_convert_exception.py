class InvalidLogFile(Exception):
    pass


class ParameterError(Exception):
    pass


class DatabaseConnectError(Exception):
    pass
