delete from __schema__.convert_error where 1 = 1;

alter table __schema__.convert_error add rid varchar(50);
alter table __schema__.convert_error add path varchar(1024);
