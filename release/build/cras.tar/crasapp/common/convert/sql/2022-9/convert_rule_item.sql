alter table __schema__.convert_rule_item drop column skip;
alter table __schema__.convert_rule_item drop column col_prefix;
alter table __schema__.convert_rule_item rename column prefix to regex_prefix;