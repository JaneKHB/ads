create table __schema__.column_define
(
    id            serial not null
        constraint column_define_pk
            primary key,
    type          text,
    name          text   not null,
    output_column text   not null,
    data_type     text   not null,
    coef          double precision,
    def_val       text,
    def_type      text,
    unit          text,
    regex_prefix  text,
    regex         text,
    re_group      integer
);

create unique index column_define_id_uindex
    on __schema__.column_define (id);

create unique index column_define_name_uindex
    on __schema__.column_define (name);
