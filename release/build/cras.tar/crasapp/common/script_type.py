from enum import Enum


class ScriptType(Enum):
    PYTHON = '.py'
    SHELL = '.sh'
    UNKNOWN = '.unknown'

    @classmethod
    def conv_script_type(cls, script_type):
        if script_type == 'python':
            ret = cls.PYTHON
        elif script_type == 'shell':
            ret = cls.SHELL
        else:
            ret = cls.UNKNOWN
        return ret
