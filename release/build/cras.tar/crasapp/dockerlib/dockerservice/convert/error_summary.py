import re
import pandas as pd
import numpy as np

import env
from logutil import config_of
from dbconnector import PostgresConnector


class ErrorSummary:

    monitor_db = None  # Config to connect log-monitor database.
    base_connect = None  # Connector for base information like error_category.

    ERR_DB_COL = ['equipment_id', 'log_date', 'error_no', 'error_name', 'error_rank', 'error_count', 'elapsed', 'error_category']
    DATE_PTN = 'Start time:(\d{4}/\d{2}/\d{2})'

    A_RANK_PTN1 = '【Error occurrence】.*・A rank\n(.*)・B rank'
    A_RANK_PTN2 = '【Error occurrence】.*・A rank\n(.*)・B/D rank'
    B_RANK_PTN1 = '・B rank\n(.*)・C rank'
    B_RANK_PTN2 = '・B/D rank\n(.*)・C rank'
    C_RANK_PTN1 = '・C rank\n(.*)・D rank'
    C_RANK_PTN2 = '・C rank\n(.*)$'
    C_RANK_PTN3 = '・C rank\n(.*)【'
    D_RANK_PTN1 = '・D rank\n(.*)【'
    D_RANK_PTN2 = '・D rank\n(.*)$'

    def __init__(self, monitor_db):
        self.monitor_db = monitor_db
        with PostgresConnector(config_of(env.LOG_MONITOR_DB)) as (con, cur):
            self.category_df = pd.read_sql("select * from cnvbase.error_category", con)

    def summary(self, file, equipment_id):
        try:
            data = self.read_file(file)
            out_df = pd.DataFrame(columns=self.ERR_DB_COL)
            match = re.search(self.DATE_PTN, data)
            if match:
                date = match.group(1)
                err_list = self.create_error_list(data)
                db_err = self.create_err_df(equipment_id, date, err_list)
                out_df = out_df.append(db_err, ignore_index=True)
            return out_df

        except Exception as ex:
            raise RuntimeError(f'summary failed. {ex}')

    def read_file(self, file):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as ex:
            with open(file, 'r', encoding='shift_jis') as f:
                return f.read()

    def create_error_list(self, logdata):
        """
        ログからランク毎のエラーリストを作成する
        :param logdata: ログ
        :return: ランク毎エラーリスト　頭からA->B->C->D となる
        """
        err_list = []
        arank = re.search(self.A_RANK_PTN1, logdata, flags=re.DOTALL)
        brank = re.search(self.B_RANK_PTN1, logdata, flags=re.DOTALL)
        crank = re.search(self.C_RANK_PTN1, logdata, flags=re.DOTALL)
        drank = re.search(self.D_RANK_PTN1, logdata, flags=re.DOTALL)

        if arank is None:
            arank = re.search(self.A_RANK_PTN2, logdata, flags=re.DOTALL)

        if brank is None:
            brank = re.search(self.B_RANK_PTN2, logdata, flags=re.DOTALL)

        if crank is None:
            crank = re.search(self.C_RANK_PTN2, logdata, flags=re.DOTALL)

        if crank is None:
            crank = re.search(self.C_RANK_PTN3, logdata, flags=re.DOTALL)

        if drank is None:
            drank = re.search(self.D_RANK_PTN2, logdata, flags=re.DOTALL)

        if arank:
            alist = arank.group(1).split('\n')
            err_list.append(alist)
        else:
            err_list.append(list())

        if brank:
            blist = brank.group(1).split('\n')
            err_list.append(blist)
        else:
            err_list.append(list())

        if crank:
            clist = crank.group(1).split('\n')
            err_list.append(clist)
        else:
            err_list.append(list())

        if drank:
            dlist = drank.group(1).split('\n')
            err_list.append(dlist)
        else:
            err_list.append(list())

        return err_list

    def create_err_df(self, machine, date, ranked_err):
        """
        エラーDB登録・ファイル出力用のDataFrameを作成する
        :param machine: 装置
        :param date: エラーの日付
        :param ranked_err: ランク毎に分けられたエラー
        :return: ファイル出力用データ、DB出力用データ
        """

        rank = 0

        # errlog_list = []
        db_list = []
        for err_list in ranked_err:  # エラーリストからランク毎のエラー一覧を取得
            if len(err_list) != 0:
                for err in err_list:
                    err = err.strip()
                    if len(err) != 0:
                        try:
                            str_rank = self.convert_rank(rank)  # エラーランクを文字に変換
                            err_elem = self.convert_errlog(err, str_rank)
                            err_no = err_elem[0].upper()
                            category = self.get_error_category(err_no)
                        except Exception as ex:
                            print(f"create_err_df| converting error msg={ex}")
                        try:
                            equipment_id = machine
                            err_val = [equipment_id, date]
                            err_val.extend(err_elem)
                            err_val.append(category)
                            db_list.append(err_val)
                        except:
                            print(f"create_err_df| appending error machine={machine}")

            rank += 1
        dbdf = pd.DataFrame(db_list, columns=self.ERR_DB_COL)
        return dbdf

    def convert_rank(self, rank):
        """
        エラーランク変換
        :param rank: エラーランクの数字
        :return: エラーランク文字
        """
        if rank == 0:
            return 'A'
        elif rank == 1:
            return 'B'
        elif rank == 3:
            return 'D'
        else:
            return 'C'

    def convert_errlog(self, error_log, err_rank):
        """
        稼働率データからエラーサマリを作成する
        :param error_log:
        :param err_rank:
        :return:
        """
        err_no = error_log.split('/', 1)[0].strip().upper()
        err_str = error_log.split('/', 1)[1].split(',')
        name = err_str[0].strip()
        count = int(err_str[1].replace('[time]', ''))
        elapsed = np.nan
        if err_rank != 'C':
            try:
                h, m, s = err_str[2].split(':')

                delta = int(h) * 10000 + int(m) * 100 + int(s)
                if delta >= 240000:
                    elapsed = np.nan
                else:
                    elapsed = err_str[2].strip()
            except:
                elapsed = np.nan

        return [err_no, name, err_rank, count, elapsed]

    def get_error_category(self, error_no):
        """
        Error Noからカテゴリを取得する
        :param error_no:
        :param db_if:
        :return:
        """
        unit = error_no[0]  # エラーユニットNo(CONS/MAIN/SCAN/PERL)
        cat = error_no[2]  # エラー発生サブユニット(発生箇所)

        ret = self.category_df[(self.category_df['unit_no'] == unit) & (self.category_df['category_no'] == cat)]
        if len(ret) == 0:
            return 'Other'

        return ret.iloc[0]['category_name']
