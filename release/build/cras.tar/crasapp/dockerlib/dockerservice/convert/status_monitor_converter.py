import os

import pandas as pd

import env
import extlogger as lo
from convert.util import insert_df
from logutil import config_of
from dbconnector import PostgresConnector


def convert_status_monitor(file, equipment_id):

    lo.gger.info(f"start convert(status_monitor) {os.path.basename(file)}")

    with PostgresConnector({**env.CONFIG_CONVERT_DB}) as (con, cur):
        event_df = pd.read_sql("select * from cras_db.status_monitor_items", con)
    if event_df is None or len(event_df) == 0:
        return None

    try:
        status_df = pd.read_csv(file, encoding='shift_jis')
    except:
        status_df = pd.read_csv(file, encoding='utf_8')

    # headerなしのファイルは対象外とする
    if len(status_df) == 0 or 'Event' not in status_df.columns.values:
        return None

    status_df['Event'] = status_df['Event'].str.rstrip()

    ret_list = list()

    def _apply(elem):
        item = elem['name']
        start = elem['start_state']
        end = elem['end_state']
        tmd_df = status_df.query('Event == @start or Event == @end')
        tmd_df['Date Time'] = tmd_df['Date Time'] + '000'
        tmd_df['Date Time'] = pd.to_datetime(tmd_df['Date Time'], format='%Y/%m/%d %H:%M:%S:%f')
        ret = check_event(item, start, end, tmd_df)
        ret_list.extend(ret)

    event_df.apply(_apply, axis=1)

    output_df = pd.DataFrame(ret_list)
    output_df['equipment_id'] = equipment_id
    output_df = output_df.sort_values('start_time')

    output_df = output_df.reindex(
        columns=['equipment_id', 'event', 'start_time', 'end_time', 'elapsed', 'device', 'process', 'lot_id',
                 'plate_id', 'plate_no'])

    _db = env.CONFIG_CONVERT_DB
    schema = _db['schema']

    lo.gger.info('insert dataframe into status_monitor_analysis')
    insert_df(_db, schema, 'status_monitor_analysis', output_df, logger=lo.gger)
    return output_df


def check_event(event, start, end, input_data):
    is_started = False
    start_time = None

    output_list = list()

    for _, elem in input_data.iterrows():
        if elem.Event == start:
            start_time = elem['Date Time']
            is_started = True

        elif is_started is True and elem.Event == end:
            output_data = dict()
            output_data['event'] = event

            output_data['start_time'] = start_time
            output_data['end_time'] = elem['Date Time']

            # 時間差は秒単位でfloat型に変換する
            elapsed = abs(elem['Date Time'] - start_time)
            output_data['elapsed'] = elapsed.total_seconds()

            output_data['device'] = str(elem['Device']).rstrip()
            output_data['process'] = str(elem['Process']).rstrip()
            output_data['lot_id'] = str(elem['LotID']).rstrip()
            output_data['plate_id'] = str(elem['GlassID']).rstrip()

            check_nunList = ['device', 'process', 'lot_id', 'plate_id']
            # nanは空欄に変換する
            for check_num in check_nunList:
                if output_data[check_num] == 'nan':
                    output_data[check_num] = ''

            output_data['plate_no'] = elem['Plate']
            output_list.append(output_data)
            is_started = False
    return output_list