import os
import pandas as pd
from datetime import datetime, timedelta

import env
import extlogger as lo
from logutil import config_of
from dbconnector import ConvertDatabaseConnector


class ErrorSummary:

    def __init__(self, user, equipment_df):
        self.user = user
        self.equipment_df = equipment_df
        c = env.CONFIG_CONVERT_DB
        if 'schema' not in c:
            raise RuntimeError('CONVERT_DB has not configured yet')
        self.schema = c['schema']

    def get_days(self, lastday):
        """
        昨日の日付と引数で指定された日付だけさかのぼった日の日付を取得する
        :param lastday: さかのぼる日付
        :return: 昨日の日付、さかのぼった日付
        """
        now = datetime.now()
        delta_day = now
        to_day = ('{0:04d}/{1:02d}/{2:02d}'.format(delta_day.year, delta_day.month, delta_day.day))
        delta_day = now + timedelta(days=-lastday)
        from_day = ('{0:04d}/{1:02d}/{2:02d}'.format(delta_day.year, delta_day.month, delta_day.day))
        return from_day, to_day

    def lastdayslist(self, days):
        """
        昨日の日付と引数で指定された日付だけさかのぼった日の間の日付のリストを取得する
        :param days: 取得する日付の期間
        :return: 日付のリスト
        """
        now = datetime.now()
        days_list = []
        for day in range(-days, 0):
            delta_day = now + timedelta(days=day)

            days_list.append('{0:04d}/{1:02d}/{2:02d}'.format(delta_day.year, delta_day.month, delta_day.day))
        return days_list

    def delta2str(self, t_delta):
        """
        time deltaを文字列に変換
        :param t_delta: デルタ時間
        :return: 変換後の文字列
        """
        sec_ = t_delta.seconds
        hour_ = int(int(sec_) / 3600)
        min_ = int((int(sec_) - hour_ * 3600) / 60)
        sec_ = int(sec_ - hour_ * 3600 - min_ * 60)
        return '{0:02d}:{1:02d}:{2:02d}'.format(hour_, min_, sec_)

    def output_excel(self, output_file, input_df, eqp_list):
        """
        データフレームからexcelファイルを作成する
        :param output_file:
        :param input_df:
        :return:
        """
        lo.gger.info('output_excel| output=%s equipments=%d' % (os.path.basename(output_file), len(eqp_list)))
        writer = pd.ExcelWriter(output_file)
        #    tool_list = input_df['equipment_name'].unique()
        for tool in eqp_list:
            tool_summary = input_df[input_df['equipment_id'] == tool]
            del tool_summary['equipment_id']
            tool_summary = tool_summary.sort_values(['ErrRank', 'TotalCount', 'TotalTime', 'ErrNo'],
                                                    ascending=[True, False, False, True])
            tool_summary['ErrNo'] = tool_summary['ErrNo'].str.upper()
            tool_summary = tool_summary.drop_duplicates(['ErrNo'])
            equip_info = self.equipment_df[self.equipment_df['equipment_id'] == tool]
            namelist = equip_info['equipment_name'].values[0].split('_')
            # tool_name = namelist[len(namelist) - 1]
            tool_name = namelist[len(namelist) - 2] + '_' + namelist[len(namelist) - 1]
            tool_summary.to_excel(writer, sheet_name=tool_name, index=False)
            lo.gger.info('output_excel| %d records have been written in equipment %s' % (len(tool_summary), tool))
        writer.save()

    def create_summary_df(self, output_file, time_span, fab):
        """
        指定された期間のエラーサマリーデータを作成しExcelとして出力
        :param dbif: DBとのIFオブジェクト
        :param output_file: 出力するファイル名
        :param time_span: 取得するエラーの期間(過去何日か)
        :return:
        """

        # サマリーを作る期間を設定する
        from_day, to_day = self.get_days(time_span)
        timespan_str = "log_date >='{}' AND log_date < '{}' ".format(from_day, to_day)
        days = self.lastdayslist(time_span)

        df_column = ['equipment_id', 'error_rank', 'error_no', 'error_name', 'count', 'elapsed']
        with ConvertDatabaseConnector() as (con, cur):
            try:
                outdf = pd.read_sql("select \
                    equipment_id, error_no, error_name,error_rank, sum(elapsed) AS elapsed, sum(error_count) \
                    AS count from %s.error_summary \
                    where %s group by equipment_id, error_no, error_name,error_rank"
                                    % (self.schema, timespan_str), con)
            except Exception:
                outdf = pd.DataFrame(index=range(0, 0), columns=df_column)
            else:
                outdf = outdf.loc[:, df_column]

            # 一日毎の集計列を付加していく
            for day in days:
                logdate_str = "log_date ='{}'".format(day)
                # 一日毎のエラー数を取得する。エラー毎のカウントもDB側で処理する
                # oneday = dbif.fetch_all(table=f'{self.schema}.error_summary',
                #                         args={'select': 'equipment_name, error_no, sum(error_count) AS day_col',
                #                               'where': '{}'.format(logdate_str)+' group by error_no, equipment_name'})
                try:
                    oneday = pd.read_sql("select equipment_id, error_no, sum(error_count) AS day_col \
                        from %s.error_summary where %s group by error_no, equipment_id" % (self.schema, logdate_str), con)
                except Exception:
                    oneday = pd.DataFrame(index=range(0, 0), columns=['equipment_id', 'error_no', 'day_col'])

                # 取得したデータと、指定期間のサマリーデータを結合する
                outdf = pd.merge(outdf, oneday, on=['equipment_id', 'error_no'], how='left')
                # NaNの部分は0にする
                outdf = outdf.fillna('0')

                outdf['day_col'] = outdf['day_col'].astype(int)
                outdf = outdf.rename(columns={'day_col': day})

        # 欠損値を補間し経過時間を文字列にする
        outdf = outdf.fillna('0')
        outdf['elapsed'] = outdf['elapsed'].map(self.delta2str).astype(dtype=str)

        # 出力するテーブルのカラム名を変換する
        colname = {'error_no': 'ErrNo',
                   'error_name': 'ErrName',
                   'error_rank': 'ErrRank',
                   'elapsed': 'TotalTime',
                   'count': 'TotalCount'}
        outdf = outdf.rename(columns=colname)

        # 装置のリストを作成
        """
        if fab == 'CZ' or fab == 'T2' or fab == 'T4':  # equipement DBに小文字になっていて必要な例外処理
            sqlstr = "SELECT equipment_name FROM equipments WHERE fab_name='{}' ORDER BY equipment_name".format(fab.lower())
        elif fab == 'WUHAN':
            sqlstr = "SELECT equipment_name FROM equipments WHERE fab_name='{}' ORDER BY equipment_name".format('WH')
        else:
        """

        special_fab_map = {
            'CQ': 'H1',
            'CZ': 'H2'
        }

        if fab in special_fab_map.keys():
            line = special_fab_map[fab]
        else:
            line = fab

        eqp_list = self.equipment_df[self.equipment_df['fab_name'] == line]['equipment_id'].tolist()

        if len(eqp_list) == 0:
            return None
        self.output_excel(output_file, outdf, eqp_list)
        return outdf
