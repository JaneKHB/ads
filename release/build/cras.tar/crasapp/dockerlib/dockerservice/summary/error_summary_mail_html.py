"""
File: version_info_mail_html.py
Date:
Author:
Description:Version Info reportを作成
Rev:
"""
import sys
import os

import pandas as pd
from jinja2 import Template

import env
import extlogger as lo
from dbconnector import ConvertDatabaseConnector
from logutil import config_of

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(os.path.dirname(__file__))), 'common'))

sys.path.append(os.path.dirname(os.getcwd()))
sys.path.append(os.path.abspath(os.getcwd()))


BASE_HTML = '''
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>Error Summary Top10 Report</title>
</head>
<style type="text/css">
body {
    color:#000000;
    background-color:#FCECE8;
    margin:10px 10px 10px 10px;
    padding:0px;
    font:normal normal normal 11pt/14pt 'Arial';
}
.gs_none {
    border-width:0px;
}
.gs_header {
    border-width:0px;
    background-color:#FCECE8;
    padding: 20px 20px 20px 20px;
    font:normal normal normal 14pt/14pt 'Arial';
}
.gs_tail {
    border-width:0px;
    padding: 20px 20px 20px 20px;
    font:normal normal normal 11pt/14pt 'Arial';
}
table {
    border:0px;
    border-collapse:collapse;
    font:normal normal normal 11pt/13pt 'Arial';
    table-layout:fixed;
    word-break:break-all;
}
th {
    border:0px;
    padding: 1px 5px 1px 5px;
    font:normal normal bold 11pt/13pt 'Arial';
    text-align:center;
    vertical-align:middle;
    background-color:#F8D7CD;
}
td {
    border:0px;
    padding: 1px 5px 1px 5px;
}
.gs_bar1 {
    border-width:0px;
    color:#FFFFFF;
    background-color:#ED7D31;
    font:normal normal bold 14pt/14pt 'Arial';
    padding:3px 3px;
}
.gs_bar2 {
    border-width:0px;
    color:#FFFFFF;
    background-color:#ED7D31;
    text-align:right;
}
.gs_barmark {
    color:#FFD700;
    font:normal normal bold 14pt/14pt 'Arial';
}
.gs_body {
    border-width:0px 1px 0px 1px;
    padding:10px;
    background-color:#FFFFFF;
    text-align:left;
    vertical-align:top;
}
</style>
<body>
    {{ table_data }}
</body>
</html>
'''


def create_html(table_list, output):
    output_table_html = '<br><br>'.join(table_list)

    # HTML Data Create
    data = {'table_data': output_table_html}
    template = Template(BASE_HTML)
    output_html = template.render(data)

    with open(output, "w") as f:
        # すべての内容を書き込む
        f.write(output_html)

    return output_html


def create_html_body(error_summary_df, report_header, report_tail, user_name, fab_name, df_equipments):
    """
    Production dataからメール配信用HTMLの作成
    :param error_summary_df:
    :return HTML Data
    """

    table_html = '''
    <table class="gs_none" style="width:{{ html_width }}">
    <tr>
    <td class="gs_body" colspan="100" style="border:1px solid #EA5234;">
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_header" colspan="96" style="border:5px solid #EA5234;">{{ report_header }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>

        <h2>[{{ latest_date_colname }}] : Error Ranking Top10</h2>
        &nbsp;

        {% for equipment_name, target_error_summary_top in render_data.items(): %}
        <table class="gs_none" style="width:100%;">
            <tr>
                <td class="gs_bar1" colspan="96"><font class="gs_barmark">&#X25C6; </font> {{ equipment_name }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
            <tr>
                <td class="gs_none" colspan="96">
                    <table class="gs_none" style="width:100%;">
                        {% if target_error_summary_top == [] %}
                            <tbody>
                                <h2 style="text-align:center">{{ latest_date_colname }} => There were no errors.(Excluding C rank)</h2>
                            </tbody>
                        {% else %}
                            <thead>
                                <tr>
                                    <th scope="col" style="border:1px solid #EA5234; width:50px;">ErrRank</th>
                                    <th scope="col" style="border:1px solid #EA5234; width:50px;">ErrNo</th>
                                    <th scope="col" style="border:1px solid #EA5234; width:400px;">ErrName</th>
                                    <th scope="col" style="border:1px solid #EA5234; width:75px;">Elapsed</th>
                                    <th scope="col" style="border:1px solid #EA5234; width:75px;">{{ latest_date_colname }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for target_error_summary in target_error_summary_top: %}
                                    <tr>
                                        <td style="text-align:center; border:1px solid #EA5234;">{{ target_error_summary['ErrRank'] }}</td>
                                        <td style="text-align:center; border:1px solid #EA5234;">{{ target_error_summary['ErrNo'] }}</td>
                                        <td style="text-align:center; border:1px solid #EA5234;">{{ target_error_summary['ErrName'] }}</td>
                                        <td style="text-align:center; border:1px solid #EA5234;">{{ target_error_summary['Elapsed'] }}</td>
                                        <td style="text-align:center; border:1px solid #EA5234;">{{ target_error_summary[latest_date_colname] }}</td>
                                    </tr>
                                {% endfor %}
                            </tbody>
                        {% endif %}
                    </table>
                </td>
            </tr>
            <tr><td class="gs_none" colspan="96">&nbsp;<br>&nbsp;</td></tr>
        </table>
        {% endfor %}
        <table class="gs_none" style="width:100%;">
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr>
                <td class="gs_tail" colspan="96">{{ report_tail }}</td>
            </tr>
            <tr><td class="gs_none" colspan="96"><hr></td></tr>
            <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
        </table>
    </td>
    </tr>
    <tr>
    <td class="gs_none" colspan="100" style="text-align:right;">Canon Remote Alarm System Version 2.0</td>
    </tr>
    </table>
    '''

    # DBからデータ取得用のインターフェースを作成
    # dbif = database_if.DatabaseIF(connection_config)
    # df_equipments = dbif.get_data('equipments')
    df_equipments = df_equipments[df_equipments['fab_name'] == fab_name]
    df_equipments = df_equipments.sort_values('equipment_name')

    render_data = dict()
    # 最新の一日のみをランキング化するので、日付用にcolumnの一番最後のみを抽出する
    latest_date_colname = error_summary_df.columns.values.tolist()[len(error_summary_df.columns.values.tolist()) - 1]

    # Cランクエラーは対象外なので除外する
    error_summary_df = error_summary_df[error_summary_df['ErrRank'] != 'C']

    # 装置単位で処理を回す
    all_equipment_idList = df_equipments['equipment_id'].values.tolist()
    errorsummary_equipment_idList = sorted(list(set(error_summary_df['equipment_id'].values.tolist())))
    for equipment_id in all_equipment_idList:
        equip_info = df_equipments[df_equipments['equipment_id'] == equipment_id]
        user_fab_equipment_name = equip_info['equipment_name'].values[0]
        if len(user_fab_equipment_name.split('_')) < 3:
            lo.gger.warn('equipment_name Error (%s)' % user_fab_equipment_name)
            continue

        target_user = user_fab_equipment_name.split('_')[0]
        target_fab = user_fab_equipment_name.split('_')[1]
        # CSOT-t1/t2用分岐処理、自fabでない場合はスキップする
        if user_name == 'CSOT' and (fab_name == 't1' or fab_name == 't2') and (target_user != user_name or target_fab != fab_name):
            lo.gger.warn(f'This userfab is not target => target_user:{target_user} user_name:{user_name} target_fab:{target_fab} fab_name:{fab_name}')
            continue

        target_equipment = user_fab_equipment_name.split('_')[2]
        if len(user_fab_equipment_name.split('_')) >= 4:
            target_equipment = target_equipment + '_' + user_fab_equipment_name.split('_')[3]

        # error_summaryにその装置のデータが存在しない場合は、空のリストを追加して後の処理をスキップする
        if equipment_id not in errorsummary_equipment_idList:
            render_data[target_equipment] = []
            continue

        # DBから特定装置の一日分のerror_summaryを取得
        target_log_date = latest_date_colname.replace('/', '-')
        sql = f"equipment_id='{equipment_id}' AND log_date='{target_log_date}' AND error_rank!='C'"
        with ConvertDatabaseConnector() as (con, cur):
            schema = env.CONFIG_CONVERT_DB['schema']
            target_error_summary_df = pd.read_sql(f"select * from {schema}.error_summary where {sql}", con)
            # target_error_summary_df = dbif.get_data_with_col('error_summary', sql, '*')
        # 名前をExcelのものと統一するために変更
        target_error_summary_df = target_error_summary_df.rename(columns={'elapsed': 'Elapsed', 'error_no': 'ErrNo', 'error_name': 'ErrName', 'error_rank': 'ErrRank', 'error_count': latest_date_colname})
        # 最新日のランキングでソート
        target_error_summary_df = target_error_summary_df.sort_values(['Elapsed', 'ErrRank', 'ErrNo'], ascending=[False, True, True])
        # 必要列のみ抽出
        target_error_summary_df = target_error_summary_df.loc[:, ['ErrRank', 'ErrNo', 'ErrName', 'Elapsed', latest_date_colname]]
        # 0を削除
        target_error_summary_df = target_error_summary_df[target_error_summary_df[latest_date_colname] > 0]
        target_error_summary_df.reset_index(inplace=True, drop=True)

        if len(target_error_summary_df) == 0:
            render_data[target_equipment] = []
            lo.gger.info(f'{target_equipment} => There were no errors in this device.')
            continue

        latest_date_valueList = target_error_summary_df[latest_date_colname].values.tolist()
        target_error_summary_top = target_error_summary_df.copy()
        for i in range(10, len(latest_date_valueList)):
            if latest_date_valueList[i - 1] != latest_date_valueList[i]:
                target_error_summary_top = target_error_summary_df[:i]
                break

        # 装置単位で辞書にランキングのリストを登録
        render_data[target_equipment] = target_error_summary_top.to_dict(orient='records')

    if len(render_data) == 0:
        lo.gger.debug('[debug] len(rander_data) == 0')
        return ''

    # HTMLの幅を決める
    width = 980
    html_width = '{}px'.format(width)

    # Table Data Create
    table_data = {'render_data': render_data, 'latest_date_colname': latest_date_colname, 'report_header': report_header, 'report_tail': report_tail, 'html_width': html_width}
    table_template = Template(table_html)
    output_table_html = table_template.render(table_data)
    return output_table_html
