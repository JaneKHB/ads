BASE_HTML = '''
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title>CRAS Report</title>
</head>
<style type="text/css">
body {
  color:#000000;
  background-color:#F0F8FF;
  margin:10px 10px 10px 10px;
  padding:0px;
  font:normal normal normal 11pt/14pt 'Arial';
}
.gs_none {
  border-width:0px;
}
.gs_header {
  border-width:0px;
  background-color:#F0F8FF;
  padding: 20px 20px 20px 20px;
  font:normal normal normal 14pt/14pt 'Arial';
}
.gs_tail {
  border-width:0px;
  padding: 20px 20px 20px 20px;
  font:normal normal normal 11pt/14pt 'Arial';
}
table {
  border:0px;
  border-collapse:collapse;
  font:normal normal normal 11pt/13pt 'Arial';
}
th {
  border:0px;
  padding: 1px 5px 1px 5px;
  font:normal normal bold 11pt/13pt 'Arial';
  text-align:center;
  vertical-align:middle;
  background-color:#7adbf3;
}
td {
  border:0px;
  padding: 1px 5px 1px 5px;
}
.gs_bar1 {
  border-width:0px;
  color:#FFFFFF;
  background-color:#4090E0;
  font:normal normal bold 14pt/14pt 'Arial';
  padding:3px 3px;
}
.gs_bar2 {
  border-width:0px;
  color:#FFFFFF;
  background-color:#4090E0;
  text-align:right;
}
.gs_barmark {
  color:#FFD700;
  font:normal normal bold 14pt/14pt 'Arial';
}
.gs_body {
  border-width:0px 1px 0px 1px;
  padding:10px;
  background-color:#FFFFFF;
  text-align:left;
  vertical-align:top;
}
</style>
<body>
<table class="gs_none" style="width:980px;">
    <tr>
        <td class="gs_body" colspan="100" style="border:1px solid #02439f;">
    {{ table_data }}
        </td>
    </tr>
</table>        
</body>
</html>
'''
