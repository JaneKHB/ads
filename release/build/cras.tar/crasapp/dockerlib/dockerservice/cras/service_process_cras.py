import os
import datetime
import subprocess

import pandas as pd
from psycopg2 import extras

import env
import extlogger as lo
from logutil import config_of
from dbconnector import ConvertDatabaseConnector
from dbconnector import PostgresConnector
from dockerservice.cras.exception import CrasException
from dockerservice.cras.service_create_data_cras import CRASDataCreate
from dockerservice.cras.service_production_report_cras import CCrasProductonReport
from dockerservice.cras.service_report_cras import CRASReport
from dockerservice.cras.service_judge_data_cras import CCrasJudge, create_abnormal_report_html, \
    create_abnormal_report_html_body
from stepexception import StepError, StepNoData


class ProcessCras:
    """
    CRAS Process Class
    """

    def __init__(self, user, equipment_df, output_path, total_fab_list, period, password, rule_list):
        self.user = user
        self.equipment_df = equipment_df
        c = env.CONFIG_CONVERT_DB
        if 'schema' not in c:
            raise RuntimeError('CONVERT_DB has not configured yet')
        self.schema = c['schema']
        self.fab_list = list()
        self.skip_fab_list = list()
        self.cras_info = dict()
        self.rule_list = rule_list

        self.logger = lo.gger

        with PostgresConnector(config_of(env.LOG_MONITOR_DB)) as (con, cur):
            for _fab in total_fab_list:
                sql = f"select * from cras.cras_data where lower(user_name) = '{user.lower()}'" \
                      f" and lower(fab_name) = '{_fab.lower()}'"
                _info = pd.read_sql(sql, con)
                if _info is None:
                    self.logger.warn(f'failed to get cras-data for {_fab}')
                if len(_info) == 0:
                    self.logger.warn(f'empty rule (user={user}, fab={_fab})')
                    self.skip_fab_list.append(_fab)
                    continue

                self.fab_list.append(_fab)
                self.cras_info[_fab] = _info
                self.logger.info(f'{len(_info)} rules exist (user={user}, fab={_fab})')

        if len(self.cras_info) == 0:
            raise StepNoData('no rule data')

        self.output_path = output_path
        self.days = period
        self.judge_period = 1

        self.input_file = dict()
        self.output = dict()
        self.cras_pdf_name = dict()
        self.cras_abnormal_data_table_name = dict()
        for _fab in self.fab_list:
            self.output[_fab] = os.path.join(self.output_path, f'JudgeResult_{self.user}-{_fab}.xlsx')
            self.cras_pdf_name[_fab] = os.path.join(self.output_path, f'CRAS_REPORT-{_fab}.pdf')
            self.cras_abnormal_data_table_name[_fab] = 'cras.cras_abnormal_data'
        self.mail_body_output = os.path.join(self.output_path, f'MESSAGE.html')

        self.zip_password = password

        self.production_report = dict()

    def load_execute_info(self):
        """
        data setting
        """
        self.judge_period = self.days

        if self.judge_period <= 0:
            self.judge_period = 1
        elif self.judge_period > 3:
            self.judge_period = 3

        self.logger.info(f"load_execute_info| judge_period={self.judge_period}")

    def execute_cras(self):
        self.load_execute_info()

        # 1. Create CRAS Data
        for _fab in self.fab_list:
            try:
                self.logger.info(f'execute_cras| Create CRAS Data Start ({_fab})')
                self.create_cras_data(_fab)
            except Exception as e:
                self.logger.warn(f'exception occurs from creating cras data(msg={e})')
                e.args = ('execute_cras_1(fab=%s)' % _fab,) + e.args
                raise
            finally:
                self.logger.info(f'execute_cras| Create CRAS Data End ({_fab})')

        # 2. Production Report Create and mail
        for _fab in self.fab_list:
            try:
                self.logger.info(f'execute_cras| send_production_report Start ({_fab})')
                self.send_production_report(_fab)
            except Exception as e:
                self.logger.warn(f'exception occurs from writing report(msg={e})')
                e.args = ('execute_cras_2(fab=%s)' % _fab,) + e.args
            finally:
                self.logger.info(f'execute_cras| send_production_report End ({_fab})')

        # 3. Abnormal Data Report Create and mail
        try:
            self.logger.info(f'execute_cras| CRAS Start')
            self.send_abnormal_report()  # <- テスト後、実際のSetting DBに変更が必要
        except Exception as e:
            self.logger.warn(f'exception occurs from abnormal report(msg={e})')
            e.args = ('execute_cras_3',) + e.args
        finally:
            self.logger.info(f'execute_cras| CRAS End')


        return True

    def create_cras_data(self, fab_name):
        createobj = CRASDataCreate(self.equipment_df,
                                   self.user,
                                   fab_name)

        equipments_list = createobj.get_eqp_list()
        if len(equipments_list) == 0:
            raise StepError("failed to create cras data. no equipments")

        # file_name = 'cras.xlsx'
        file_name = f'CRASDATA_{self.user}-{fab_name}.xlsx'

        cras_info = self.cras_info[fab_name]

        # CRAS 判定に必要な値のみ取得する場合
        # cras_info = cras_info[cras_info['enable'] == True]

        # データをDBから取得
        result = createobj.collect_data_by_day(cras_info, days=self.days)
        if result is None:
            raise StepNoData(f"failed to collect data by day (fab={fab_name})")

        # file Save
        output = os.path.join(self.output_path, file_name)

        if not os.path.isdir(self.output_path):
            os.makedirs(self.output_path)

        self.output_to_excel_by_tool(result, output, equipments_list)
        self.input_file[fab_name] = output
        self.logger.info(f'create_cras_data| cras data ready for {fab_name} in {output}')

    def output_to_excel_by_tool(self, df, output, equipments):
        """
        CRAS用のファイルを出力する
        :param df:
        :param output:
        :return:
        """
        tools = df['ToolID'].drop_duplicates()
        # シートを装置毎に分割してExcelにする
        with pd.ExcelWriter(output) as writer:
            for tool in tools:
                if tool in equipments:
                    equipments.remove(tool)
                    book = df[df['ToolID'] == tool]
                    book = book.sort_values(by=['Day'], ascending=[False]).drop_duplicates('Day', keep='last')
                    book['Day'] = book['Day'].astype(str)
                    book['Day'] = book['Day'].str.replace('-', '/')
                    book.to_excel(writer, sheet_name=tool, index=False)
            for eqp in equipments:
                book = pd.DataFrame(columns=df.columns)
                book.to_excel(writer, sheet_name=eqp, index=False)
            writer.save()

    def send_production_report(self, fab_name):
        """
        Production Report作成及びメール配信
        """
        production = CCrasProductonReport(self.user, fab_name, self.equipment_df)
        production_report = production.create_production_report_html('report header', 'report tail', fab_name)

        self.production_report[fab_name] = production_report
        self.logger.info(f'send_production_report| production report for {fab_name} ready')

    def get_state_count(self, user, fab, toolid, cras_id, date):
        """
        """
        self.logger.info('get_state_count| user=%s fab=%s toolid=%s' % (user, fab, toolid))
        date = datetime.datetime.strptime(date, '%Y/%m/%d').date()

        with PostgresConnector(config_of(env.LOG_MONITOR_DB)) as (con, cur):
            where_str = "lower(user_name) = '{0}' AND lower(fab_name) = '{1}' AND toolid = '{2}' \
            AND cras_id = '{3}' AND date <= '{4}'".format(user.lower(), fab.lower(), toolid, cras_id, date)
            query = 'select * from %s where %s' % (self.cras_abnormal_data_table_name[fab], where_str)
            err_data = pd.read_sql(query, con)
            err_data = err_data.sort_values(['date'], ascending=False)

            count = 0

            for _, elem in err_data.iterrows():
                if elem['date'] == date:
                    date = date - datetime.timedelta(days=1)
                    count = count + 1
                else:
                    break

            return count

    def insert_from_df(self, table, df):
        """
        指定されたテーブルにデータフレームをInsertする
        :param table_name: テーブル名
        :param insert_df: insertするデータフレーム
        :return:
        """
        for _, elem in df.iterrows():
            values = []
            key_str = ''
            is_first_elem = True
            elem = elem.dropna()
            for key, value in elem.items():
                values.append(value)
                if not is_first_elem:
                    key_str += ','
                is_first_elem = False
                key_str += key

            sql_str = "INSERT INTO " + table + " (" + key_str + ") VALUES %s"
            value_tuple = tuple(values)
            value_list = list()
            value_list.append(value_tuple)
            with PostgresConnector(config_of(env.LOG_MONITOR_DB)) as (conn, cur):
                try:
                    extras.execute_values(cur, sql_str, value_list)
                except Exception as errmsg:
                    errmsg.args = ('insert_from_df',) + errmsg.args
                    raise

    def send_abnormal_report(self):
        """
        CRASデータ作成～Mail配信
        :param parser:
        :return:
        """
        last_date = datetime.date.today() - datetime.timedelta(days=1)  # 昨日まで
        start_date = datetime.date.today() - datetime.timedelta(days=self.judge_period)  # 何日前から

        self.logger.info('send_abnormal_report| last=%s start=%s' % (last_date, start_date))

        # Database Setting
        # convert_connect = DAOBaseClass(**self.convert_db)
        # monitor_connect = DAOBaseClass(**self.monitor_db)
        # monitor_con, monitor_cur = PostgresConnector(config_of(env.LOG_MONITOR_DB))
        abnormal_report = ''

        # CRAS判定Data作成
        for _fab in self.fab_list:
            self.logger.info('send_abnormal_report| create data for %s' % _fab)
            if _fab not in self.input_file:
                self.logger.warn(f"send_abnormal_report| no input file for {_fab}")
                continue

            cras_judge = CCrasJudge(self.input_file[_fab], self.user, _fab, self.rule_list)
            result_df = cras_judge.create_cras_judge_data(last_date, start_date)
            if result_df is None or len(result_df) == 0:
                self.logger.warn(f"send_abnormal_report| empty result_df for {_fab}")
                continue

            self.logger.info('send_abnormal_report| result_df=%d' % len(result_df))

            result_df.to_excel(self.output[_fab])

            # result_df = result_df.query('Result == "FALSE"')
            result_df = result_df.sort_values('ToolID')
            result_df.reset_index(inplace=True, drop=True)

            # CRAS Data をDBに格納
            abnormal_db_df = result_df[result_df['Result'] == 'FALSE']
            self.logger.info('send_abnormal_report| abnormal_db_df=%d' % len(abnormal_db_df))

            abnormal_db_df = abnormal_db_df.loc[:, ['Date', 'ToolID', 'CRAS_ID', 'Value']]

            abnormal_db_df['user_name'] = self.user.lower()
            abnormal_db_df['fab_name'] = _fab.lower()

            self.insert_from_df(self.cras_abnormal_data_table_name[_fab], abnormal_db_df)

            # State(連続で発生している日)をカウンター
            result_df['State'] = '0'

            for i in range(len(result_df)):
                if result_df.loc[i, 'Result'] == 'FALSE':
                    count = self.get_state_count(self.user,
                                                 _fab,
                                                 result_df.loc[i, 'ToolID'],
                                                 result_df.loc[i, 'CRAS_ID'],
                                                 result_df.loc[i, 'Date'])
                    result_df.loc[i, 'State'] = count

            # Error Summary DataをDBから取得
            # err_summary = cras_db_if.get_data_with(
            #    "equipment_name, log_date, error_no, error_name, error_rank, sum(elapsed) AS elapsed, \
            #    sum(error_count) AS count",
            #    "error_summary",
            #    "log_date <='{}' AND log_date >='{}' AND error_rank != 'C'".format(rast_date, start_date),
            #    "equipment_name, log_date, error_no, error_name,error_rank;")

            # err_summary = convert_connect.fetch_all(table=f"{self.convert_db['schema']}.error_summary", args={
            #        'select': 'equipment_name, log_date, error_no, error_name, error_rank, \
            #        sum(elapsed) AS elapsed, sum(error_count) AS count',
            #        'where': "log_date <='{}' AND log_date >='{}' AND error_rank != 'C'".format(
            #            rast_date,
            #            start_date) + " group by equipment_name, log_date, error_no, error_name,error_rank;"})

            with ConvertDatabaseConnector() as (con, cur):
                sql = f"select equipment_id, log_date, error_no, error_name, error_rank, sum(elapsed) AS elapsed, " \
                      f"sum(error_count) AS count from cras_db.error_summary where log_date <='{last_date}' AND log_date >='{start_date}' AND error_rank != 'C' " \
                      f"group by equipment_id, log_date, error_no, error_name,error_rank;"

                try:
                    err_summary = pd.read_sql(sql, con)
                except Exception:
                    err_summary = pd.DataFrame(index=range(0, 0),
                                               columns=['equipment_id', 'log_date', 'error_no', 'error_name', 'error_rank', 'elapsed'])

                err_summary['log_date'] = err_summary['log_date'].astype(str)
                err_summary['log_date'] = err_summary['log_date'].str.replace('-', '/')

                # equipment_df = cras_db_if.fetch_all(table='equipments',
                #                                args={'select': 'equipment_name, tool_serial, tool_id, inner_tool_id'})
                equipment_df = self.equipment_df[['equipment_id', 'equipment_name', 'tool_serial', 'tool_id', 'inner_tool_id']]
                equipment_df = equipment_df.sort_values(by=['equipment_id'], axis=0)

                # CRAS Mail
                abnormal_body = create_abnormal_report_html_body(result_df, err_summary, equipment_df, _fab)
                abnormal_report = f'{abnormal_report}\r\n{abnormal_body}'

                # PDF作成
                cras_report = CRASReport()
                self.logger.info('send_abnormal_report| create_cras_report_pdf start')
                cras_report.create_cras_report_pdf(self.user,
                                                   _fab,
                                                   self.input_file[_fab],
                                                   result_df,  # self.output,
                                                   err_summary,
                                                   equipment_df,
                                                   self.cras_pdf_name[_fab],
                                                   self.zip_password)
                self.logger.info('send_abnormal_report| create_cras_report_pdf end')

        if not abnormal_report or abnormal_report == '':
            raise StepError('failed to create an abnormal report')

        with open(os.path.join(self.mail_body_output), 'w', encoding='utf-8') as f:
            f.write(create_abnormal_report_html(abnormal_report))
        return

    def create_zipfile(self, zip_name):
        if zip_name.find('CRAS_Report') != -1:
            files = self.cras_pdf_name
        elif zip_name.find('CRASDATA') != -1:
            files = self.input_file
        else:
            files = self.output

        if len(files) == 0:
            return ''

        arg = '' if self.zip_password is None or self.zip_password == '' else '-P %s' % self.zip_password
        _list = ' '.join([os.path.basename(files[_]) for _ in files if os.path.exists(files[_])])
        cmd_str = f'{env.ZIP_EXEC} {arg} {os.path.basename(zip_name)} {_list}'
        shell = f'cd {os.path.dirname(zip_name)}; {cmd_str};'
        ret = subprocess.call(shell, shell=True)
        return zip_name if ret == 0 else ''
