import matplotlib.pyplot as plt
import numpy as np


class CRASReportgraph:
    """
    .. class:: CRASReportgraph

        結果レポート用Graph
    """

    def __init__(self):
        # Graph Common setting
        self.graph_widht = 7
        self.graph_height = 3.7

        self.graph_bar_lable_font_size = 5
        self.graph_dpi = 150

        self.graph_label_font_size = 7

        self.graph_x_label_rotate = 70

        # Color Table
        # https://matplotlib.org/gallery/color/named_colors.html#sphx-glr-gallery-color-named-colors-py
        # Summary Graph
        self.abnomal_cnt_bar_color = 'orange'
        self.a_rank_cnt_bar_color = 'cadetblue'
        self.b_d_rank_cnt_bar_color = 'skyblue'

        # Abnoral Graph
        self.threshold_line_color = 'orangered'
        self.abnormal_bar_ok_color = 'forestgreen'
        self.abnormal_bar_ng_color = 'salmon'

    def create_summary_graph(self, summary_data, graph_file):
        """
        Summary dataのGraphを生成

        :param summary_data:
            :Graph 作成用データ
        :param graph_file:
            :Graph File Name

        :return: None
        """
        #### 1. bar plotで描画するデータ
        graph_list = ['Abnomal Count', 'A Rank Error', 'B/D Rank Error']

        xticks = []
        abnomal_count = []
        a_rank_error = []
        b_d_rank_error = []

        max_cnt = 5

        for row in summary_data.iterrows():
            count_data = row[1]

            xticks.append(count_data['tool_id'])

            abnomal_count.append(count_data['Abnomal Count'])
            a_rank_error.append(count_data['A Rank Error'])
            b_d_rank_error.append(count_data['B/D Rank Error'])

            if count_data['Abnomal Count'] > max_cnt:
                max_cnt = count_data['Abnomal Count']

            if count_data['A Rank Error'] > max_cnt:
                max_cnt = count_data['A Rank Error']

            if count_data['B/D Rank Error'] > max_cnt:
                max_cnt = count_data['B/D Rank Error']

        data = {'Abnomal Count': abnomal_count,
                'A Rank Error': a_rank_error,
                'B/D Rank Error': b_d_rank_error}

        #### 2. matplotlibのfigure及びaxis設定
        # 1x1 figure matrix生成, 幅(インチ)x高さ(インチ) のサイズ指定
        fig, axs = plt.subplots(1, 1, figsize=(self.graph_widht, self.graph_height))
        colors = [self.abnomal_cnt_bar_color,
                  self.a_rank_cnt_bar_color,
                  self.b_d_rank_cnt_bar_color]

        width = 0.25

        #### 3. bar 描画
        for i, model in enumerate(graph_list):
            pos = self.compute_pos(xticks, width, i, graph_list)
            bar_graph = axs.bar(pos, data[model], width=width * 0.95, label=model, color=colors[i])
            self.present_height(axs, bar_graph)  # bar高さ出力

        #### 4. x軸の詳細設定
        axs.set_xticks(range(len(xticks)))
        axs.set_xticklabels(xticks, fontsize=10)
        # axs.set_xlabel('Cancer type', fontsize=14)
        axs.xaxis.set_tick_params(rotation=self.graph_x_label_rotate,
                                  width=20,
                                  color='gray',
                                  labelsize=self.graph_label_font_size)

        #### 5. y軸の詳細設定
        axs.set_ylim([0, max_cnt + 1])

        yticks = []
        for i in range(1, max_cnt + 1):
            yticks.append(i)

        axs.set_yticks(yticks)
        axs.yaxis.set_tick_params(labelsize=self.graph_label_font_size)
        axs.set_ylabel('count')

        #### 6. 凡例
        axs.legend(loc='upper right', shadow=True, ncol=1)

        #### 7. 目
        axs.set_axisbelow(True)
        axs.yaxis.grid(True, color='gray', linestyle='dashed', linewidth=0.5)

        #### 8. Graph保存及び画面に出力
        fig.tight_layout()
        fig.savefig(graph_file, format='png', dpi=self.graph_dpi)
        # fig.show()

    def create_cras_graph(self, crasdata, event, graph_file, threshold, condition, range_day, err_judge, unit):
        """
        cras dataのGraphを生成

        :param crasdata:
            :Graph 作成用データ

        :param graph_file:
            :Graph File Name

        :param threshold:
            :C-RAS判定のthreshold値

        :param err_judge:
            :C-RAS判断基準

        :return: None
        """
        crasdata = crasdata.sort_values(['Day'], ascending=True)
        crasdata.reset_index(inplace=True, drop=True)

        date = list(crasdata.loc[:, 'Day'])
        values1 = list(crasdata.loc[:, event])
        values2 = list()

        for i in range(len(date)):
            values2.append(threshold)

        fig, axs = plt.subplots(1, 1, figsize=(self.graph_widht, self.graph_height))

        # Threshold Line Graph
        if condition != 'Coef.':
            axs.plot(date, values2, color=self.threshold_line_color, linestyle='dashed', linewidth=1.5)

        # Graph Bar Color
        over_color = self.abnormal_bar_ng_color
        under_color = self.abnormal_bar_ok_color

        if err_judge == 'Under':
            over_color = self.abnormal_bar_ok_color
            under_color = self.abnormal_bar_ng_color

        # Graph Bar add
        for i in range(len(date)):
            bar_color = self.abnormal_bar_ok_color

            if values1[i] > threshold:
                bar_color = over_color
            elif values1[i] < threshold:
                bar_color = under_color

            bar_graph = axs.bar(date[i], values1[i], color=bar_color, width=0.3)

            self.present_height(axs, bar_graph)

        #### x軸の詳細設定
        axs.xaxis.set_tick_params(labelsize=self.graph_label_font_size,
                                  rotation=self.graph_x_label_rotate)

        #### y軸の詳細設定
        axs.set_axisbelow(True)
        axs.yaxis.grid(True, color='gray', linestyle='dashed', linewidth=0.5)
        axs.yaxis.set_tick_params(labelsize=self.graph_label_font_size)
        if unit is not None and len(unit) > 0:
            axs.set_ylabel(unit)

        #### Graph Save
        # fig.suptitle(event, fontsize=15, fontweight='bold')
        fig.tight_layout()
        fig.savefig(graph_file, format='png', dpi=self.graph_dpi)

        plt.close()

    def compute_pos(self, xticks, width, i, models):
        """
        Graph Draw

        :return: index + width*correction
        """
        index = np.arange(len(xticks))
        nength = len(models)
        correction = i - 0.5 * (nength - 1)
        return index + width * correction

    def present_height(self, axs, bar_graph):
        """
        Graph Draw

        :return: none
        """
        for rect in bar_graph:
            height = rect.get_height()

            posx = rect.get_x() + rect.get_width() * 0.5
            posy = height * 1.01

            lable_rotate = 0

            if (height % 1) > 0:
                if height >= 10:
                    lable_rotate = 50

                axs.text(posx, posy, '%.3f' % height, rotation=lable_rotate,
                         ha='center', va='bottom',
                         fontsize=self.graph_bar_lable_font_size)
            else:
                if height >= 1000:
                    lable_rotate = 50

                axs.text(posx, posy, '%d' % height, rotation=lable_rotate,
                         ha='center', va='bottom',
                         fontsize=self.graph_bar_lable_font_size)