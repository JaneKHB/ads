import datetime

import pandas as pd
from jinja2 import Template

from dbconnector import ConvertDatabaseConnector
from dockerservice.cras.service_mail_html_cras import BASE_HTML


class CCrasProductonReport:
    """
    CRAS Production Reportを作成
    """

    def __init__(self, user_name, fab_name, equipment_df):
        # self.convert_db = {**convert_db}
        # self.convert_schema = self.convert_db.pop('schema')
        self.convert_schema = "cras_db"
        # self.convert_connect = DAOBaseClass(**self.convert_db)

        self.user_name = user_name
        self.fab_name = fab_name

        self.equipment_df = equipment_df

        if user_name == 'HKC':
            if fab_name == 'CZ':
                self.fab_name = 'H2'
            elif fab_name == 'CQ':
                self.fab_name = 'H1'

    def create_production_report_html(self, report_header, report_tail, fab_name, days=7):
        """
        Production dataのHTML Report作成
        :param days: data作成の日(前日から何日前までのデータを作成するか)
        :return Production HTML data
        """
        data = self.create_production_data(fab_name, days)
        return self.create_html_data(data, report_header, report_tail)

    def create_production_data(self, fab_name, days=7):
        """
        Production dataの作成
        :param days: data作成の日(前日から何日前までのデータを作成するか)
        :return Production data
        """
        day_str = 'log_date'

        end_day = datetime.date.today()
        # For testing
        end_day = datetime.datetime.strptime('2020-11-13', '%Y-%m-%d')
        start_day = end_day - datetime.timedelta(days=days)

        select_sql = '''SELECT equipment_id AS "ToolID", 
                    log_date AS "Date", 
                    plate_unload_number AS "PlateCount", 
                    running_rate AS "RunningRate", 
                    tact_time AS "TactTime", 
                    plate_transfer_waiting_time AS "WaitingTime", 
                    manual_assist_time_count AS "MasnuatAssistCount", 
                    person_inside_pm_count AS "PersonInsidePM", 
                    person_inside_a_rank_factor_count + person_inside_bd_rank_factor_count AS "PersonInsideErr", 
                    mask_transfer_number AS "MaskTransfer" 
                    FROM %s.running_rate ''' % self.convert_schema

        where_str = "WHERE {0} >= '{1}' AND {0} < '{2}';".format(day_str, start_day, end_day)
        # GROUP BY 句
        # group_by_str = "GROUP BY equipment_name,date_trunc('day', {})::date \n".format(day_str)
        # ORDER BY 句
        # order_by_str = "ORDER BY equipment_name, date_trunc('day', {})::date;".format(day_str)
        # 最終的なSQLの作成
        sql = select_sql + where_str
        # production_data = self.dbif.get_data_by_sql(sql)
        # production_data = self.convert_connect.execute_by_spl(sql)
        with ConvertDatabaseConnector() as (con, cur):
            try:
                production_data = pd.read_sql(sql, con)
            except Exception:
                production_data = pd.DataFrame(index=range(0, 0),
                                               columns=['ToolID', 'Date', 'PlateCount', 'RunningRate', 'TactTime',
                                                        'WaitingTime', 'MasnuatAssistCount', 'PersonInsidePM',
                                                        'PersonInsideErr', 'MaskTransfer'])

            # equipment nameを　inner tool idに変更
            # dbからequipmentsTable取得
            equipment_df = self.equipment_df[['equipment_id', 'user_name', 'fab_name', 'tool_id', 'inner_tool_id']]
            equipment_df = equipment_df[equipment_df["fab_name"] == fab_name]

            production_data['disp_name'] = ''

            for i in range(len(production_data)):
                inner_toolid = equipment_df[equipment_df['equipment_id'] == production_data.loc[i, 'ToolID']][
                    'inner_tool_id'].values
                toolid = equipment_df[equipment_df['equipment_id'] == production_data.loc[i, 'ToolID']]['tool_id'].values
                if len(toolid) > 0:
                    production_data.loc[i, 'ToolID'] = inner_toolid
                    production_data.loc[i, 'disp_name'] = toolid + '_' + inner_toolid
                else:
                    production_data.loc[i, 'ToolID'] = 'NOTFOUND(DELETE)'

            production_data = production_data[production_data['ToolID'] != 'NOTFOUND(DELETE)']

            return production_data

    def create_html_data(self, production_data, report_header, report_tail):
        """
        Production dataからメール配信用HTMLの作成
        :param production_data:
        :return HTML Data
        """
        tool_list = production_data['disp_name'].drop_duplicates().sort_values()
        # date_list = production_data['Date'].drop_duplicates().sort_values(ascending=False)
        output_list = list()
        ng_data = production_data.sort_values('disp_name')

        header = ['Date', 'PlateCount', 'RunningRate', 'TactTime', 'WaitingTime',
                  'MasnuatAssistCount', 'PersonInsidePM', 'PersonInsideErr', 'MaskTransfer']

        table_html = '''
    <table class="gs_none" style="width:980px;">
    <tr>        
        <td class="gs_body" colspan="100" style="border:1px solid #02439f;">
            <table class="gs_none" style="width:100%;">
                <tr>
                    <td class="gs_header" colspan="96" style="border:5px solid #02439f;">{{ report_header }}</td>
                </tr>
                <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
            </table>
            {% for tool, tool_list in render_data.items(): %}
            <table class="gs_none" style="width:100%;">
                <tr>
                    <td class="gs_bar1" colspan="96"><font class="gs_barmark">&#x25C6; </font> {{ tool }}</td>
                </tr>
                <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
                <tr>
                    <td class="gs_none" colspan="96">
                        <table class="gs_none" style="width:100%;">
                            <thead>
                                <tr>                               
                                    <th scope="col" style="border:1px solid #02439f;">Date</th>
                                    <th scope="col" style="border:1px solid #02439f;">Plate<br>Count</th>
                                    <th scope="col" style="border:1px solid #02439f;">Running<br>Rate[%]</th>
                                    <th scope="col" style="border:1px solid #02439f;">Tact<br>Time</th>
                                    <th scope="col" style="border:1px solid #02439f;">Waiting<br>Time</th>
                                    <th scope="col" style="border:1px solid #02439f;">Manual Assist<br>Time Count</th>
                                    <th scope="col" style="border:1px solid #02439f;">Person Inside<br>PM Count</th>
                                    <th scope="col" style="border:1px solid #02439f;">Person Inside<br>ABD Error</th>
                                    <th scope="col" style="border:1px solid #02439f;">MaskTransfer</th>
                                </tr>
                            </thead>
                            <tbody>
                                {% for record in tool_list: %}
                                <tr>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[0] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[1] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[2] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[3] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[4] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[5] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[6] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[7] }}</td>
                                    <td style="text-align:center; border:1px solid #02439f;">{{ record[8] }}</td>
                                </tr>
                                {% endfor %}
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr><td class="gs_none" colspan="96">&nbsp;<br>&nbsp;</td></tr>
            </table>
            {% endfor %}
            <table class="gs_none" style="width:100%;">
                <tr><td class="gs_none" colspan="96"><hr></td></tr>
                <tr>
                    <td class="gs_tail" colspan="96">{{ report_tail }}</td>
                </tr>
                <tr><td class="gs_none" colspan="96"><hr></td></tr>
                <tr><td class="gs_none" colspan="96">&nbsp;</td></tr>
            </table>
        </td>
    </tr>
    <tr>
        <td class="gs_none" colspan="100" style="text-align:right;">Canon Remote Alarm System Version 2.0</td>
    </tr>
</table>
        '''
        render_data = dict()

        for tool in tool_list:
            output_list.append(tool)

            odata = ng_data[(ng_data['disp_name'] == tool)]
            odata = odata.sort_values('Date', ascending=True)
            odata = odata[header]

            record = odata.values.tolist()

            table_template = Template(table_html)
            data = {'tool': tool, 'record': record}

            render_data[tool] = record

        ## Table Data Create
        table_data = {'render_data': render_data, 'report_header': report_header, 'report_tail': report_tail}
        table_template = Template(table_html)
        output_table_html = table_template.render(table_data)

        ## HTML Data Create
        data = {'table_data': output_table_html}
        template = Template(BASE_HTML)
        output_html = template.render(data)

        # print(os.path.abspath(os.getcwd())+"/test.html")
        # with open(os.path.abspath(os.getcwd())+"/test.html", "w") as f:
        #    # すべての内容を書き込む
        #    f.write(output_html)
        # print(output_html)

        return output_html
