import base64


class CRASReporthtml:
    """
    .. class:: CRASReportgraph

        結果レポート用Graph
    """

    def __init__(self, user_name, fab_name, date):
        self.user_name = user_name
        self.fab_name = fab_name
        self.date = '{}-{}-{}'.format(date.year, date.month, date.day)
        self.graph_img_width = 650

        self.subpage_title_bg_color = '#A8D08E'
        self.table_title_bg_color = '#D9E2F3'
        self.table_normal_bg_color = '#FFFFFF'
        self.table_highlight_bg_color = '#FFB6C1'

    def generate_report_mainpage(self, summary_data, html_file_name, image_file_name):
        """
        Summary PageのHTMLを作成
        """
        file = open(html_file_name, 'w')
        file.write('<html>')
        self.__make_header(file)
        file.write('    <body>')
        self.__make_title_1p(file)
        self.__make_cras_summary_table(summary_data, file)
        self.__insert_cras_summary_graph(file, image_file_name)

        file.write('    </body>\n')
        file.write('</html>\n')
        file.close()

    def generate_report_subpage(self, tool_id, JudgeResult, html_file_name, image_file, img_start_idx):
        """
        CRAS Error PageのHTMLを作成
        """
        file = open(html_file_name, 'w')
        file.write('<html>')
        self.__make_header(file)
        file.write('    <body>')
        self.__make_title_sub_p(file, tool_id)
        self.__make_abnormal_list_sub_p(file, JudgeResult, image_file, img_start_idx)
        # self.__make_error_summary_list_sub_p(file, err_summary)
        file.write('    </body>\n')
        file.write('</html>\n')
        file.close()

    def __make_header(self, file):
        """
        HTMLヘッダーの作成
        :param file: report html file
        """

        html_text = """
    <head>
        <title>CRAS Report</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <style type="text/css">
            #Title{
                font-size: 25pt;
                font-weight: bolder;
                font-family: Arial;
            }
            #SubTitle{
                font-size: 13pt;
                font-weight: bolder;
                font-family: Arial;
            }
            #ToolInfo{
                font-size: 13pt;
                font-weight: bolder;
                font-family: Arial;
            }
            #NormalFont{
                font-size: 10pt;
                font-family: Arial;
            }
            #SmallFont{
                font-size: 8pt;
                font-family: Arial;
            }
        </style>
    </head>
"""
        file.write(html_text)

    def __make_title_1p(self, file):
        """
        HTML 1pageのTitleとFAB情報、日付を作成
        :param file: report html file
        """

        html_text = """
        <p style='text-align:center'><span id ="Title"><u>C-RAS Abnormal Detection Report</u></span></p>
        <span id ="NormalFont">&nbsp;</span>
        <span id ="NormalFont">&nbsp;</span>
        <table align="center" cellspacing=0 border=0 style='width:500pt;border-collapse:collapse;border:none'>
            <table align="right" cellspacing=0 border=0 style='width:150pt;border-collapse:collapse;border:none'>
                <tr>
                    <td colspan=0 valign=center style='width:50pt;padding:0mm 0mm 0mm 0mm'>
                        <p style='text-align:left'><span id='ToolInfo'>&#183; FAB</span></p>
                    </td>
                    <td colspan=0 valign=center style='width:100pt;padding:0mm 0mm 0mm 0mm'>
                        <p style='text-align:left'><span id='ToolInfo'>: {}-{}</span></p>
                    </td>
                </tr>
                <tr>
                    <td colspan=0 valign=center style='width:50pt;padding:0mm 0mm 0mm 0mm'>
                        <p style='text-align:left'><span id='ToolInfo'>&#183; Date</span></p>
                    </td>
                    <td colspan=0 valign=center style='width:100pt;padding:0mm 0mm 0mm 0mm'>
                        <p style='text-align:left'><span id='ToolInfo'>: {}</span></p>
                    </td>
                </tr>
            </table>
        </table>
""".format(self.user_name, self.fab_name, self.date)

        file.write(html_text)

    def __make_title_sub_p(self, file, tool_id):
        """
        HTML 1pageのTitleとFAB情報、日付を作成
        :param file: report html file
        """
        html_text = """
        <table align="center" cellspacing=0 border=0 style='width:500pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='width:500pt;padding:0mm 0mm 0mm 0mm;background-color: {}'>
                    <p style='text-align:center'><span id='ToolInfo'>{}</span></p>
                </td>
            </tr>
        </table>
        <span id ="NormalFont">&nbsp;</span>
        <span id ="NormalFont">&nbsp;</span>
""".format(self.subpage_title_bg_color, tool_id)

        file.write(html_text)

    def __make_cras_summary_table(self, summary_data, file):
        """
        HTML 1PageのCRAS Sumary Table作成
        :param file: report html file
        """

        html_text = """
        <table align="center" cellspacing=0 border=0 style='width:500.0pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="NormalFont">&nbsp;</span>
                </td>
            </tr>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="NormalFont">&nbsp;</span>
                </td>
            </tr>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="SubTitle">[Summay Data]</span>
                </td>
            </tr>
        </table>

        <table align="center" cellspacing=0 border=1 style='width:500pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>TOOL ID</b></span></p> 
                </td>

                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Abnormal Detect Count</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>A Rank Error Count</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>B/D Rank Error Count</b></span></p>
                </td>
            </tr>
""".format(self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color)

        file.write(html_text)

        for row in summary_data.iterrows():
            count_data = row[1]

            bg_color = self.table_normal_bg_color

            if (count_data['Abnomal Count'] + count_data['A Rank Error'] + count_data['B/D Rank Error']) > 0:
                bg_color = self.table_highlight_bg_color

            html_text = """
            <tr>
                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>
                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>
                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>
                <td colspan=0 valign=center style='width:125pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>
            </tr>
""".format(bg_color,
           count_data['disp_name'],
           bg_color,
           count_data['Abnomal Count'],
           bg_color,
           count_data['A Rank Error'],
           bg_color,
           count_data['B/D Rank Error'])

            file.write(html_text)

        file.write('        </table>')

    def __insert_cras_summary_graph(self, file, image_file_name):
        """
        HTML 1PageのCRAS Sumary Graph
        :param file: report html file
        """
        data = None
        with open(image_file_name, 'rb') as img:
            data = base64.b64encode(img.read())

#         html_text = """
#         <span id ="NormalFont">&nbsp;</span>
#         <span id ="NormalFont">&nbsp;</span>
#         <center><img width={} align=center src="{}"></center>
# """.format(self.graph_img_width, image_file_name)
        html_text = """
        <span id ="NormalFont">&nbsp;</span>
        <span id ="NormalFont">&nbsp;</span>
        <center><img width={} align=center src="{}"></center>
        """.format(self.graph_img_width, f"data:image/png;base64,{data.decode('utf-8')}")

        file.write(html_text)

    def __make_abnormal_list_sub_p(self, file, judgeresult, image_file, img_start_idx):
        """
        C-RAS Page HTML
        """
        html_text = """
        <table align="center" cellspacing=0 border=0 style='width:500.0pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="SubTitle">[Abnormal Detection]</span>
                </td>
            </tr>
        </table>            
"""
        file.write(html_text)

        if len(judgeresult) > 0:
            i = 0
            for row in judgeresult.iterrows():
                abnormal_data = row[1]

                html_text = """
        <table align="center" cellspacing=0 border=1 style='width:500pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='width:50pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>State</b></span></p> 
                </td>

                <td colspan=0 valign=center style='width:240pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Item Name</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:70pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Threshold</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:70pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Compare</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:70pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Value</b></span></p>
                </td>
            </tr>
""".format(self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color)

                file.write(html_text)

                _state = ''

                if (abnormal_data['State'] == 1):
                    _state = 'New'
                else:
                    _state = 'Cont {}'.format(abnormal_data['State'])

                html_text = """
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p> 
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:left'><span id ="NormalFont">{}</span></p>
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>
            </tr>
        </table>
""".format(_state,
           abnormal_data['Event'],
           abnormal_data['Threshold'],
           abnormal_data['Compare'],
           format(abnormal_data['Value'], '.3f'))

                file.write(html_text)

                html_text = """
        <table align="center" cellspacing=0 border=0 style='width:500pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="SmallFont">&#9758;&nbsp;Range : {} [day] / Condition : {}</span>
                </td>
            </tr>
        </table>
""".format(abnormal_data['Range[day]'], abnormal_data['Condition'])

                file.write(html_text)

                # Image
                html_text = """
        <span id ="NormalFont">&nbsp;</span>
        <center><img width={} align=center src="{}"></center>
        <span id ="NormalFont">&nbsp;</span>
        <span id ="NormalFont">&nbsp;</span>
""".format(self.graph_img_width, image_file[img_start_idx + i])

                file.write(html_text)

                i = i + 1
        else:
            html_text = """
        <table align="center" cellspacing=0 border=0 style='width:500.0pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="NormalFont">&nbsp;</span>
                    <span id ="NormalFont">&nbsp;&nbsp;None</span>
                </td>
            </tr>
        </table>
        <span id ="NormalFont">&nbsp;</span>
        <span id ="NormalFont">&nbsp;</span>
"""
            file.write(html_text)

    def __make_error_summary_list_sub_p(self, file, err_summary):
        """

        """
        html_text = """
        <table align="center" cellspacing=0 border=0 style='width:500.0pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <span id ="SubTitle">[Error Summary]</span>
                </td>
            </tr>
        </table>
"""
        file.write(html_text)

        if len(err_summary) > 0:
            html_text = """
        <table align="center" cellspacing=0 border=1 style='width:500pt;border-collapse:collapse;border:none'>
            <tr>
                <td colspan=0 valign=center style='width:50pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Error No.</b></span></p> 
                </td>

                <td colspan=0 valign=center style='width:310pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Error Name</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:60pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Total Count</b></span></p>
                </td>

                <td colspan=0 valign=center style='width:80pt;padding:0.5mm 1mm 0.5mm 1mm;background-color: {}'>
                    <p style='text-align:center'><span id ="NormalFont"><b>Total Time</b></span></p>
                </td>
            </tr>
""".format(self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color,
           self.table_title_bg_color)

            file.write(html_text)

            for row in err_summary.iterrows():
                err_summary_data = row[1]

                html_text = """
            <tr>
                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p> 
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:left'><span id ="NormalFont">{}</span></p>
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>

                <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                    <p style='text-align:center'><span id ="NormalFont">{}</span></p>
                </td>
            </tr>
""".format(err_summary_data['error_no'],
           err_summary_data['error_name'],
           err_summary_data['count'],
           err_summary_data['elapsed'])

                file.write(html_text)

            file.write('        </table>')

        else:
            html_text = """
            <table align="center" cellspacing=0 border=0 style='width:500.0pt;border-collapse:collapse;border:none'>
                <tr>
                    <td colspan=0 valign=center style='padding:0.5mm 1mm 0.5mm 1mm'>
                        <span id ="NormalFont">&nbsp;</span>
                        <span id ="NormalFont">&nbsp;&nbsp;None</span>
                    </td>
                </tr>
            </table>
"""

            file.write(html_text)