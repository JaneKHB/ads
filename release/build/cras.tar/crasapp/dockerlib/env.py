import os
from sys import platform

ROOT_PATH = None

PRIV_PATH = 'priv'
USER_PATH = 'priv/usr'
STORAGE_FILE = 'priv/usr/__storage/storage.json'
CONTEXT_FILE_NAME = 'order.json'
TEST_SCRIPT_PATH = 'test'
COMMON_PATH = '_common'

ZIP_EXEC = 'zip'

CONFIG_DB = {
    'host': 'Cras-Database',
    'port': 5432,
    'dbname': 'rssdb',
    'user': 'rssadmin',
    'password': 'canon'
}

if platform == 'win32':
    CONFIG_DB['host'] = 'localhost'
    CONFIG_DB['port'] = 5443

# CONFIG_DB = {
#     'host': 'localhost',
#     'port': 5443,
#     'dbname': 'rssdb',
#     'user': 'rssadmin',
#     'password': 'canon'
# }

CONFIG_CONVERT_DB = {
    **CONFIG_DB,
    'schema': 'cras_db'
}

# Use the below constants like config_of(the below one)
CONVERT_DB = 'convert-storage-db'
SETTING_DB = 'setting-db'
LOG_MONITOR_DB = 'log-monitor'
USERNAME = 'user-name'
RAPID_COLLECTOR = 'rapid-collector'
LOG_NAME_RECIPE = 'log-name-recipe'
LOG_NAME_MACHINE_DATA = 'log-name-machine-status'
LOG_NAME_VERSION = 'log-name-version'


def init():
    global ROOT_PATH
    print('##[steprunner] initialize env file')
    ROOT_PATH = os.getcwd()
