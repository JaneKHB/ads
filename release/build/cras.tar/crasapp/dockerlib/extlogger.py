import env
from system_logger import SystemLogger


gger = None


def init_logger(system: str, module: str):
    global gger
    gger = SystemLogger(system, module, config=env.CONFIG_DB)
