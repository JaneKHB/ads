methods = list()


def script():
    def _wrapper1(func):
        def _wrapper2(*args, **kwargs):
            return func(*args, **kwargs)

        methods.append({'name': func.__name__, 'func': func})

        return _wrapper2

    return _wrapper1


def get_method_list():
    return methods
