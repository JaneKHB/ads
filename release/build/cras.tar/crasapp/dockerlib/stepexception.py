class StepIterationContinue(Exception):
    pass


class StepSuccess(Exception):
    """
    StepSuccess exception will break a step processing.
    But in this case the step consider this processing success.
    """
    pass


class StepError(Exception):
    """
    StepError exception will break a step processing
    and change its status to error.
    """
    pass


class StepNoData(Exception):
    """
    StepNoData exception means the step has been finish with no result data.
    """
    pass
