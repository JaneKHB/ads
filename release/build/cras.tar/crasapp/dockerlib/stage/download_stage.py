import os
import shutil

import env
import logutil
from logutil import config_of
from rapid import RapidConnector
from stage.step_service import StepService
from stepexception import StepError, StepSuccess, StepNoData
import extlogger as lo


class DownloadStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.username = config_of(env.USERNAME)
        self.logger = lo.gger

        self.fab_name_list = None
        self.machine_name_list = None
        self.category_list = None

    def step_start(self):
        # Download user-specific logs
        self.logger.info('download user-specific logs')
        ftp_type = self.ctx['ftp_type']
        if ftp_type == 'ftp':
            log_zip_path = self.ftp_download()
        elif ftp_type == 'vftp_compat':
            log_zip_path = self.vftp_compat_download()
        elif ftp_type == 'vftp_sss':
            log_zip_path = self.vftp_sss_download()
        else:
            raise StepError('unsupported ftp type')

        # Download common information logs
        common_path = self.download_common()

        if log_zip_path is None and common_path is None:
            raise StepNoData('no log files to download')

        # Put all logs into an archive
        self.logger.info('create an archive')
        output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'], 'log_files')
        if os.path.exists(output_path):
            self.logger.warn('remove old output')
            shutil.rmtree(output_path)
        os.mkdir(output_path)

        if log_zip_path is not None:
            # Unzip log files
            self.logger.info('unzip downloaded logs')
            log_path = logutil.unzip_r(log_zip_path, os.path.dirname(log_zip_path))
            os.remove(log_zip_path)

            self.logger.info('copy downloaded logs into the archive')
            shutil.copytree(log_path, output_path, copy_function=shutil.move, dirs_exist_ok=True)
            shutil.rmtree(log_path)

        if common_path is not None:
            self.logger.info('copy common information into the archive')
            shutil.copytree(common_path, output_path, copy_function=shutil.move, dirs_exist_ok=True)
            shutil.rmtree(common_path)

        # Zip all downloaded files.
        self.logger.info('create an output file')
        shutil.make_archive(output_path, 'zip', output_path)
        shutil.rmtree(output_path)

        self.change_status('success')

    def download_common(self):
        try:
            self.logger.info('download_common')

            fab_name_list, machine_name_list = self.get_fab_machine_name_list()

            category_list = self.get_category_list()

            default_payload = {
                'fabNames': fab_name_list,
                'machineNames': machine_name_list,
                'startDate': '19800101000000',
                'endDate': '21001231235959',
                'depth': 0,
                'folder': True
            }

            rapid = RapidConnector()
            download_list = list()

            # Search recipes
            is_recipe = False
            if self.is_recipe_prerequisite():
                try:
                    self.logger.info(f"download_common| download recipes of dev={self.ctx['device']} pro={self.ctx['process']}")

                    config_recipe = config_of(env.LOG_NAME_RECIPE)
                    cat_recipe = next((c for c in category_list if c['categoryName'] == config_recipe), None)
                    if cat_recipe is None:
                        raise StepService.Next('failed to find log category with the log name %s' % config_recipe)

                    file_list = rapid.search({'ftp_type': 'ftp', 'payload': {
                        **default_payload,
                        'categoryCodes': [cat_recipe['categoryCode']],
                        'categoryNames': [cat_recipe['categoryName']]}})

                    if file_list is None or len(file_list) == 0:
                        raise StepService.Next('failed to search files')

                    dev_file = next((i for i in file_list if i['fileName'] == self.ctx['device']), None)
                    if dev_file is None:
                        raise StepService.Next('failed to find matching directory with the device %s' % self.ctx['device'])

                    download_list.append(dev_file)
                    is_recipe = True
                    self.logger.info('download_common| %d recipes have found' % len(file_list))

                except StepService.Next as ex:
                    self.logger.info('download_common| no recipe files (%s)' % str(ex))
            else:
                self.logger.info('download_common| not enough information to download recipes')

            # Search machine data
            try:
                config_machine_data = config_of(env.LOG_NAME_MACHINE_DATA)
                self.logger.info("download_common| download machine_data (cat=%s)" % config_machine_data)

                cat_machine_data = next((c for c in category_list if c['categoryName'] == config_machine_data), None)
                if cat_machine_data is None:
                    raise StepService.Next('failed to find log category with the log name %s' % cat_machine_data)

                file_list = rapid.search({'ftp_type': 'ftp', 'payload': {
                    **default_payload,
                    'categoryCodes': [cat_machine_data['categoryCode']],
                    'categoryNames': [cat_machine_data['categoryName']]}})

                if file_list is None or len(file_list) == 0:
                    raise StepService.Next('failed to search files')

                download_list += file_list
                self.logger.info('download_common| %d machine data have found' % len(file_list))

            except StepService.Next as ex:
                self.logger.info('download_common| no machine_data files (%s)' % str(ex))

            # Search version information
            try:
                config_version = config_of(env.LOG_NAME_VERSION)
                self.logger.info("download_common| download version info (cat=%s)" % config_machine_data)

                cat_version = next((c for c in category_list if c['categoryName'] == config_version), None)
                if cat_version is None:
                    raise StepService.Next('failed to find log category with the log name %s' % cat_machine_data)

                file_list = rapid.search({'ftp_type': 'ftp', 'payload': {
                    **default_payload,
                    'categoryCodes': [cat_version['categoryCode']],
                    'categoryNames': [cat_version['categoryName']]}})

                if file_list is None or len(file_list) == 0:
                    raise StepService.Next('failed to search files')

                download_list += file_list
                self.logger.info('download_common| %d version info have found' % len(file_list))

            except StepService.Next as ex:
                self.logger.info('download_common| no version information files (%s)' % str(ex))

            if len(download_list) == 0:
                self.logger.warn('download_common| no files to download')
                return None

            # Request to download from Rapid-Collector
            download_req_info = {'ftp_type': 'ftp', 'payload': {'lists': download_list}}
            download_path = rapid.download_request(download_req_info,
                                                 os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id']))

            if not os.path.exists(download_path):
                raise StepError('failed to download file')

            # Unzip the downloads
            download_unzip_path = logutil.unzip_r(download_path, os.path.dirname(download_path))
            os.remove(download_path)

            # Remove files that doesn't relates with the error
            if self.is_recipe_prerequisite() and is_recipe:
                target_path = os.path.join(download_unzip_path, dev_file['machineName'], config_recipe, self.ctx['device'])
                for f in os.listdir(target_path):
                    if not f.startswith(self.ctx['device']) and not f.startswith(self.ctx['process']):
                        _f = os.path.join(target_path, f)
                        if os.path.isdir(_f):
                            shutil.rmtree(_f)
                        else:
                            os.remove(_f)
                        self.logger.debug('download_common| recipe %s deleted' % f)

            return download_unzip_path

        except Exception as ex:
            ex.args = ('download_common|',) + ex.args
            raise

    def ftp_download(self):
        rapid = RapidConnector()

        # Create machine and fab information
        machine_list = self.get_equipment_df()
        machine_name_list = list()
        fab_name_list = list()
        for eq in self.ctx['machine']:
            m = machine_list[machine_list['machineName'] == eq]
            if m is None or len(m) == 0:
                raise StepError('cannot find a machine %s' % eq)
            m = m.iloc[0].to_dict()
            machine_name_list.append(m['machineName'])
            fab_name_list.append(m['fab_name'])

        # Create category information
        category_list = self.get_category_list()

        category_code_list = list()
        category_name_list = list()
        for ct in self.ctx['command']:
            c = next((c for c in category_list if c['categoryName'] == ct), None)
            if c is None:
                raise StepError('cannot find a category code %s' % ct)
            category_code_list.append(c['categoryCode'])
            category_name_list.append(c['categoryName'])

        payload = {
            'fabNames': fab_name_list,
            'machineNames': machine_name_list,
            'categoryCodes': category_code_list,
            'categoryNames': category_name_list,
            'startDate': self.ctx['start_date'],
            'endDate': self.ctx['end_date'],
            'depth': 999,
            'folder': False
        }
        search_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        file_list = rapid.search(search_req_info)
        if file_list is None:
            raise StepError('failed to search file')

        if len(file_list) == 0:
            raise StepNoData('no search result')

        payload = {'lists': file_list}
        download_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}

        file_path = rapid.download_request(download_req_info,
                                           os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id']))

        if not os.path.exists(file_path):
            raise StepError('failed to download file')

        return file_path

    def vftp_compat_download(self):
        rapid = RapidConnector()

        if 'command' not in self.ctx:
            raise StepError('no command parameter')
        if len(self.ctx['command']) == 0:
            raise StepError('empty command not allowed')

        # Create machine and fab information
        machine_list = self.get_equipment_df()

        machine_name_list = list()
        fab_name_list = list()
        for eq in self.ctx['machine']:
            m = machine_list[machine_list['machineName'] == eq]
            if m is None or len(m) == 0:
                raise StepError('cannot find a machine %s' % eq)
            m = m.iloc[0].to_dict()
            machine_name_list.append(m['machineName'])
            fab_name_list.append(m['fab_name'])

        # download
        download_cmd = self.ctx['command'][0].split()[-1].strip()
        payload = {'command': download_cmd,
                   'fabNames': fab_name_list,
                   'machineNames': machine_name_list}
        download_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        try:
            file_path = rapid.download_request(download_req_info,
                                               os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id']))
        except Exception as ex:
            raise StepSuccess(ex)

        if not os.path.exists(file_path):
            raise StepError('failed to download file')

        return file_path

    def vftp_sss_download(self):
        rapid = RapidConnector()

        if 'command' not in self.ctx:
            raise StepError('no command parameter')
        if len(self.ctx['command']) == 0:
            raise StepError('empty command not allowed')

        # Create machine and fab information
        machine_list = self.get_equipment_df()

        machine_name_list = list()
        fab_name_list = list()
        for eq in self.ctx['machine']:
            m = machine_list[machine_list['machineName'] == eq]
            if m is None or len(m) == 0:
                raise StepError('cannot find a machine %s' % eq)
            m = m.iloc[0].to_dict()
            machine_name_list.append(m['machineName'])
            fab_name_list.append(m['fab_name'])

        search_cmd = self.ctx['command'][0].split()[-1].strip()
        payload = {
            'command': search_cmd,
            'fabNames': fab_name_list,
            'machineNames': machine_name_list
        }
        search_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        file_list = rapid.search(search_req_info)
        if file_list is None:
            raise StepError('failed to search file')

        if len(file_list) == 0:
            raise StepNoData('no search result')

        payload = {'lists': file_list}
        download_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        file_path = rapid.download_request(download_req_info, os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id']))

        if not os.path.exists(file_path):
            raise StepError('failed to download file')

        return file_path

    def get_fab_machine_name_list(self):
        if self.fab_name_list is None or self.machine_name_list is None:
            # Create machine and fab information
            machine_list = self.get_equipment_df()
            machine_name_list = list()
            fab_name_list = list()
            for eq in self.ctx['machine']:
                m = machine_list[machine_list['machineName'] == eq]
                if m is None or len(m) == 0:
                    raise StepError('cannot find a machine %s' % eq)
                m = m.iloc[0].to_dict()
                machine_name_list.append(m['machineName'])
                fab_name_list.append(m['fab_name'])

            if len(fab_name_list) == 0 or len(machine_name_list) == 0:
                raise StepError('fab(%d) and(%d) machine is not determined'
                                % (len(fab_name_list), len(machine_name_list)))

            self.fab_name_list = fab_name_list
            self.machine_name_list = machine_name_list

        return self.fab_name_list, self.machine_name_list

    def get_category_list(self):
        if self.category_list is None:
            rapid = RapidConnector()
            self.category_list = rapid.get_categories()
        return self.category_list

    def is_recipe_prerequisite(self):
        if self.ctx['process'] is None or self.ctx['process'] == '':
            return False
        if self.ctx['device'] is None or self.ctx['device'] == '':
            return False
        return True
