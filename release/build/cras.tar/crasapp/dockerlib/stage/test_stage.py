import extlogger as lo

from stage.step_service import StepService
from stage.custom_stage import PyScript


class TestStage(StepService):

    def __init__(self, ctx, pid):
        self.pid = pid
        self.ctx = ctx
        self.logger = lo.gger

    def step_start(self):
        script_runner = PyScript(self.ctx['step'], self.ctx['id'], self.logger, True)
        is_success = script_runner.run()
        if is_success:
            self.change_status('success')
        else:
            self.change_status('error')
