import os
import shutil


import env
import logutil
import extlogger as lo
from rapid import RapidConnector
from stepexception import StepNoData
from stage.step_service import StepService
from datetime import datetime
from logutil import config_of
class CollectStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.logger = lo.gger
        self.username = config_of(env.USERNAME)

    def step_start(self):
        rapid = RapidConnector()

        # Get retention
        retention = 7
        if 'retention_period' in self.ctx:
            retention = int(self.ctx['retention_period'])

        # Get plan list
        plan_list = rapid.get_plan()
        plan_list = [plan for plan in plan_list if plan['planId'] in self.ctx['plan_id']]

        # Download all files collected from the plans
        file_list = list()
        for plan in plan_list:
            download_log = rapid.get_download_list(plan['planId'])
            if len(download_log) == 0:
                self.logger.info('no log files to download in plan %d' % plan['planId'])
                continue

            self.logger.info('download log file of plan %d' % plan['planId'])
            dest_path = os.path.join(env.PRIV_PATH, self.ctx['step'], str(plan['planId']))
            if not os.path.exists(dest_path):
                os.mkdir(dest_path)
            for log in download_log:
                f = rapid.download_file(log['downloadUrl'], dest_path)
                if f is not None:
                    file_list.append(f)
                    self.logger.info('unzip file %s' % f)
                    unzip_dest_path = logutil.unzip_r(f, dest_path)
                    self.backup_file(f, unzip_dest_path, retention)

        if len(file_list) == 0:
            raise StepNoData('no logs to download')

        self.logger.info('total %d files downloaded' % len(file_list))

        self.change_status('success')

    def get_oldest_item(self, download_list):
        oldest = None
        for item in download_list:
            if oldest is None:
                oldest = item
            elif oldest['created'] > item['created']:
                oldest = item
        return oldest

    def delete_backup_in_dir(self, path, now, del_day):
        for (root, dirs, files) in os.walk(path):
            for file in files:
                f_path = os.path.join(root, file)
                a_time = os.path.getatime(f_path)
                f_time = datetime.fromtimestamp(a_time)
                diff = now - f_time
                if diff.days > del_day:
                    self.logger.warn('remove| file: %s' % f_path)
                    os.remove(f_path)

    def move_machine_in_sub_dir(self, machine, root, path):
        for m_dir in os.listdir(path):
            if machine == m_dir:
                src = os.path.join(path, m_dir)
                dst = os.path.join(root, machine)
                shutil.copytree(src, dst, dirs_exist_ok=True)
                self.logger.warn('move| src: %s' % src)
                self.logger.warn('move| dst: %s' % dst)

    def move_machine_in_dir(self, machine, root, path):
        src = path
        dst = os.path.join(root, machine)
        shutil.copytree(src, dst, dirs_exist_ok=True)
        self.logger.warn('move| src: %s' % src)
        self.logger.warn('move| dst: %s' % dst)

    def move_all_in_dir(self, path, root):
        if os.path.exists(path):
            for f in os.listdir(path):
                f_path = os.path.join(path, f)
                if not os.path.isfile(f_path):
                    equipment_df = self.get_equipment_df()
                    equipment_list = equipment_df['machineName'].to_list()
                    for machine in equipment_list:
                        if machine in f_path:
                            # ex)Administrator_Fab1_MPA_2_20221101_134708
                            #     + statusmonitor
                            #       + 20102213
                            #       + 20112031
                            self.move_machine_in_dir(machine, root, f_path)
                        else:
                            # ex)Administrator_Fab1_20221101_102705
                            #     + MPA1
                            #       + statusmonitor
                            #         + 20102213
                            #         + 20112031
                            self.move_machine_in_sub_dir(machine, root, f_path)

    def backup_file(self, file, unzip_dest_path, retention):
        # remove zip file
        if os.path.exists(file):
            os.remove(file)

        # create base, root path
        username = config_of(env.USERNAME)
        base_path = os.path.join(env.PRIV_PATH, 'rawdata')
        if not os.path.exists(base_path):
            os.mkdir(base_path)

        root_path = os.path.join(base_path, username)
        if not os.path.exists(root_path):
            os.mkdir(root_path)

        # move raw data
        self.move_all_in_dir(unzip_dest_path, root_path)

        # delete raw data
        self.delete_backup_in_dir(root_path, datetime.now(), retention)