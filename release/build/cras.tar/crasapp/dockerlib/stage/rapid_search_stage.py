import os
import json

import env
import extlogger as lo
from rapid import RapidConnector
from stepexception import StepError
from stage.step_service import StepService
from logutil import config_of


class RapidSearchStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.logger = lo.gger
        self.username = config_of(env.USERNAME)

    def step_start(self):
        # search logs
        self.logger.info('search logs')
        ftp_type = self.ctx['ftp_type']
        if ftp_type == 'ftp':
            file_list = self.ftp_search()
        elif ftp_type == 'vftp_sss':
            file_list = self.vftp_sss_search()
        else:
            raise StepError('unsupported ftp type')
        print(file_list)
        # Create output directory using pid
        output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'])
        # os.mkdir(output_path)
        print(output_path)

        file_list_path = os.path.join(output_path, 'file_list.json')
        with open(file_list_path, 'w', encoding='utf-8') as f:
            f.write(json.dumps(file_list))

        if not os.path.exists(file_list_path):
            raise StepError('failed to create report html file')

        self.change_status('success')

    def ftp_search(self):
        rapid = RapidConnector()

        if 'command' not in self.ctx:
            raise StepError('no command parameter')
        if len(self.ctx['command']) == 0:
            raise StepError('empty command not allowed')

        # Create machine and fab information
        machine_list = self.get_equipment_df()
        machine_name_list = list()
        fab_name_list = list()
        print(machine_list)
        for eq in self.ctx['machine']:
            m = machine_list[machine_list['equipment_name'] == eq]
            if m is None or len(m) == 0:
                raise StepError('cannot find a machine %s' % eq)
            m = m.iloc[0].to_dict()
            machine_name_list.append(m['machineName'])
            fab_name_list.append(m['fab_name'])

        # Create category information
        category_list = self.get_category_list()

        category_code_list = list()
        category_name_list = list()
        for ct in self.ctx['command']:
            c = next((c for c in category_list if c['categoryName'] == ct), None)
            if c is None:
                raise StepError('cannot find a category code %s' % ct)
            category_code_list.append(c['categoryCode'])
            category_name_list.append(c['categoryName'])

        payload = {
            'fabNames': fab_name_list,
            'machineNames': machine_name_list,
            'categoryCodes': category_code_list,
            'categoryNames': category_name_list,
            'startDate': self.ctx['start_date'],
            'endDate': self.ctx['end_date'],
            'depth': 999,
            'folder': False
        }
        search_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        file_list = rapid.search(search_req_info)
        if file_list is None:
            raise StepError('failed to search file')

        return file_list

    def vftp_sss_search(self):
        rapid = RapidConnector()

        if 'command' not in self.ctx:
            raise StepError('no command parameter')
        if len(self.ctx['command']) == 0:
            raise StepError('empty command not allowed')

        # Create machine and fab information
        machine_list = self.get_equipment_df()

        machine_name_list = list()
        fab_name_list = list()
        for eq in self.ctx['machine']:
            m = machine_list[machine_list['equipment_name'] == eq]
            if m is None or len(m) == 0:
                raise StepError('cannot find a machine %s' % eq)
            m = m.iloc[0].to_dict()
            machine_name_list.append(m['machineName'])
            fab_name_list.append(m['fab_name'])

        search_cmd = self.ctx['command'][0].split()[-1].strip()
        payload = {
            'command': search_cmd,
            'fabNames': fab_name_list,
            'machineNames': machine_name_list
        }
        search_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        file_list = rapid.search(search_req_info)
        if file_list is None:
            raise StepError('failed to search file')

        return file_list

    def get_category_list(self):
        rapid = RapidConnector()
        return rapid.get_categories()
