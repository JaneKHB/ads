import importlib
import os
import sys
import shutil
import subprocess
from abc import ABC, abstractmethod
from pathlib import Path

import env
import extlogger as lo
import step
from stage.step_service import StepService
from script_type import ScriptType

RUN_SH_SCRIPT_NAME = 'run.sh'
RUN_PY_SCRIPT_NAME = 'run.py'


class CustomStage(StepService):
    def __init__(self, ctx):
        self.ctx = ctx
        self.logger = lo.gger
        self.step = ctx['step']
        self.rid = ctx['id']
        self.script_type = ScriptType.UNKNOWN

    def step_start(self):
        # create rid directory
        self.__create_rid_dir()

        # get script type
        script_path = os.path.join(env.PRIV_PATH, self.step, "_script")
        self.script_type, run_script_path = self.__get_script_type(script_path)

        # create script_runner instance.
        script_runner = self.__create_script_runner(run_script_path)
        if script_runner is not None:
            # Run scripts
            work_path = os.getcwd()
            os.chdir(os.path.dirname(run_script_path))
            res = script_runner.run()
            os.chdir(work_path)
        else:
            self.logger.error('script_runner fail to create.[step:{}, script_type:{}]'
                              .format(self.step, self.script_type.name))
            res = False

        # set status
        self.__set_status(res)

    def __create_rid_dir(self):
        rid_path = os.path.join(env.PRIV_PATH, self.step, self.rid)
        if not os.path.exists(rid_path):
            Path(rid_path).mkdir(parents=True, exist_ok=True)
            # os.mkdir(rid_path)
        return rid_path

    def __copy_script_to_rid_dir(self, dst_path):
        src_path = os.path.join(env.PRIV_PATH, self.step, "_script")
        if os.path.exists(dst_path):
            shutil.rmtree(dst_path)

        if os.path.exists(src_path):
            shutil.copytree(src_path, dst_path)
        else:
            self.logger.warn("[{}] is not exist.".format(src_path))

    def __create_script_runner(self, run_script_path):
        if self.script_type == ScriptType.PYTHON:
            script_runner = PyScript(self.step, self.rid, self.logger, run_script_path)
        elif self.script_type == ScriptType.SHELL:
            script_runner = ShScript(self.step, self.rid, self.logger, run_script_path)
        else:
            script_runner = None
        return script_runner

    def __get_script_type(self, rid_path):
        script_type = ScriptType.UNKNOWN
        run_script_path = ''
        for f in os.listdir(rid_path):
            if f == RUN_SH_SCRIPT_NAME:
                script_type = ScriptType.SHELL
            elif f == RUN_PY_SCRIPT_NAME:
                script_type = ScriptType.PYTHON
            else:
                continue
            # script_type = ScriptType.conv_script_type(type)
            run_script_path = os.path.join(rid_path, f)
            break
        return script_type, run_script_path

    def __set_status(self, is_success):
        if is_success:
            self.change_status('success')
        else:
            self.change_status('error')


class Script(ABC):
    def __init__(self, step_name, rid, script_type, logger, run_script_path):
        self._step = step_name
        self._rid = rid
        self._script_type = script_type
        self._logger = logger
        self._run_script_path = run_script_path

    @abstractmethod
    def run(self) -> bool:
        pass


class PyScript(Script):
    def __init__(self, step_name, rid, logger, run_script_path, is_test_mode=False):
        super().__init__(step_name, rid, ScriptType.PYTHON, logger, run_script_path)
        self.is_test_mode = is_test_mode

    def get_script_method(self):
        modules = []
        # create module name.
        script_name = str(self._run_script_path).split(os.sep)[-1].split('.')[0]
        if self.is_test_mode:
            modules.append('%s.%s.%s.%s' % (env.PRIV_PATH, self._step, '_script', script_name))
        else:
            modules.append('%s.%s.%s' % (self._step, '_script', script_name))

        # import module.
        for module in modules:
            importlib.import_module(module)
        return step.get_method_list()

    def run(self):
        sys.path.append(os.path.abspath(os.path.basename(self._run_script_path)).replace('run.py', ''))
        methods = self.get_script_method()
        if len(methods) > 0:
            for method in methods:
                self._logger.info('call python script function[{}]'.format(method['name']))
                method['func']()
            res = True
        else:
            self._logger.error('cannot find methods in [{}] script'.format(self._script_type.name))
            res = False
        return res


class ShScript(Script):
    def __init__(self, step_name, rid, logger, run_script_path):
        super().__init__(step_name, rid, ScriptType.SHELL, logger, run_script_path)

    def run(self):
        res = self.__execute(self._run_script_path)
        return res

    def __execute(self, script):
        if script is not None:
            self._logger.info('run [{}] file'.format(script))
            try:
                python_path = ":".join(sys.path)[1:]
                process = subprocess.Popen(['sh', os.path.basename(script)],
                                           stdout=subprocess.PIPE,
                                           stderr=subprocess.STDOUT,
                                           universal_newlines=True,
                                           env={'PYTHONPATH':python_path})

                # print stdout while child process is running
                while process.poll() is None:
                    out = process.stdout.readline()
                    if out != '':
                        self._logger.info(out.replace(os.linesep, ""))

                # print remaining buffer after child process is terminated
                out = process.stdout.readline()
                while out != '':
                    self._logger.info(out.replace(os.linesep, ""))
                    out = process.stdout.readline()

                is_success = True
            except Exception as ex:
                self._logger.error(ex.args)
                is_success = False
        else:
            self._logger.error("[{}] file not found.".format(self._script_type.name))
            is_success = False
        return is_success
