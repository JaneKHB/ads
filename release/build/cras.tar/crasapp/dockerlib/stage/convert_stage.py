import os
import re
import shutil
import traceback
import psycopg2

import numpy as np

import logutil
import env
import extlogger as lo
from logutil import config_of
from dockerservice.convert.status_monitor_converter import convert_status_monitor
from dockerservice.convert.error_summary import ErrorSummary
from stage.step_service import StepService
from convert.convert import LogConvert
from stepexception import StepIterationContinue, StepError
from dbconnector import ConvertDatabaseConnector


class ConvertStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.converter = None
        self.equipment_list = None
        self.username = config_of(env.USERNAME)
        self.logger = lo.gger

    def step_start(self):
        self.init_converter_module()

        if 'file' not in self.ctx:
            collected_log_list = logutil.get_collected_log_list()
        else:
            # In case of local job, it's gonna set collected_log_list after unzip files.
            files = self.ctx['file']

            collected_log_list = list()
            for f in files:
                self.logger.info('unzip file %s' % f)
                file_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'], f)
                if not os.path.exists(file_path):
                    raise StepError('cannot find input file %s' % file_path)
                if not f.endswith('.zip'):
                    raise StepError('not supported input file extension %s' % f)

                # Unzip the file
                dest = logutil.unzip_r(file_path, os.path.dirname(file_path))

                for (root, dirs, logs) in os.walk(dest):
                    if len(logs) > 0:
                        collected_log_list += [os.path.join(root, l) for l in logs if not l.endswith('.zip')]

        if len(collected_log_list) == 0:
            self.logger.info('no files collected')
        else:
            self.logger.info('%d files collected' % len(collected_log_list))

        # Convert logs
        converted_log_file = list()
        for log_file in collected_log_list:
            try:
                fab_name, equipment_name, log_name, equipment_id = self.get_log_file_information(log_file)

                self.logger.info('convert| target info: fab:%s eqp:%s log:%s' % (fab_name, equipment_name, log_name))
                self.logger.info('convert| target file: %s' % log_file)
                # When there is a standalone converter for the log name.
                if log_name.lower() == 'statusmonitor' or log_name.lower() == 'status_monitor':
                    df = convert_status_monitor(log_file, equipment_id)
                else:
                    df = self.converter.convert(log_name, log_file, self.ctx['path'], self.ctx['id'], equipment_id, equipment_name)

                self.logger.info('convert| converted-data=%d' % (-1 if df is None else len(df)))

                if df is not None and len(df) > 0:
                    if log_name.lower() == 'error_log' or log_name.lower() == 'errorlog':
                        self.add_unit_rank(df)

                    if self.converter.insert_convert_df(log_name, df):
                        converted_log_file.append(log_file)
                        if log_name.lower() == 'running':
                            error_df = ErrorSummary(config_of(env.LOG_MONITOR_DB)).summary(log_file, equipment_id)
                            self.logger.info('error summary| data_len=%d'
                                              % (-1 if error_df is None else len(error_df)))
                            if error_df is not None and len(error_df) > 0:
                                self.insert_error_summary(error_df)
                    else:
                        raise StepError('insert| failed to insert log [%s]' % log_name)

            except StepIterationContinue as ex:
                self.logger.info('iteration cont. %s' % str(ex))
                continue

        # Clean up the converted logs
        for sub in os.listdir(env.PRIV_PATH):
            path = os.path.join(env.PRIV_PATH, sub)
            if os.path.isfile(path) or sub.find("collect_") != 0:
                continue

            if os.path.exists(path):
                for d in os.listdir(path):
                    d = os.path.join(path, d)
                    if os.path.isfile(d) or os.path.basename(d) == 'backup':
                        continue

                    self.logger.info('wrap-up| delete files in %s directory' % os.path.basename(d))
                    self.delete_all_in_dir(d, converted_log_file)

        self.change_status('success')

    def get_log_file_information(self, log_file):
        try:
            equipment_df = self.get_equipment_df()
            equipment_list = equipment_df['machineName'].to_list()
            if len(equipment_list) == 0:
                raise StepError('get_log_file_information| empty equipment list in rapid-collector')

            dirname_list = os.path.dirname(log_file).split(os.sep)
            for i in reversed(range(len(dirname_list))):
                if dirname_list[i] in equipment_list:
                    eqp = dirname_list[i]
                    log = dirname_list[i+1]
                    break

                r = re.search(r'[^_]+_(\w+)_\d{8}_\d{6}', dirname_list[i])
                if r is None:
                    continue

                val = r.group(1)
                if 'ALL' in val:
                    # It means an equipment name is the next of this path value.
                    eqp = dirname_list[i+1]
                    log = dirname_list[i+2]
                else:
                    # In this case, val is an equipment name, the next of this path is a log name.
                    for _eqp in equipment_list:
                        if _eqp in val:
                            eqp = _eqp
                            break
                    log = dirname_list[i + 1]

                if eqp is not None and log is not None:
                    break

            else:
                raise StepError('get_log_file_information| failed to determine equipment or log_name')

            fab = self.get_fab_from_equipment(eqp)
            equipment_id = self.get_equipment_id_from_equipment(eqp)
            if fab is not None:
                repr_log = self.converter.determine_log_name(log)
                if repr_log is not None:
                    # Success
                    return fab, '%s_%s_%s' % (self.username, fab, eqp), repr_log, equipment_id
                else:
                    self.logger.warn('cannot find representative log name for %s' % log)
            else:
                self.logger.warn('cannot find fab for %s' % eqp)
        except IndexError:
            pass
        raise StepIterationContinue('cannot find log information from %s' % log_file)

    def get_fab_from_equipment(self, equipment):
        if self.equipment_list is None:
            self.equipment_list = self.get_equipment_df()
        return next((self.equipment_list['fab_name'].values[i] for i in range(len(self.equipment_list)) if self.equipment_list['machineName'].values[i] == equipment), None)

    def get_equipment_id_from_equipment(self, equipment):
        if self.equipment_list is None:
            self.equipment_list = self.get_equipment_df()
        return next((self.equipment_list['equipment_id'].values[i] for i in range(len(self.equipment_list)) if self.equipment_list['machineName'].values[i] == equipment), None)

    def init_converter_module(self):
        self.logger.debug('init_converter_module| initialize converter')
        monitor_db = config_of(env.LOG_MONITOR_DB)
        convert_db = {**env.CONFIG_CONVERT_DB}
        self.logger.debug('init_converter_module| monitor-db=%s convert-db=%s'
                          % (monitor_db['host'], convert_db['host']))
        self.converter = LogConvert(logger=self.logger)
        self.converter.set_db_config(**monitor_db)
        self.converter.set_convert_db(**convert_db)

    def insert_error_summary(self, error_df):
        if error_df is None or len(error_df) == 0:
            return

        error_df['elapsed'] = error_df['elapsed'].replace({np.nan: '00:00:00'})

        self.logger.info('insert_error_summary| data_len=%d' % (-1 if error_df is None else len(error_df)))
        with ConvertDatabaseConnector() as (conn, cur):
            for item_index in error_df.index:
                item = error_df.loc[item_index]
                sql = f"insert into {env.CONFIG_CONVERT_DB['schema']}.error_summary \
                (equipment_id, log_date, error_no, error_name, elapsed, error_rank, error_count, error_category) \
                values \
                ('{item['equipment_id']}', '{item['log_date']}', '{item['error_no']}', '{item['error_name']}',\
                '{item['elapsed']}', '{item['error_rank']}', {item['error_count']}, '{item['error_category']}')"
                try:
                    cur.execute(sql)
                except psycopg2.Error as ex:
                    if ex.pgcode == '23505':  # Unique-Violation error
                        self.logger.warn('insert_error_summary| unique-violation: %s' % (str(ex).replace('\n', '\t')))
                        conn.rollback()
                        continue
                    elif ex.pgcode == '23502':  # NotNull-Violation error
                        self.logger.warn('insert_error_summary| notnull-violation: %s' % (str(ex).replace('\n', '\t')))
                        conn.rollback()
                        continue
                    raise

    def delete_all_in_dir(self, path, converted_log_file):
        if os.path.exists(path):
            for f in os.listdir(path):
                f_path = os.path.join(path, f)
                converted = False
                for log_file in converted_log_file:
                    if log_file.find(f_path) == 0:
                        converted = True
                        break
                if converted is False:
                    continue
                if os.path.isfile(f_path):
                    os.remove(f_path)
                else:
                    shutil.rmtree(f_path)

    def add_unit_rank(self, error_log):
        if error_log is not None and len(error_log) > 0:
            unit_list = error_log['error_code'].str.get(i=0).tolist()
            rank_list = error_log['error_code'].str.get(i=1).tolist()
            conv_unit_list = self.conv_unit(unit_list)
            conv_rank_list = self.conv_rank(rank_list)
            error_log['unit'] = conv_unit_list
            error_log['rank'] = conv_rank_list

    def conv_unit(self, unit_list):
        conv_unit_list = []
        for val in unit_list:
            unit = val.upper()
            if unit == '0':
                conv_unit_list.append('CONSOLE')
            elif unit == '1' or unit == 'A':
                conv_unit_list.append('MAIN')
            elif unit == '2' or unit == 'B':
                conv_unit_list.append('SCAN')
            elif unit == '3' or unit == 'C':
                conv_unit_list.append('PERL')
            else:
                conv_unit_list.append('Unknown')
        return conv_unit_list

    def conv_rank(self, rank_list):
        conv_rank_list = []
        for rank in rank_list:
            if rank == '0' or rank == '1':
                conv_rank_list.append('A')
            elif rank == '2' or rank == '3':
                conv_rank_list.append('B/D')
            elif rank == '4' or rank == '5':
                conv_rank_list.append('C')
            else:
                conv_rank_list.append('Unknown')
        return conv_rank_list
