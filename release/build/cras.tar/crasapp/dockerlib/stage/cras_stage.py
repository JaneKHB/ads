import os
import datetime
import time
import traceback

import env
import extlogger as lo
from logutil import config_of
from stepexception import StepError, StepSuccess, StepNoData
from stage.step_service import StepService
from dockerservice.cras.service_process_cras import ProcessCras


class CrasStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.username = config_of(env.USERNAME)
        self.logger = lo.gger

    def step_start(self):
        # Get equipment and fab information
        equipment_df = self.get_equipment_df()
        fab_list = equipment_df.drop_duplicates(['fab_name'])['fab_name'].tolist()
        self.logger.info('fab_list=%s' % ','.join(fab_list))

        # Create output directory
        output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'])
        if not os.path.exists(output_path):
            os.mkdir(output_path)

        # Check if rule information valid
        if 'rule' not in self.ctx or len(self.ctx['rule']) == 0:
            raise StepError('invalid rule parameter')
        self.logger.info('rule_list=%s' % str(self.ctx['rule']))

        # Execute cras
        do = ProcessCras(self.username, equipment_df, output_path, fab_list, self.ctx['period'],
                         self.ctx['password'], self.ctx['rule'])

        ret = do.execute_cras()
        if ret:
            self.logger.info('start compressing result.')
            today = datetime.datetime.today().strftime('%Y%m%d')

            cras_report_zip_path = os.path.join(output_path, f'CRAS_Report_{self.username}_{today}.zip')
            cras_report_zip = do.create_zipfile(cras_report_zip_path)

            cras_data_zip_path = os.path.join(output_path, f'CRASDATA_{self.username}_{today}.zip')
            cras_data_zip = do.create_zipfile(cras_data_zip_path)

            judge_result_zip_path = os.path.join(output_path, f'JudgeResult_{self.username}_{today}.zip')
            judge_result_zip = do.create_zipfile(judge_result_zip_path)

            check_list = [cras_report_zip, cras_data_zip, judge_result_zip]

            if '' in check_list:
                raise StepError("failed to compress result")

            wait = 60
            while wait > 0:
                time.sleep(1)
                for check in check_list:
                    if os.path.exists(check):
                        self.logger.info(f'{check} compressed')
                        check_list.remove(check)
                if len(check_list) == 0:
                    break
                wait -= 1
                self.logger.info(f"waiting compression.. {wait}")
            else:
                raise StepError("""compressing timeout
                            [%s] files weren't ready.
                            """ % ','.join(check_list))

        self.change_status('success')
