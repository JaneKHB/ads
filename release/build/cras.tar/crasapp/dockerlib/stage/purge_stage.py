import env
import extlogger as lo
from convert.convert import LogConvert
from logutil import config_of
from stage.step_service import StepService
from stepexception import StepSuccess, StepError


class PurgeStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.logger = lo.gger
        self.username = config_of(env.USERNAME)
        self.converter = None
        self.equipment_list = None
        convert_set = env.CONFIG_CONVERT_DB
        self.schema = convert_set['schema']

    def step_start(self):
        # Initialize a convert module
        self.init_converter_module()

        # List the equipments
        equipment_df = self.get_equipment_df()
        equipment_list = equipment_df['equipment_id'].to_list()

        if len(equipment_list) == 0:
            raise StepError('no equipment information')

        self.logger.info('%d equipments found' % len(equipment_list))

        # Purge
        self.converter.purge_convert_data(equipment_list)

        self.change_status('success')

    def init_converter_module(self):
        self.logger.debug('init_converter_module| initialize converter')
        monitor_db = config_of(env.LOG_MONITOR_DB)
        convert_db = env.CONFIG_CONVERT_DB
        self.logger.debug('init_converter_module| monitor-db=%s convert-db=%s'
                          % (monitor_db['host'], convert_db['host']))
        self.converter = LogConvert(logger=self.logger)
        self.converter.set_db_config(**monitor_db)
        self.converter.set_convert_db(**convert_db)
