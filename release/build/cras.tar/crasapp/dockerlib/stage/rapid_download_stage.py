import os

import env
import extlogger as lo
from logutil import config_of
from rapid import RapidConnector
from stepexception import StepNoData, StepError, StepSuccess
from stage.step_service import StepService


class RapidDownloadStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.logger = lo.gger
        self.username = config_of(env.USERNAME)

    def step_start(self):
        # Download user-specific logs
        self.logger.info('rapid download logs')
        ftp_type = self.ctx['ftp_type']
        if ftp_type == 'ftp':
            log_zip_path = self.ftp_download()
        elif ftp_type == 'vftp_compat':
            log_zip_path = self.vftp_compat_download()
        elif ftp_type == 'vftp_sss':
            log_zip_path = self.vftp_sss_download()
        else:
            raise StepError('unsupported ftp type')
        print(log_zip_path)


        self.change_status('success')

    def ftp_download(self):
        rapid = RapidConnector()

        file_list = self.ctx['lists']
        if file_list is None:
            raise StepError('failed to search file')

        if len(file_list) == 0:
            raise StepNoData('no search result')

        payload = {'lists': file_list}
        download_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}

        # Create output directory using pid
        output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'])

        file_path = rapid.download_request(download_req_info, output_path)

        if not os.path.exists(file_path):
            raise StepError('failed to download file')

        return file_path

    def vftp_compat_download(self):
        rapid = RapidConnector()

        if 'command' not in self.ctx:
            raise StepError('no command parameter')
        if len(self.ctx['command']) == 0:
            raise StepError('empty command not allowed')

        # Create machine and fab information
        machine_list = self.get_equipment_df()

        machine_name_list = list()
        fab_name_list = list()
        for eq in self.ctx['machine']:
            m = machine_list[machine_list['equipment_name'] == eq]
            if m is None or len(m) == 0:
                raise StepError('cannot find a machine %s' % eq)
            m = m.iloc[0].to_dict()
            machine_name_list.append(m['machineName'])
            fab_name_list.append(m['fab_name'])

        # download
        download_cmd = self.ctx['command'][0].split()[-1].strip()
        payload = {'command': download_cmd,
                   'fabNames': fab_name_list,
                   'machineNames': machine_name_list}
        download_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}
        try:
            # Create output directory using pid
            output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'])

            file_path = rapid.download_request(download_req_info, output_path)
        except Exception as ex:
            raise StepSuccess(ex)

        if not os.path.exists(file_path):
            raise StepError('failed to download file')

        return file_path

    def vftp_sss_download(self):
        rapid = RapidConnector()

        file_list = self.ctx['lists']
        if file_list is None:
            raise StepError('failed to search file')

        if len(file_list) == 0:
            raise StepNoData('no search result')

        payload = {'lists': file_list}
        download_req_info = {'ftp_type': self.ctx['ftp_type'], 'payload': payload}

        # Create output directory using pid
        output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'])

        file_path = rapid.download_request(download_req_info, output_path)

        if not os.path.exists(file_path):
            raise StepError('failed to download file')

        return file_path
