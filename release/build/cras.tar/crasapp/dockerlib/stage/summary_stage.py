import os
import subprocess
import traceback

import env
import extlogger as lo
import logutil
import rapid
from dockerservice.summary.error_summary_mail_html import create_html_body, create_html
from dockerservice.summary.service_error_summary import ErrorSummary
from logutil import config_of
from stepexception import StepError, StepNoData
from stage.step_service import StepService


class SummaryStage(StepService):

    def __init__(self, ctx):
        self.ctx = ctx
        self.username = config_of(env.USERNAME)
        self.logger = lo.gger

    def step_start(self):
        # Get equipment and fab information
        equipment_df = self.get_equipment_df()
        fab_list = equipment_df.drop_duplicates(['fab_name'])['fab_name'].tolist()
        self.logger.info('fab_list=%s' % ','.join(fab_list))

        # Create output directory using pid
        output_path = os.path.join(env.PRIV_PATH, self.ctx['step'], self.ctx['id'])
        os.mkdir(output_path)

        # Create reports for each fab
        do = ErrorSummary(self.username, equipment_df)
        excel_list = list()
        html_list = list()
        for fab in fab_list:
            self.logger.info('create summary report for fab %s' % fab)
            output_excel = os.path.join(output_path, f'error_summary_{fab}.xlsx')
            output = do.create_summary_df(output_excel, self.ctx['period'], fab)
            # Check empty output
            if os.path.exists(output_excel):
                if output is None or len(output) == 0:
                    os.remove(output_excel)
                else:
                    # Create an error summary html file
                    html = create_html_body(output,
                                            f'Error Summary For {fab}',
                                            '',
                                            self.username, fab, equipment_df)
                    html_list.append(html)
                    excel_list.append(output_excel)
                    self.logger.info('success to create a report for fab %s' % fab)
                    continue
            self.logger.info('failed to create a report for fab %s' % fab)

        if len(excel_list) == 0:
            raise StepNoData('no date to report')

        output_html = os.path.join(output_path, f'error_summary.html')
        html = create_html(html_list, output_html)

        self.logger.info('total %d reports created' % len(excel_list))

        zip_file = self.zip_files(output_path, excel_list)
        if not os.path.exists(zip_file):
            raise StepError('failed to create a zip')

        self.change_status('success')

    def zip_files(self, zip_root, file_list):
        zip_name = 'error_summary.zip'
        if not os.path.exists(zip_root) or os.path.isfile(zip_root):
            raise StepError('zip_files failed. invalid zip_root %s' % zip_root)
        if file_list is None or len(file_list) == 0:
            raise StepError('zip_files failed. empty file_list')
        arg = f"-P {self.ctx['password']}"

        diff_list = [os.path.relpath(f, zip_root) for f in file_list if os.path.exists(f)]
        subprocess.call(f"cd {zip_root}; {env.ZIP_EXEC} {arg} {zip_name} {' '.join(diff_list)};", shell=True)
        # subprocess.call(f"cd {zip_root} & /7z {arg} {zip_name} {' '.join(diff_list)};", shell=True)
        return os.path.join(zip_root, zip_name)
