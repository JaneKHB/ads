import os
import importlib
import traceback

import env
import step
import rapid
import pandas as pd
from dbconnector import PostgresConnector
from stepexception import StepError, StepNoData, StepSuccess
from logutil import config_of

class StepService:

    ctx = None
    logger = None
    equipment_df = None

    class Next(Exception):
        pass

    def start(self):
        try:
            self.containerized()

            # Invoke respective step process
            self.step_start()

        except StepSuccess as ex:
            self.logger.info(str(ex))
            self.change_status('success')
        except StepError as ex:
            self.logger.error(str(ex))
            self.change_status('error')
        except StepNoData as ex:
            self.logger.info(str(ex))
            self.change_status('nodata')
        except Exception as ex:
            self.logger.error('unexpected exception occurs. msg=%s' % str(ex))
            self.logger.debug(traceback.format_exc())
            self.change_status('error')
        finally:
            self.decontainerized()

    def containerized(self):
        self.logger.info('process start')
        self.logger.info(f"client={self.ctx['client']} id={self.ctx['id']} step={self.ctx['step']}")
        self.change_status('running')

    def decontainerized(self):
        p = self.get_status()
        if p['status'] not in ['success', 'error', 'nodata']:
            self.logger.error('process has been unexpected exited')
            self.change_status('error')
        self.logger.info('process finish')

    def change_status(self, status):
        pid = self.get_pid()
        with PostgresConnector(env.CONFIG_DB, to_dict=True) as (con, cur):
            cur.execute("update cnvset.step_process set status = '%s' where id = '%s' returning *" %
                        (status, pid))
            p = cur.fetchone()
            if p is None:
                raise StepError('change_status failed. invalid id %s' % pid)
            return dict(p)

    def get_status(self):
        pid = self.get_pid()
        with PostgresConnector(env.CONFIG_DB, to_dict=True) as (con, cur):
            cur.execute("select * from cnvset.step_process where id = '%s' limit 1" % pid)
            p = cur.fetchone()
            return dict(p)

    def get_pid(self):
        if self.ctx is None or 'id' not in self.ctx or self.ctx['id'] == '':
            raise RuntimeError('[change_status] invalid process-id')
        return self.ctx['id']

    def get_equipment_df(self):
        if self.equipment_df is None:
            with PostgresConnector({**env.CONFIG_DB}, to_dict=True) as (con, cur):
                query = "select * from cras_db.equipments where user_name = '%s'" % self.username
                equipment_df = pd.read_sql(query, con)
                if equipment_df is None:
                    raise RuntimeWarning(f'get_equipment_df| empty data (username=%s )from equipment table' % self.username)
                equipment_df = equipment_df.rename(columns={
                    'machinename': 'machineName',
                    'tootype': 'tooType'
                })
                self.equipment_df = equipment_df
        return self.equipment_df
