import os
import zipfile
import json
import psycopg2 as pg2

import env


def config_of(key):
    try:
        with pg2.connect(**env.CONFIG_DB) as con:
            with con.cursor() as cur:
                cur.execute("select * from cnvset.server_config where key = '%s' limit 1" % key)
                ret = cur.fetchone()[1]
                try:
                    # When decoding failed, it's not json type value.
                    return json.loads(ret)
                except json.decoder.JSONDecodeError:
                    pass
                return ret

    except Exception as ex:
        raise RuntimeError('config_of(%s) failed.\r\n%s' % (key, str(ex)))


def get_collected_log_list():
    ret = list()

    for sub in os.listdir(env.PRIV_PATH):
        path = os.path.join(env.PRIV_PATH, sub)
        if os.path.isfile(path) or sub.find("collect_") != 0:
            continue

        if not os.path.exists(path):
            return ret
        for plan in os.listdir(path):
            plan = os.path.join(path, plan)
            if os.path.isfile(plan) or os.path.basename(plan) == 'backup':
                continue
            for (root, dirs, logs) in os.walk(plan):
                if len(logs) > 0:
                    ret += [os.path.join(root, l) for l in logs]
    return ret


def unzip_r(file, dest):
    path = os.path.abspath(file)
    unzip_dest = os.path.join(dest, os.path.basename(file).replace('.zip', ''))
    root_dir = unzip(path, unzip_dest)

    def recursive(parent_dir):
        if os.path.isfile(parent_dir):
            return
        for _child in os.listdir(parent_dir):
            child = os.path.join(parent_dir, _child)
            if os.path.isfile(child):
                if zipfile.is_zipfile(child):
                    child_dir = unzip(child)
                    recursive(child_dir)
                    os.remove(child)
                else:
                    recursive(child)
            else:
                recursive(child)

    recursive(root_dir)
    return unzip_dest


def unzip(zip_file, dest=None):
    dest_dir = dest
    if dest_dir is None:
        _dest = os.path.splitext(os.path.basename(zip_file))[0]
        dest_dir = os.path.join(os.path.dirname(zip_file), _dest)

    # print('dest_dir=%s' % dest_dir)
    zf = zipfile.ZipFile(zip_file)
    zf.extractall(dest_dir)
    zf.close()
    return dest_dir
