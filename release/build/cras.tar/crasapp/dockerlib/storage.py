import os
import json
import env


def __preprocess(func):
    def __wrapper(*args, **kwargs):
        if not os.path.exists(env.STORAGE_FILE):
            f = open(env.STORAGE_FILE, 'w', encoding='utf-8')
            f.write('{}')
            f.close()
        return func(*args, **kwargs)
    return __wrapper


@__preprocess
def __get_data():
    with open(env.STORAGE_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)
    return {}


@__preprocess
def __set_data(data):
    with open(env.STORAGE_FILE, 'w', encoding='utf-8') as f:
        f.write(json.dumps(data))


def getv(key, default=None):
    data = __get_data()
    if key not in data:
        data[key] = default if default is not None else ''
    return data[key]


def setv(key, value):
    data = __get_data()
    data[key] = value
    __set_data(data)
