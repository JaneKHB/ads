import os
import json
import psycopg2 as pg2
import psycopg2.extras
from logutil import config_of

import env


class PostgresConnector:

    connect = None
    cursor = None
    config = None
    to_dict = False

    def __init__(self, config, to_dict=False):
        self.config = config
        self.to_dict = to_dict

    def __enter__(self):
        try:
            self.connect = pg2.connect(host=self.config['host'],
                                       port=self.config['port'],
                                       dbname=self.config['dbname'],
                                       user=self.config['user'],
                                       password=self.config['password'])
            self.connect.autocommit = True
            if self.to_dict:
                self.cursor = self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor)
            else:
                self.cursor = self.connect.cursor()
            return self.connect, self.cursor
        except Exception as ex:
            raise RuntimeError('[PostgresConnector] failed to connect to host %s.\r\n%s' % (self.config['host'], str(ex)))

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connect is not None and self.cursor is not None:
            self.connect.commit()
            self.cursor.close()
            self.connect.close()


class ConvertDatabaseConnector(PostgresConnector):
    def __init__(self, to_dict=False):
        config = {**env.CONFIG_CONVERT_DB}
        self.schema = config['schema']
        super().__init__(config, to_dict=to_dict)


class SettingDatabaseConnector(PostgresConnector):
    """
    `SettingDatabaseConnector` creates a connector for legacy database that has user configurable settings.
    If you have to create a new table, you should use `UserDatabaseConnector` because this database might be deprecated.
    """
    def __init__(self, to_dict=False):
        config = config_of(env.SETTING_DB)
        self.schema = config['schema']
        super().__init__(config, to_dict=to_dict)


class UserDatabaseConnector(PostgresConnector):
    """
    `UserDatabaseConnector` creates a connector for database that has user configurable settings.
    """
    def __init__(self, to_dict=False):
        config = {**env.CONFIG_DB}
        self.schema = 'userdata'
        super().__init__(config, to_dict=to_dict)
