import os
import re
import json
import time

import requests
import pandas as pd

import env
from logutil import config_of
import extlogger as lo


class RapidConnector:
    access_token = ''

    def __init__(self):
        self.config = config_of(env.RAPID_COLLECTOR)

    def get_access_token(self):
        try:
            url = self.create_request_url() + '/rss/api/auths/login'
            url = url + '?username=%s&password=%s' % (self.config['user'], self.config['password'])
            response = requests.get(url)
            if response.status_code == 200:
                body = json.loads(response.text)
                if 'accessToken' in body:
                    self.access_token = body['accessToken']
                    return True
                elif 'refreshToken' in body:
                    url = self.create_request_url() + '/rss/api/auths/token'
                    response = requests.post(url, data={'refreshToken': body['refreshToken']})
                    if response.status_code == 200:
                        body = json.loads(response)
                        if 'accessToken' in body:
                            self.access_token = body['accessToken']
                            return True
            lo.gger.warn('failed to login and get access token (code=%d)' % response.status_code)
        except Exception as msg:
            lo.gger.warn(f'connection failed. {msg}')
            raise RuntimeError('access token error')
        return False

    def get_plan(self):
        return self.io_bus(self._get_plan, {})

    def get_download_list(self, plan_id):
        return self.io_bus(self._get_download_list, {'plan_id': plan_id})

    def download_file(self, url, dest):
        return self.io_bus(self._download_file, {'url': url, 'dest': dest})

    def get_machines(self):
        return self.io_bus(self._get_machines, {})

    def get_categories(self):
        return self.io_bus(self._get_categories, {})

    def get_command(self, ftp_type):
        return self.io_bus(self._get_command, {'ftp_type': ftp_type})

    def search(self, searchReqInfo):
        if searchReqInfo['ftp_type'] == 'ftp':
            request_url = self.create_request_url() + '/rss/api/ftp/search'
        elif searchReqInfo['ftp_type'] == 'vftp_sss':
            request_url = self.create_request_url() + '/rss/api/vftp/sss/search'
        else:  # ftp
            request_url = self.create_request_url() + '/rss/api/ftp/search'

        return self.io_bus(self._search, {'request_url': request_url, 'payload': searchReqInfo['payload']})

    def download_request(self, downloadReqInfo, dest):
        if downloadReqInfo['ftp_type'] == 'ftp':
            request_url = self.create_request_url() + '/rss/api/ftp/download'
        elif downloadReqInfo['ftp_type'] == 'vftp_compat':
            request_url = self.create_request_url() + '/rss/api/vftp/compat/download'
        elif downloadReqInfo['ftp_type'] == 'vftp_sss':
            request_url = self.create_request_url() + '/rss/api/vftp/sss/download'
        else:  # ftp
            request_url = self.create_request_url() + '/rss/api/ftp/download'
        return self.io_bus(self._download_request, {'request_url': request_url, 'payload': downloadReqInfo['payload'], 'dest': dest})

    def me(self):
        return self.io_bus(self._me, {})

    def _get_plan(self):
        lo.gger.debug('get_plan')
        header = self.create_request_header()
        url = self.create_request_url() + '/rss/api/plans'
        response = requests.get(url, headers=header)
        if response.status_code != 200:
            lo.gger.warn('failed to get plan list (response=%d)' % response.status_code)
            return None
        body = json.loads(response.text)
        return body['lists']

    def _get_download_list(self, plan_id):
        lo.gger.debug('get_download_list')
        header = self.create_request_header()
        url = self.create_request_url() + f"/rss/api/plans/{plan_id}/filelists"
        response = requests.get(url, headers=header)
        if response.status_code != 200:
            lo.gger.warn(f'failed to get file list code={response.status_code}')
            return None
        body = json.loads(response.text)
        if 'lists' not in body:
            return None
        return body['lists']

    def _download_file(self, url, dest):
        lo.gger.debug(f'download_file url={url} dest={dest}')
        header = self.create_request_header()
        url = self.create_request_url() + url
        with requests.get(url, headers=header, stream=True) as response:
            if response.status_code != 200:
                lo.gger.warn(f'failed to download file ({url})')
                return None

            # Get file name
            if 'Content-Disposition' not in response.headers:
                lo.gger.warn("not enough header 'Content-Disposition'")
                return None
            filename = re.findall('filename=(.+)', response.headers['Content-Disposition'])[0]
            filename = filename.replace('"', '')
            if len(filename) == 0:
                lo.gger.warn("no file name in response header")
                return None

            # Store a file
            file_dest = os.path.join(dest, filename)
            with open(file_dest, 'wb') as f:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        f.write(chunk)

            return os.path.abspath(file_dest)
        lo.gger.warn(f'failed to request url {url}')
        return None

    def _get_machines(self):
        lo.gger.debug('get_machines(host=%s)' % self.config['host'])
        header = self.create_request_header()
        url = self.create_request_url() + '/rss/api/system/machinesInfo'
        response = requests.get(url, headers=header)
        if response.status_code != 200:
            lo.gger.warn(f'failed to get machines code={response.status_code}')
            return None
        body = json.loads(response.text)

        # 2021-11-25 Ted  If a fab name(line) consists of the format 'AAA-BBB',
        # it considers 'BBB' as the fab name, and 'AAA' means an user name.
        machine_list = [{**m, 'line': m['line'] if '-' not in m['line'] else m['line'].split('-')[-1]}
                        for m in body['lists'] if m['ots'] is not None]

        return machine_list

    def _get_categories(self):
        lo.gger.debug('get_categories')
        header = self.create_request_header()
        url = self.create_request_url() + '/rss/api/system/categoryInfo'
        response = requests.get(url, headers=header)
        if response.status_code != 200:
            lo.gger.warn(f'failed to get category code={response.status_code}')
            return None
        body = json.loads(response.text)
        return body['lists']

    def _search(self, request_url, payload):
        lo.gger.debug('search')
        header = self.create_request_header(app_json=True)
        url = request_url
        response = requests.post(url, headers=header, data=json.dumps(payload))
        if response.status_code != 200:
            lo.gger.warn(f'failed to post search code={response.status_code}')
            return None
        sid = json.loads(response.text)['searchId']

        url += '/%s' % sid
        while True:
            time.sleep(0.5)
            response = requests.get(url, headers=header)
            if response.status_code != 200:
                lo.gger.warn(f'failed to get search information={response.status_code}')
                return None
            data = json.loads(response.text)
            if data['status'] != 'in-progress':
                break

        if 'resultUrl' not in data:
            lo.gger.warn(f"search finished with error status={data['status']}")
            return None

        url = self.create_request_url() + data['resultUrl']
        response = requests.get(url, headers=header)
        if response.status_code != 200:
            lo.gger.warn(f'failed to get search result={url}')
            return None

        return json.loads(response.text)['lists']

    def _download_request(self, request_url, payload, dest):
        lo.gger.debug('download_request')
        header = self.create_request_header(app_json=True)
        url = request_url

        response = requests.post(url, headers=header, data=json.dumps(payload))
        if response.status_code != 200:
            lo.gger.warn(f'failed to request download={response.status_code}')
            return None
        did = json.loads(response.text)['downloadId']

        url += '/%s' % did
        while True:
            time.sleep(0.5)
            response = requests.get(url, headers=header)
            if response.status_code != 200:
                lo.gger.warn(f'failed to get download information={response.status_code}')
                return None
            data = json.loads(response.text)
            if data['status'] == 'error':
                lo.gger.warn('download finished with error status')
                return None
            elif data['status'] == 'done':
                break

        if 'downloadUrl' not in data or data['downloadUrl'] == '':
            lo.gger.warn('empty download url', data['downloadUrl'])
            return None

        url = self.create_request_url() + data['downloadUrl']
        with requests.get(url, headers=header, stream=True) as response:
            if response.status_code != 200:
                lo.gger.warn('failed to download files', url, response.status_code)
                return None
            filename = re.findall('filename=(.+)', response.headers['Content-Disposition'])[0]
            filename = filename.replace('"', '')
            if len(filename) == 0:
                lo.gger.warn("no file name in response header")
                return None

            file_dest = os.path.join(dest, filename)
            with open(file_dest, 'wb') as f:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        f.write(chunk)

            return os.path.abspath(file_dest)

        lo.gger.warn(f'failed to open file stream={url}')
        return None

    def _me(self):
        lo.gger.debug('me')
        header = self.create_request_header()
        url = self.create_request_url() + '/rss/api/auths/me'
        response = requests.get(url, headers=header)
        if response.status_code == 200:
            return False
        return True

    def io_bus(self, func, args):
        while True:
            try:
                if self.access_token is None or self.access_token == '':
                    raise GetAccessToken()
                return func(**args)
            except GetAccessToken:
                self.get_access_token()
                if self.access_token is None or self.access_token == '':
                    return None

    def create_request_header(self, app_json=False):
        if self.access_token is None or self.access_token == '':
            lo.gger.warn('no access_token in context')
        headers = {'Authorization': 'Bearer ' + self.access_token}
        if app_json:
            headers['Content-Type'] = 'application/json'
        return headers

    def create_request_url(self):
        return 'http://%s:%d' % (self.config['host'], self.config['port'])

    """
    Convert machine list which got from 'self.get_machines' to dataframe.
    """

    def machines_to_df(self, equipments: list, user=None):
        if equipments is None or len(equipments) == 0:
            return None
        df = pd.DataFrame(columns=equipments[0].keys())
        for eqp in equipments:
            if eqp['ots'] is not None:
                df = df.append(eqp, ignore_index=True)

        df = df.drop(['ots', 'ftpUser', 'ftpPassword', 'vftpUser', 'vftpPassword', 'ftpConnected', 'vftpConnected',
                      'host', 'port'], axis=1)

        df = df.rename(columns={
            'line': 'fab_name',
            'serialNumber': 'tool_serial'
        })

        df['tool_id'] = df.apply(lambda elem: elem['machineName'].split('_')[0], axis=1)
        df['inner_tool_id'] = df.apply(lambda elem: elem['machineName'].split('_')[1], axis=1)

        if user is not None:
            df['user_name'] = user
            df['equipment_name'] = df.apply(lambda elem: f"{user}_{elem['fab_name']}_{elem['machineName']}", axis=1)
        return df

    def get_fab_list(self):
        equipment_list = self.get_machines()
        fab_list = list()
        if equipment_list is not None:
            for eqp in equipment_list:
                if eqp['line'] not in fab_list:
                    fab_list.append(eqp['line'])
        return fab_list

    def _get_command(self, ftp_type):
        lo.gger.debug('get_command type : ' + ftp_type)
        header = self.create_request_header()
        url = self.create_request_url() + '/rss/api/vftp/command'
        query = {'type': ftp_type}
        response = requests.get(url, params=query, headers=header)
        if response.status_code != 200:
            lo.gger.warn(f'failed to get command={response.status_code}')
            return None
        body = json.loads(response.text)
        return body['lists']


class GetAccessToken(Exception):
    pass
