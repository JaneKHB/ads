import psycopg2 as pg2
import psycopg2.extras
import inspect

import config.app_config as _config


def connector(func):
    def _wrapper(*args, **kwargs):
        with pg2.connect(**_config.CRAS_DB) as c:
            with c.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                arg_list = [sign for sign in inspect.signature(func).parameters]
                if len(args) > 1:
                    for i in range(1, len(args)):
                        kwargs[arg_list[i]] = args[i]
                if 'conn' in arg_list:
                    kwargs['conn'] = c
                if 'cur' in arg_list:
                    kwargs['cur'] = cur
                return func(*[args[0]], **kwargs)
        raise RuntimeWarning('failed to connect db')
    return _wrapper


class SystemLoggerDao:

    def __init__(self):
        self.config = _config.CRAS_DB

    @connector
    def get_log_by_id(self, rid, cur, after=0, limit=0):
        after_option = "" if after == 0 else f"and id > {after}"
        limit_option = "" if limit == 0 else f"limit {limit}"
        cur.execute(f"select * from cnvset.system_log where key like '%{rid}%'"
                    f" {after_option} order by id {limit_option}")
        ret = cur.fetchall()
        return [dict(r) for r in ret]

    @connector
    def get_error_log_by_id(self, rid, cur):
        cur.execute(f"select * from cnvset.system_log where key like '%{rid}%' and lower(lv) = 'error' order by ts desc")
        ret = cur.fetchall()
        return [dict(r) for r in ret]

    @connector
    def delete_log_by_id(self, rid, cur):
        cur.execute(f"delete from cnvset.system_log where key = '%s'" % rid)

