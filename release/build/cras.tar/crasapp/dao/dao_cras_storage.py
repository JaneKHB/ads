from io import StringIO
import pandas as pd
import pandas.io.sql as sqlio
import psycopg2 as pg2
import psycopg2.extras
import psycopg2.errors
from dao.exception import DatabaseQueryException
from convert.util import get_table_type_list


class CrasStorageDao:

    """
    ConvertDao is access object to connect cras-storage database.
    """

    def __init__(self, db_config):
        self.config = {**db_config}
        self.schema = self.config.pop('schema')

    def ___insert_df(self, table, df):
        table = f'{self.schema}.{table}'

        buffer = StringIO()

        if '' in df.columns:
            del df['']

        df['created_time'] = pd.Timestamp.now()

        # df.to_csv('test.csv', index=False, header=True)
        df.to_csv(buffer, index=False, header=False)
        buffer.seek(0)

        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                try:
                    cur.copy_from(buffer, table, sep=",", columns=df.columns, null='-99999999999999')
                except (Exception, pg2.DatabaseError) as error:
                    conn.rollback()
                    raise DatabaseQueryException(error)

    def count_row(self, table):
        with pg2.connect(**self.config) as connect:
            with connect.cursor() as cursor:
                cursor.execute(f'select count(*) from {self.schema}.{table}')
                return int(cursor.fetchone()[0])
        return 0

    def ___get_columns(self, table):
        table = table.split('.')[-1]
        with pg2.connect(**self.config) as connect:
            sql = "select * from information_schema.columns where table_name = '%s' and table_schema = '%s'" \
                  % (table, self.schema)
            df = sqlio.read_sql_query(sql, connect)
            return df['column_name'].tolist()

    def ___get_version_info_log_time(self, count=2):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    cursor.execute(f"select log_time from {self.schema}.version_info group by log_time \
                                        order by log_time desc limit {count}")
                    _ret = cursor.fetchall()
                    ret = [_[0] for _ in _ret]
                    return ret
        except Exception as msg:
            print(f'failed to get version info log time. {msg}')
        return None

    def get_version_info(self, date=None, df=False):
        try:
            with pg2.connect(**self.config) as connect:
                where_date = ''
                if date is not None:
                    where_date = f"where log_time = '{date}'"
                sql = f"select * from {self.schema}.version_info {where_date}"
                if df:
                    return pd.read_sql(sql, connect)
                else:
                    with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                        cursor.execute(sql)
                        _ret = cursor.fetchall()
                        ret = [dict(_) for _ in _ret]
                        return ret
        except Exception as msg:
            print(f'failed to get version info. {msg}')
        return None

    def get_log_info(self, table, equipment=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    sql_equipment = ''
                    if equipment is not None:
                        sql_equipment = f"where equipment_name='{equipment}'"
                    cursor.execute(f"select to_char(min(log_time), 'YYYY-MM-DD HH24:MI:SS') as start, \
                                        to_char(max(log_time), 'YYYY-MM-DD HH24:MI:SS') as end, count(*) \
                                        from {self.schema}.{table} {sql_equipment}")
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to get log info. {msg}')
        return None

    def get_converted_data(self, table, start, end, equipment=None):
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor() as cursor:
                    sql_interval = f"where log_time >= '{start}' and log_time <= '{end}'"
                    sql_equipment = ''
                    if equipment is not None:
                        sql_equipment = f"and equipment_name='{equipment}'"
                    buffer = StringIO()
                    sql = f"copy (select * from {self.schema}.{table} {sql_interval} {sql_equipment}) \
                            to stdout with csv header delimiter '\t' null as '-99999999999999'"
                    cursor.copy_expert(sql, buffer)
                    return buffer.getvalue()
        except Exception as msg:
            print(f'failed to get converted log. {msg}')
        return None

    def get_error_log(self, page, size, sort, order, search, filter):
        # WHERE文生成
        where_sql = self.make_where_sql_in_error_log(search, filter)

        order_sql = []
        if sort != 'occurred_date':
            tbl = 'err' if sort != 'equipment_name' else 'eqp'
            order_sql.append(f'{tbl}.{sort} {order}')
            order_sql.append('err.occurred_date desc')  # Default ordering
        else:
            order_sql.append(f'err.{sort} {order}')
        order_sql = f"order by {','.join(order_sql)}"

        page_sql = f'offset {page*size} limit {size}'

        sel_column_sql = self.get_error_log_column_sql()

        sql = f"select \
            concat(err.equipment_id, err.log_time, err.log_idx) as id, \
            err.equipment_id, \
            {sel_column_sql} \
            eqp.machinename as equipment_name \
            from cras_db.error_log err \
            left join cras_db.equipments eqp on err.equipment_id = eqp.equipment_id \
            {where_sql} {order_sql} {page_sql}"

        print('#               %s' % sql)

        with pg2.connect(**self.config) as con:
            with con.cursor() as cur:
                try:
                    cur.execute(f"select count(*) from cras_db.error_log err {where_sql}")
                    total = cur.fetchone()
                    df = pd.read_sql(sql, con)
                except Exception:
                    # empty data
                    total = (0,)
                    df = pd.DataFrame()

                return df, total[0] if total is not None and len(total)>0 else 0

    def get_error_log_column_sql(self):
        except_columns = ['equipment_id', 'log_time', 'log_idx', 'request_id', 'created_time']
        columns = get_table_type_list(self.config, self.schema, 'error_log')
        sql = ''
        for col in columns:
            if col[0] not in except_columns:
                if 'timestamp' in col[1]:
                    sql += 'to_char(err.' + col[0] + ", 'YYYY-MM-DD HH24:MI:SS') as " + col[0] + ', '
                else:
                    sql += 'err.' + col[0] + ', '
        return sql

    def get_equipment_by_id(self, equipment_id: list):
        if equipment_id is None or len(equipment_id)==0:
            return None

        where_in = ','.join([f"'{e}'" for e in equipment_id])

        with pg2.connect(**self.config) as con:
            with con.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                try:
                    cur.execute(f"select * from cras_db.equipments where equipment_id in ({where_in})")
                    return [dict(_) for _ in cur.fetchall()]
                except Exception as ex:
                    print(f"get_equipment_by_id() query failed {ex}")
        return None

    def make_where_sql_in_error_log(self, search, filter):
        where_sql = []
        # search Where文生成
        sub_sql = self.make_where_sql_search(search)
        where_sql += sub_sql

        # filter Where文生成
        sub_sql = self.make_where_sql_filter(filter)
        where_sql += sub_sql

        if len(where_sql) == 0:
            where_sql = ''
        else:
            where_sql = f"where {' and '.join(where_sql)}"
        return where_sql

    def make_where_sql_error_code(self, key, error_code):
        range_arr = error_code.split('-')
        if len(range_arr) == 2:
            sql = f"UPPER(err.{key}) between UPPER('{range_arr[0]}') and UPPER('{range_arr[1]}')"
        elif len(range_arr) == 1:
            sql = self.make_where_sql(key, range_arr[0])
        else:
            sql = ''
        return sql

    def make_where_sql_equip_name(self, equip_name):
        equip_name = equip_name.replace('_', '\_')
        equip_name = equip_name.replace('%', '\%')
        where = f"where machineName ilike '%{equip_name}%'"
        if '*' in equip_name:
            equip_name = equip_name.replace('*', '%')
            where = f"where machineName ilike '{equip_name}'"

        with pg2.connect(**self.config) as con:
            try:
                equipments = pd.read_sql(f"select * from cras_db.equipments {where}", con)
            except Exception:
                equipments = pd.DataFrame()

        if equipments is not None and len(equipments) > 0:
            equip_id_list = equipments['equipment_id'].drop_duplicates().tolist()
            sql = "err.equipment_id in (%s)" % ','.join([f'\'{e}\'' for e in equip_id_list])
        else:
            sql = 'FALSE'
        return sql

    def make_where_sql_search(self, search):
        where_sql = []
        for search_param in search:
            key = search_param.split(',', maxsplit=1)[0]
            val = search_param.split(',', maxsplit=1)[1]
            if key == 'error_code':
                where = self.make_where_sql_error_code(key, val)
                if len(where) > 0:
                    where_sql.append(where)
            elif key == 'equipment_name':
                where = self.make_where_sql_equip_name(val)
                if len(where) > 0:
                    where_sql.append(where)
            elif key == 'occurred_date':
                range_arr = val.split(',')
                if len(range_arr) == 2:
                    where_sql.append(f"err.{key} between '{range_arr[0]}' and '{range_arr[1]}'")
            elif key == 'error_message':
                if '*' in val:
                    where_sql.append(self.make_where_sql(key, val, is_contain=False))
                else:
                    where_sql.append(self.make_where_sql(key, val, is_contain=True))
        return where_sql

    def make_where_sql(self, key, val, is_contain=False):
        val = val.replace('_', '\_')
        val = val.replace('%', '\%')
        if '*' in val:
            val = val.replace('*', '%')

        if is_contain:
            sql = f"err.{key} ilike '%{val}%'"
        else:
            sql = f"err.{key} ilike '{val}'"
        return sql

    def make_where_sql_filter(self, filter):
        # FilterからRankとUnitを分離する。
        unit_list, rank_list = self.get_filter_list(filter)

        #sql文生成
        where_sql = []
        if len(unit_list) > 0:
            where_sql.append(f"err.unit in (%s)" % ', '.join([f'\'{elem}\'' for elem in unit_list]))

        if len(rank_list) > 0:
            where_sql.append(f"err.rank in (%s)" % ', '.join([f'\'{elem}\'' for elem in rank_list]))
        return where_sql

    def get_filter_list(self, filter):
        unit_list = []
        rank_list = []
        for filter_param in filter:
            key = filter_param.split(',', maxsplit=1)[0]
            val = filter_param.split(',', maxsplit=1)[1]
            if key == 'unit':
                unit_list = val.split(',')
            elif key == 'rank':
                for val in val.split(','):
                    if val == 'BD':
                        val = 'B/D'
                    rank_list.append(val)
        return unit_list, rank_list
