import os
import re

import pandas as pd
import psycopg2 as pg2

import config.app_config
from common.utils.response import ResponseForm
from config.app_config import CRAS_DB, LEGACY_ROOT
from dao.dao_base_server import BaseServerDao
from dao.dao_config import ConfigDao
from dao.utils import get_db_config, test_db_connection, copy_table, exist_table, exist_data_from_table, \
    copy_legacy_table, get_table_list
from dao.dao_base import DAOBaseClass
from convert import convert


def init_db():

    # Initialize server database.

    # Create server schemas to Cras-Database local container.
    init_schema(['public', 'cnvset', 'userdata', 'settings', 'fragments', 'cras_db'])
    init_type()
    init_table()
    init_data()

    # Initialize server_config table.
    ConfigDao().init()

    # Even if the following processes failed, the application should work.
    try:
        # Initialize cras-storage database.
        init_target_schema(ConfigDao.monitor_db(), 'cnvbase')
        init_cras_server_data()

        cv = convert.LogConvert()
        cv.set_db_config(**ConfigDao.monitor_db())
        cv.set_convert_db(**config.app_config.CRAS_DB, schema='cras_db')
        cv.init_database()

        dump_cras_data()

        print('** create converted log tables')
        create_converter_tables()

    except RuntimeError as ex:
        print(ex)
        print('- failed to initialize database.')
        print('- open http://localhost:5000/config in browser and configure the server.')


def init_schema(schema_list):
    config = CRAS_DB
    try:
        with pg2.connect(**config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                # DBの全体Schema目録獲得
                cur.execute('select nspname from pg_catalog.pg_namespace')
                rows = cur.fetchall()

                # Schema生成
                for item in schema_list:
                    if (item,) not in rows:
                        cur.execute('create schema %s' % item)
                        print(item + ' schema is created!!')
    except Exception as e:
        print('schema create error!')
        print(e)


def init_type():
    config = CRAS_DB
    try:
        with pg2.connect(**config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                sql_path = 'resource/sql/type'
                for file_name in os.listdir(sql_path):
                    if os.path.isdir(os.path.join(sql_path, file_name)) is False:
                        [schema, type_name, extension] = file_name.split(sep='.')
                        cur.execute("SELECT EXISTS "
                                    "(SELECT FROM pg_type WHERE typname='%s')"
                                    % type_name)

                        rows = cur.fetchone()
                        if rows[0] is False:
                            file_path = os.path.join(sql_path, file_name)
                            cur.execute(open(file_path, 'r').read())
                            print(schema + '.' + type_name + ' type is created!!')
    except Exception as e:
        print('table create error!')
        print(e)


def init_table():
    config = CRAS_DB
    try:
        with pg2.connect(**config) as conn:
            conn.autocommit = True
            with conn.cursor() as cur:
                # Table生成
                sql_path = 'resource/sql/table'
                for file_name in os.listdir(sql_path):
                    if os.path.isdir(os.path.join(sql_path, file_name)) is False:
                        [schema, table_name, extension] = file_name.split(sep='.')

                        if schema == 'convert' or schema == 'public' or schema == 'cnvbase':
                            # I don't create tables related to converted result here.
                            continue

                        cur.execute("SELECT EXISTS "
                                    "(SELECT FROM information_schema.tables WHERE table_schema='%s' AND table_name='%s')"
                                    % (schema, table_name))

                        rows = cur.fetchone()
                        if rows[0] is False:
                            file_path = os.path.join(sql_path, file_name)
                            cur.execute(open(file_path, 'r').read())
                            print(schema + '.' + table_name + ' table is created!!')

        return ResponseForm(res=True)
    except Exception as e:
        print('table create error!')
        print(e)
        return ResponseForm(res=False, msg=str(e))


def init_data():
    config = CRAS_DB
    data_path = './resource/data'
    tables = ['status_monitor_items']

    file_list = {file_name: False for file_name in os.listdir(data_path)}

    idx = 0
    loop_cnt = 0
    complete = False
    while not complete:
        if loop_cnt >= 5:
            return ResponseForm(res=False, msg='Retry too many times.')
        try:
            with pg2.connect(**config) as conn:
                with conn.cursor() as cur:
                    (file_name, value) = list(file_list.items())[idx]
                    # find target table in resource/data folder
                    find_target = False
                    for table in tables:
                        if file_name.find(table) != -1:
                            find_target = True
                            break

                    if find_target is False:
                        idx += 1
                        if idx == len(list(file_list.items())):
                            complete = True
                        continue
                    if os.path.isdir(os.path.join(data_path, file_name)) is False and value is False:
                        [schema, table, extension] = file_name.split(sep='.')
                        sep = ',' if extension == 'csv' else '\t'
                        table_name = '%s.%s' % (schema, table)
                        sql = 'select count(*) from %s' % table_name
                        cur.execute(sql)
                        count = cur.fetchone()[0]
                        if count == 0:
                            file_path = os.path.join(data_path, file_name)
                            with open(file_path, 'r') as f:
                                cur.copy_from(f, table_name, sep=sep, null='-99999999999999')
                                sql = f"select * from information_schema.columns where table_name = '{table}' and table_schema = '{schema}' and column_name = 'id'"
                                cur.execute(sql)
                                row = cur.fetchall()
                                if len(row) > 0:
                                    sql = f"select setval(pg_get_serial_sequence('{table_name}', 'id'), max(id)) from {table_name}"
                                    cur.execute(sql)
                                file_list[file_name] = True
                                print(file_name + ' data insert OK.')
                        else:
                            file_list[file_name] = True

            if False in file_list.values():
                idx += 1
                if idx == len(list(file_list.items())):
                    idx = 0
                    loop_cnt += 1
                    print('Retry...')
            else:
                complete = True
        except Exception as msg:
            print('failed to initialize cnvbase tables (%s)' % msg)
            idx += 1
            if idx == len(list(file_list.items())):
                idx = 0
                loop_cnt += 1
                print('Retry...')

    return ResponseForm(res=True)


def check_prerequisite():
    if os.environ.get('SET_DB') is None or os.environ.get('LEGACY_DB') is None:
        return False
    return True


def init_cras_server_data():

    # Migration from setting_db
    set_config = ConfigDao.set_db()
    set_schema = set_config.pop('schema')

    monitor_db = ConfigDao.monitor_db()
    if 'schema' in monitor_db:
        monitor_db.pop('schema')

    if set_config is None or set_config['host'] == '':
        print('## set_db is not configured yet ##')
        # It's possible to be empty host in set_config.
        pass
    else:
        if test_db_connection(set_config):
            print(f"** settings database available {set_config['host']}:{set_config['port']}/{set_config['dbname']}")
            table_list = ['error_category', 'status_monitor_items']

            for tbl in table_list:
                _str = f'checking {tbl} '
                try:
                    if copy_table(set_config, monitor_db, set_schema, 'cnvbase', tbl):
                        _str = f'{_str} .. copied'
                    else:
                        _str = f'{_str} .. okay'
                except RuntimeError as msg:
                    _str = f'{_str} .. failed. {msg}'
                print(_str)
        else:
            print(f'*** setting_db system connection failed.')


def create_converter_tables():
    convert_db = ConfigDao.convert_db()
    if convert_db is None or convert_db['host'] == '':
        print('## convert_db is not configured yet ##')
        return

    convert_schema = convert_db.pop('schema')
    if test_db_connection(convert_db):
        with pg2.connect(**convert_db) as conn:
            with conn.cursor() as cur:
                # Check schema
                cur.execute('select nspname from pg_catalog.pg_namespace')
                schemas = [_[0] for _ in cur.fetchall()]
                if convert_schema not in schemas:
                    cur.execute(f"create schema {convert_schema}")

                # Check tables
                sql_path = 'resource/sql/table'
                for file in os.listdir(sql_path):
                    inf = file.split('.')
                    if inf[0] == 'public':
                        cur.execute("SELECT EXISTS "
                                    "(SELECT FROM information_schema.tables WHERE table_schema='%s' AND table_name='%s')"
                                    % (convert_schema, inf[1]))
                        rows = cur.fetchone()

                        if rows[0] is False:
                            filepath = os.path.join(sql_path, file)
                            with open(filepath) as f:
                                sql = f.read()
                                sql = sql.replace('__schema__', convert_schema)
                                cur.execute(sql)
                                print(f"converted_db table {inf[1]} has been created")
    else:
        print('failed to connect converted_db')


def init_target_schema(config, schema):
    print(f"init_target_schema(schema={schema})")
    if config is None or 'host' not in config or config['host'] == '':
        print('init_target_schema: invalid config', config)
        return
    if schema in [None, '']:
        print('init_target_schema: invalid schema', schema)
        return

    # Deep copy
    config = {**config}
    if 'schema' in config:
        config.pop('schema')

    if not test_db_connection(config):
        print('init_target_schema: connection failed', config, schema)
        return

    try:
        with pg2.connect(**config) as conn:
            with conn.cursor() as cur:
                # Check schema
                cur.execute('select nspname from pg_catalog.pg_namespace')
                schemas = [_[0] for _ in cur.fetchall()]
                if schema not in schemas:
                    cur.execute(f"create schema {schema}")

                conn.commit()

                # Check tables
                sql_path = 'resource/sql/table'
                for file in os.listdir(sql_path):
                    inf = file.split('.')
                    if inf[0] == schema:
                        cur.execute("SELECT EXISTS "
                                    "(SELECT FROM information_schema.tables WHERE table_schema='%s' AND table_name='%s')"
                                    % (schema, inf[1]))
                        rows = cur.fetchone()
                        print('init_target_schema: check ', inf[1], 'exist=', rows[0])
                        if rows[0] is False:
                            filepath = os.path.join(sql_path, file)
                            with open(filepath) as f:
                                sql = f.read()
                                sql = sql.replace('__schema__', schema)
                                cur.execute(sql)
                                print(f"converted_db table {inf[1]} has been created")

                # Init tables
                data_path = 'resource/data'
                tables = ['log_define_master']
                file_list = {file_name: False for file_name in os.listdir(data_path)}
                idx = 0
                loop_cnt = 0
                complete = False
                while not complete:
                    if loop_cnt >= 5:
                        print("init_target_schema: monitor-db connection failed")
                        return
                    try:
                        (file_name, value) = list(file_list.items())[idx]

                        # find target table in resource/data folder
                        find_target = False
                        for table in tables:
                            if file_name.find(table) != -1:
                                find_target = True
                                break

                        if find_target is False:
                            idx += 1
                            if idx == len(list(file_list.items())):
                                complete = True
                            continue

                        if os.path.isdir(os.path.join(data_path, file_name)) is False and value is False:
                            [schema, table, extension] = file_name.split(sep='.')
                            sep = ',' if extension == 'csv' else '\t'
                            table_name = '%s.%s' % (schema, table)
                            sql = 'select count(*) from %s' % table_name
                            cur.execute(sql)
                            count = cur.fetchone()[0]
                            if count == 0:
                                file_path = os.path.join(data_path, file_name)
                                with open(file_path, 'r') as f:
                                    cur.copy_from(f, table_name, sep=sep, null='-99999999999999')
                                    sql = f"select * from information_schema.columns where table_name = '{table}' and table_schema = '{schema}' and column_name = 'id'"
                                    cur.execute(sql)
                                    row = cur.fetchall()
                                    if len(row) > 0:
                                        sql = f"select setval(pg_get_serial_sequence('{table_name}', 'id'), max(id)) from {table_name}"
                                        cur.execute(sql)
                                    file_list[file_name] = True
                                    print(file_name + ' data insert OK.')
                            else:
                                file_list[file_name] = True

                        if False in file_list.values():
                            idx += 1
                            if idx == len(list(file_list.items())):
                                idx = 0
                                loop_cnt += 1
                                print('Retry...')
                        else:
                            complete = True
                    except Exception as msg:
                        print('failed to initialize cnvbase tables (%s)' % msg)
                        idx += 1
                        if idx == len(list(file_list.items())):
                            idx = 0
                            loop_cnt += 1
                            print('Retry...')

    except Exception as ex:
        print("init_target_schema: monitor-db connection failed")
        print(ex)
        return

def dump_cras_data():
    print('dump_cras_data start')
    # Migration cras data from legacy server.
    convert_config = ConfigDao.convert_db()
    if convert_config is None or convert_config['host'] == '':
        print('## convert_db is not configured yet ##')
        return

    convert_schema = convert_config.pop('schema')

    if not test_db_connection(convert_config):
        print(f"connection failed ({convert_config['host']}:{convert_config['port']}/{convert_config['dbname']})")
        return

    if os.path.exists(LEGACY_ROOT):
        output = os.path.join(LEGACY_ROOT, 'cras_data.xlsx')
        if not os.path.exists(output):
            print('create cras_data.xlsx')

            table_list = get_table_list(convert_config, convert_schema)
            if len(table_list) == 0:
                print('no cras table in legacy set_db')
                return

            with pg2.connect(**convert_config) as c:
                data_df = pd.DataFrame()
                for tbl in [t for t in table_list if t.startswith('cras_data')]:
                    ret = re.search(r'cras_data_([^_]+)_([^_]+)', tbl)
                    if len(ret.groups()) != 2:
                        print(f'non-formatted cras-data table name. {tbl}')
                        continue

                    df = pd.read_sql(f"select * from {convert_schema}.{tbl}", c)
                    if len(df) > 0:
                        df.insert(1, 'user_name', ret.group(1))
                        df.insert(2, 'fab_name', ret.group(2))
                        data_df = data_df.append(df, ignore_index=True)

                item_df = pd.DataFrame()
                for tbl in [t for t in table_list if t.startswith('cras_item')]:
                    ret = re.search(r'cras_item_([^_]+)_([^_]+)_master', tbl)
                    if len(ret.groups()) != 2:
                        print(f'non-formatted cras-item table name. {tbl}')
                        continue

                    df = pd.read_sql(f"select * from {convert_schema}.{tbl}", c)
                    if len(df) > 0:
                        df.insert(1, 'user_name', ret.group(1))
                        df.insert(2, 'fab_name', ret.group(2))
                        item_df = item_df.append(df, ignore_index=True)

                if len(item_df) == 0 and len(data_df) == 0:
                    print('no data to create dump file')
                    return

                # Write into excel
                writer = pd.ExcelWriter(output, engine='openpyxl', mode='w')
                if len(data_df) > 0:
                    data_df.to_excel(writer, sheet_name='cras_data', index=False, encoding='utf8')
                if len(item_df) > 0:
                    item_df.to_excel(writer, sheet_name='cras_item_master', index=False, encoding='utf8')
                writer.save()
                writer.close()

                if os.path.exists(output):
                    print('dump file %s created' % output)
                else:
                    print('failed to create dump file %s' % output)
    else:
        print('no legacy path exists')
