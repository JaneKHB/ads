class DatabaseQueryException(Exception):
    pass