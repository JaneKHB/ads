import json
import os
import psycopg2.extras
import psycopg2 as pg2
import pandas as pd
import logging

import config.app_config as _config
from dao.utils import parse_env_db_config
from psycopg2.extras import LoggingConnection

config_user_name = None
config_log_monitor = None
config_convert_db = None
config_set_db = None
config_rapid = None

logger = logging.getLogger(_config.LOG)

class ConfigDao:

    USER_NAME = 'user-name'
    CONVERT_STORAGE_DB = 'convert-storage-db'
    LOG_MONITOR = 'log-monitor'
    SETTING_DB = 'setting-db'
    RAPID_COLLECTOR = 'rapid-collector'

    # For error log download,
    # key values that configure log names(log categories in Rapid-Collector) for downloading the specific logs.
    LOG_NAME_RECIPE = 'log-name-recipe'
    LOG_NAME_MACHINE_DATA = 'log-name-machine-status'
    LOG_NAME_VERSION = 'log-name-version'

    __DEFAULT_TABLE = [
        [LOG_NAME_RECIPE, 'Recipe'],
        [LOG_NAME_MACHINE_DATA, 'Machine Data'],
        [LOG_NAME_VERSION, 'Version Info']
    ]

    def __init__(self):
        self.config = _config.CRAS_DB

    def init(self):
        global config_user_name, config_log_monitor, config_convert_db, config_set_db, config_rapid

        with pg2.connect(connection_factory=LoggingConnection, **self.config) as con:
            con.initialize(logger)
            with con.cursor() as cur:
                conf = pd.read_sql('select * from cnvset.server_config', con)

                target_conf = conf[conf['key'] == self.USER_NAME]
                if len(target_conf) == 0:
                    print('set user-name as the default')
                    config_user_name = 'default-user'
                    cur.execute(f"insert into cnvset.server_config (key, value) values\
                                    ('{self.USER_NAME}', '{config_user_name}')")
                else:
                    config_user_name = target_conf.iloc[0]['value']

                print('user_name', config_user_name)

                target_conf = conf[conf['key'] == self.CONVERT_STORAGE_DB]
                if len(target_conf) == 0:
                    print('set convert-storage-config as the default')
                    def_val = {
                        'host': '',
                        'port': 0,
                        'dbname': '',
                        'user': '',
                        'password': '',
                        'schema': ''
                    }
                    if def_val is not None:
                        cur.execute(f"insert into cnvset.server_config (key, value) values\
                                ('{self.CONVERT_STORAGE_DB}', '{json.dumps(def_val)}')")
                    if config_convert_db is None:
                        config_convert_db = def_val
                else:
                    config_convert_db = json.loads(target_conf.iloc[0]['value'])

                print('convert_db', config_convert_db)

                target_conf = conf[conf['key'] == self.LOG_MONITOR]
                if len(target_conf) == 0:
                    print('set log-monitor as the default')
                    def_val = {
                        'host': '',
                        'port': 0,
                        'user': 'rssuser',
                        'password': 'rssuser',
                        'dbname': 'logdb'
                    }
                    cur.execute(f"insert into cnvset.server_config (key, value) values ('{self.LOG_MONITOR}', \
                        '{json.dumps(def_val)}')")
                    config_log_monitor = def_val
                else:
                    config_log_monitor = json.loads(target_conf.iloc[0]['value'])

                print('log_monitor', config_log_monitor)

                target_conf = conf[conf['key'] == self.SETTING_DB]
                if len(target_conf) == 0:
                    print('set setting-db as the default')
                    def_val = {
                        'host': '',
                        'port': 0,
                        'dbname': '',
                        'user': '',
                        'password': '',
                        'schema': ''
                    }
                    cur.execute(f"insert into cnvset.server_config (key, value) values ('{self.SETTING_DB}', \
                                        '{json.dumps(def_val)}')")
                    config_set_db = def_val
                else:
                    config_set_db = json.loads(target_conf.iloc[0]['value'])

                print('set_db', config_set_db)

                target_conf = conf[conf['key'] == self.RAPID_COLLECTOR]
                if len(target_conf) == 0:
                    print('set rapid-collector as the default')
                    def_val = {
                        'host': '',
                        'port': '',
                        'user': '',
                        'password': ''
                    }
                    cur.execute(f"insert into cnvset.server_config (key, value) values ('{self.RAPID_COLLECTOR}', \
                                                            '{json.dumps(def_val)}')")
                    config_rapid = def_val
                else:
                    config_rapid = json.loads(target_conf.iloc[0]['value'])

                print('rapid', config_rapid)

                for kv in self.__DEFAULT_TABLE:
                    cur.execute(f"select * from cnvset.server_config where key = '{kv[0]}' limit 1")
                    ret = cur.fetchone()
                    if ret is None or len(ret) == 0:
                        print(f'[config] set default {kv[0]} = {kv[1]}')
                        cur.execute(f"insert into cnvset.server_config (key, value) values ('{kv[0]}', '{kv[1]}')")

    def get_config(self, name):
        with pg2.connect(connection_factory=LoggingConnection, **self.config) as con:
            con.initialize(logger)
            with con.cursor() as cur:
                cur.execute(f"select * from cnvset.server_config where key = '{name}'")
                ret = cur.fetchone()
                if ret is not None:
                    if name in [self.USER_NAME, self.LOG_NAME_RECIPE, self.LOG_NAME_MACHINE_DATA, self.LOG_NAME_VERSION]:
                        return ret[1]
                    ret = json.loads(ret[1])
                return ret

    def set_config(self, name, value):
        with pg2.connect(connection_factory=LoggingConnection, **self.config) as con:
            con.initialize(logger)
            with con.cursor() as cur:
                cur.execute(f"update cnvset.server_config set value = '{value}' where key = '{name}'")

                # The below names work immediately.
                if name == self.USER_NAME:
                    global config_user_name
                    config_user_name = value
                elif name == self.RAPID_COLLECTOR:
                    global config_rapid
                    config_rapid = json.loads(value)

    @staticmethod
    def user_name():
        global config_user_name
        return config_user_name

    @staticmethod
    def cras_db():
        return _config.CRAS_DB

    @staticmethod
    def monitor_db():
        global config_log_monitor
        return {**config_log_monitor}

    @staticmethod
    def convert_db():
        global config_convert_db
        return {**config_convert_db}

    @staticmethod
    def set_db():
        global config_set_db
        return {**config_set_db}

    @staticmethod
    def rapid():
        global config_rapid
        return {**config_rapid}

