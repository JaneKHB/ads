import os

import psycopg2.extras
import psycopg2 as pg2
import pandas as pd

from dao.utils import get_db_config, parse_env_db_config


class BaseServerDao:
    """
    BaseServerDao is data-access-object to connect to log-monitor server database.
    """

    schema = 'cnvbase'
    cras_schema = 'cras'

    def __init__(self, monitor_db):
        self.config = get_db_config()
        self.monitor_config = {**monitor_db}
        if 'schema' in self.monitor_config:
            self.monitor_config.pop('schema')

    def get_equipment_df(self, fab=None):
        with pg2.connect(**self.config) as con:
            where = '' if fab is None else f"where fab_name = '{fab}'"
            df = pd.read_sql(f"select * from cras_db.equipments {where}", con)
            return df
        return None

    def get_equipments(self, equipment_type=None, company=None, df=False):
        # Deprecated
        try:
            with pg2.connect(**self.monitor_config) as connect:
                sql = None
                if equipment_type is not None:
                    sql = f"select * from cnvbase.equipments where \
                            equipment_type='{equipment_type}' and exec is true"
                elif company is not None:
                    sql = f"select * from cnvbase.equipments where \
                            user_name='{company}' and exec is true"
                else:
                    sql = f"select * from cnvbase.equipments where exec is true"
                if df:
                    return pd.read_sql(sql, connect)
                else:
                    with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                        cursor.execute(sql, locals())
                        _equipments = cursor.fetchall()
                        equipments = []
                        for equipment in _equipments:
                            equipments.append(dict(equipment))
                        return equipments

        except Exception as msg:
            print('failed to get equipment (%s)' % msg)

    # def get_equipment(self, equipment_name):
    #     try:
    #         with pg2.connect(**self.monitor_config) as connect:
    #             with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
    #                 sql = '''
    #                     select * from log_manager.equipments where equipment_name=%(equipment_name)s
    #                 '''
    #                 cursor.execute(sql, locals())
    #                 eqp = cursor.fetchone()
    #                 if eqp is None:
    #                     print('no equipment called %s' % equipment_name)
    #                     return None
    #                 return dict(eqp)
    #
    #     except Exception as msg:
    #         print('failed to get equipment (%s)' % msg)

    def get_log_define(self, log_name):
        try:
            with pg2.connect(**self.monitor_config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(f"select * from cnvbase.log_define_master where log_name='{log_name}'")
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to get log definition. {msg}')
        return None

    def ___find_transfer_log_list(self, log_name):
        if not log_name or log_name == '':
            return None

        sql = f"select * from cnvbase.transfer_log_list where logname like '%{log_name}' or \
                    destination_path like '%{log_name}'"
        try:
            with pg2.connect(**self.config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    cursor.execute(sql)
                    _ret = cursor.fetchone()
                    if _ret is None:
                        return None
                    return dict(_ret)
        except Exception as msg:
            print(f'failed to find transfer log list. {msg}')
        return None

    def ___get_all_data(self, table):
        try:
            sql = f"select * from {table}"
            with pg2.connect(**self.config) as connect:
                return pd.read_sql(sql, connect)
        except Exception as msg:
            print(f'failed to get all data from {table}. {msg}')
        return None

    def get_error_category_df(self):
        sql = f"SELECT * FROM {self.schema}.error_category"
        try:
            with pg2.connect(**self.monitor_config) as conn:
                return pd.read_sql(sql, conn)
        except Exception as ex:
            print(f'failed to get error category')
        return None

    def ___get_cras_tool_info(self):
        try:
            with pg2.connect(**self.monitor_config) as connect:
                with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                    sql = f"select user_name, fab_name, tool_id from {self.cras_schema}.equipments"
                    cursor.execute(sql)
                    _ret = cursor.fetchall()
                    ret = list()
                    for r in _ret:
                        ret.append(dict(r))
                    return ret

        except Exception as msg:
            print(f'failed to get cras tool info {msg}')
            return None

    def get_cras_data(self, user, fab):
        try:
            with pg2.connect(**self.monitor_config) as connect:
                sql = f"select * from {self.cras_schema}.cras_data \
                    where user_name = '{user.lower()}' and fab_name = '{fab.lower()}'"
                return pd.read_sql(sql, connect)
        except Exception as msg:
            print(f'failed to get cras data info {msg}')
            return None

    def get_status_monitor_items(self):
        try:
            with pg2.connect(**self.monitor_config) as connect:
                sql = f"select * from {self.schema}.status_monitor_items"
                return pd.read_sql(sql, connect)
        except Exception as msg:
            print(f'failed to get status_monitor_items. {msg}')
            return None

