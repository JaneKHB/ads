import os
import datetime
from io import StringIO
import pandas as pd
import psycopg2 as pg2

from config.app_config import CRAS_DB


def get_db_config():
    return {**CRAS_DB}


def parse_env_db_config(env):
    if env is None:
        return None

    env_list = env.split(',')
    if len(env_list) < 4 or len(env_list[0]) == 0:
        return None

    return {
        'host': env_list[0],
        'port': env_list[1],
        'user': env_list[2],
        'password': env_list[3]
    }


def get_datetime(time: str):
    fmt = ['%Y-%m-%d %H:%M:%S', '%Y%m%d%H%M%S', '%Y-%m-%d']
    if time is None:
        return None
    for f in fmt:
        try:
            return datetime.datetime.strptime(time, f)
        except ValueError:
            continue
    return None


def get_date_string(time: datetime.date):
    return time.strftime('%Y-%m-%d %H:%M:%S')


def exist_table(table_name, schema_name='public', config=None):
    try:
        if config is None:
            config = get_db_config()
        sql = f"select exists (select from information_schema.tables \
                where table_name='{table_name}' and table_schema='{schema_name}')"
        with pg2.connect(**config) as connect:
            with connect.cursor() as cursor:
                cursor.execute(sql)
                ret = cursor.fetchone()
                return ret[0]

    except Exception as msg:
        print(f'exist_table exception occurs. {msg}')
        return False


def get_table_list(config, schema_name):
    try:
        sql = f"select table_name from information_schema.tables where table_schema = '{schema_name}'"
        with pg2.connect(**config) as c:
            with c.cursor() as cur:
                cur.execute(sql)
                ret = cur.fetchall()
                return [r[0] for r in ret]
    except Exception as ex:
        print(f'get_table_list: failed to get table_list. {ex}')
    return list()


def test_db_connection(config):
    try:
        if config is None or 'host' not in config or config['host'] == '':
            return False
        if 'port' not in config or config['port'] == 0:
            return False

        connect = pg2.connect(**config, connect_timeout=1)
        connect.close()
        return True
    except Exception as msg:
        pass
    return False


def exist_data_from_table(table_name, config=None):
    try:
        if config is None:
            config = get_db_config()
        with pg2.connect(**config) as connect:
            with connect.cursor() as cursor:
                cursor.execute(f"select count(*) from {table_name}")
                _ret = cursor.fetchone()
                return True if _ret[0] > 0 else False
    except:
        pass
    return False


def copy_table(src_config, dst_config, src_schema, dst_schema, table):
    src_tbl = f'{src_schema}.{table}'
    dst_tbl = f'{dst_schema}.{table}'

    if not exist_table(table, src_schema, src_config):
        raise RuntimeError(f"{table} table not exists from {src_tbl}")

    if not exist_table(table, dst_schema, dst_config):
        raise RuntimeError(f"{table} table not exists from {dst_tbl}")

    if not exist_data_from_table(dst_tbl, dst_config):
        if exist_data_from_table(src_tbl, src_config):
            with pg2.connect(**src_config) as src_conn:
                with src_conn.cursor() as src_cur:
                    src_cur.execute(f"select * from {src_tbl} limit 0")
                    columns = [_[0] for _ in src_cur.description]

                    buffer = StringIO()
                    src_cur.copy_to(buffer, src_tbl, sep='\t', null='-99999999999999', columns=columns)
                    buffer.seek(0)

                    with pg2.connect(**dst_config) as dst_conn:
                        with dst_conn.cursor() as dst_cur:
                            try:
                                dst_cur.copy_from(buffer, dst_tbl, sep="\t", null='-99999999999999', columns=columns)
                                return True
                            except (Exception, pg2.DatabaseError) as error:
                                raise RuntimeError(f'..error occurs on copy table. {error}')
    else:
        return True


def copy_legacy_table(src_config, src_schema, src_table, dst_table, user, fab, output):
    src_tbl = f'{src_schema}.{src_table}'
    if exist_table(src_table, src_schema, src_config):
        if exist_data_from_table(src_tbl, src_config):
            with pg2.connect(**src_config) as src_conn:
                if os.path.isfile(output):
                    writer = pd.ExcelWriter(output, engine='openpyxl', mode='a')
                else:
                    writer = pd.ExcelWriter(output, engine='openpyxl', mode='w')
                df = pd.read_sql(f"select * from {src_tbl}", src_conn)
                df.insert(1, 'user_name', user)
                df.insert(2, 'fab_name', fab)
                df.to_excel(writer, sheet_name=dst_table, index=False, encoding='utf8')
                writer.save()
                writer.close()
                return True
    return False
