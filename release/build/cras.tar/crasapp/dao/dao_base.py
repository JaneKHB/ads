from abc import *
from io import StringIO
import psycopg2 as pg2
from psycopg2 import extras
import pandas as pd
from copy import deepcopy

from common.utils.response import ResponseForm
from dao.utils import get_db_config


class DAOBaseClass(metaclass=ABCMeta):
    def __init__(self, **kwargs):
        self.df = None

        if 'table_name' in kwargs:
            self.table_name = kwargs['table_name']
        else:
            self.table_name = None

        self.config = get_db_config()

        if 'dbname' in kwargs:
            self.config['dbname'] = kwargs['dbname']
        if 'user' in kwargs:
            self.config['user'] = kwargs['user']
        if 'host' in kwargs:
            self.config['host'] = kwargs['host']
        if 'password' in kwargs:
            self.config['password'] = kwargs['password']
        if 'port' in kwargs:
            self.config['port'] = kwargs['port']

    def __del__(self):
        del self.table_name
        del self.config
        del self.df

    def execute(self, query, args={}):
        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                cur.execute(query, args)
                row = cur.fetchall()

        return row

    def execute_values(self, query, argslist):
        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                extras.execute_values(cur, query, argslist)

    def execute_by_dict(self, query):
        with pg2.connect(**self.config) as conn:
            with conn.cursor(cursor_factory=pg2.extras.DictCursor) as cur:
                cur.execute(query)
                row = cur.fetchall()

        dict_result = []

        for row in row:
            dict_result.append(dict(row))

        return dict_result

    def execute_by_spl(self, query):
        with pg2.connect(**self.config) as conn:
            return pd.read_sql(sql=query, con=conn)

    def fetch_one(self, table=None, args={}):
        table_name = table
        if table_name is None:
            table_name = self.table_name

        if 'select' in args:
            if 'where' in args:
                query = 'select %s from %s where %s' % (args['select'], table_name, args['where'])
            else:
                query = 'select %s from %s' % (args['select'], table_name)
        else:
            if 'where' in args:
                query = 'select * from %s where %s' % (table_name, args['where'])
            else:
                query = 'select * from %s' % table_name

        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                cur.execute(query)
                row = cur.fetchone()

        return row

    def fetch_all(self, table=None, args={}):
        table_name = table
        if table_name is None:
            table_name = self.table_name

        if 'select' in args:
            if 'where' in args:
                query = 'select %s from %s where %s' % (args['select'], table_name, args['where'])
            else:
                query = 'select %s from %s' % (args['select'], table_name)
        else:
            if 'where' in args:
                query = 'select * from %s where %s' % (table_name, args['where'])
            else:
                query = 'select * from %s' % table_name

        with pg2.connect(**self.config) as conn:
            return pd.read_sql(query, conn)

    def update_all(self, db_table, update_data, where_data):
        """
        データをUpdateする
        :param db_table:
        :param update_data:
        :param where_data:
        :return:
        """
        # values = []
        # key_str = ''
        # is_first_elem = True

        update_key = update_data[0]
        update_value = update_data[1]
        where_key = where_data[0]
        where_value = where_data[1]

        sql_str = "UPDATE {} SET {} = %s WHERE {} = %s;".format(db_table, update_key, where_key)

        with pg2.connect(**self.config) as conn:
            with conn.cursor()as cur:
                cur.execute(sql_str, (update_value, where_value))

    def insert_from_df(self, table, df):
        """
        指定されたテーブルにデータフレームをInsertする
        :param table_name: テーブル名
        :param insert_df: insertするデータフレーム
        :return:
        """
        for _, elem in df.iterrows():
            values = []
            key_str = ''
            is_first_elem = True
            elem = elem.dropna()
            for key, value in elem.items():
                values.append(value)
                if not is_first_elem:
                    key_str += ','
                is_first_elem = False
                key_str += key

            sql_str = "INSERT INTO " + table + " (" + key_str + ") VALUES %s"
            value_tuple = tuple(values)
            value_list = list()
            value_list.append(value_tuple)
            with pg2.connect(**self.config) as conn:
                with conn.cursor()as cur:
                    try:
                        extras.execute_values(cur, sql_str, value_list)
                    except Exception as errmsg:
                        print(errmsg)

    def insert_from_stringio(self, df):
        # save dataframe to an in memory buffer
        buffer = StringIO()

        if '' in df.columns:
            del df['']

        df['created_time'] = pd.Timestamp.now()

        df.to_csv(buffer, index=False, header=False)
        buffer.seek(0)

        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                try:
                    cur.copy_from(buffer, self.table_name, sep=",", columns=df.columns, null='-99999999999999')
                    conn.commit()
                except (Exception, pg2.DatabaseError) as error:
                    print("Error: %s" % error)
                    conn.rollback()

        print("copy_from_stringio() done")

    def get_columns(self):
        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                try:
                    cur.execute(f"Select * FROM {self.table_name}")
                    columns = [desc[0] for desc in cur.description]

                    return columns
                except Exception as e:
                    return []

    def connection_check(self):
        try:
            query = 'select version()'
            row = self.execute(query)
            data = row[0][0]
            return ResponseForm(res=True, data=data)
        except Exception as e:
            msg = str(e) if len(str(e)) > 0 else 'Cannot Connect Dababase. Check username or dbname or password.'
            return ResponseForm(res=False, msg=msg, status=400)

    def update(self, table=None, set=None, where=None):
        table_name = table
        if table_name is None:
            table_name = self.table_name

        if set is not None:
            query = 'update {0} set '.format(table_name)
            for key, val in set.items():
                query = query + "{0}='{1}', ".format(key, val)
            query = query[:-2]

            if where is not None:
                query = query + ' where '
                for key, val in where.items():
                    query = query + "{0}='{1}' and ".format(key, val)
                query = query[:-5]

            try:
                with pg2.connect(**self.config) as conn:
                    with conn.cursor()as cur:
                        cur.execute(query)

                return ResponseForm(res=True)
            except Exception as e:
                return ResponseForm(res=False, msg=str(e))
        else:
            return ResponseForm(res=False, msg='Nothing to Update.')

    def drop_tables(self, omit_schema_list=[]):
        try:
            with pg2.connect(**self.config) as conn:
                conn.autocommit = True
                with conn.cursor() as cur:
                    # cur.execute('select nspname from pg_catalog.pg_namespace')
                    # rows = cur.fetchall()

                    for schema in ['public', 'cnvbase', 'cnvset']:
                        if schema not in omit_schema_list:
                            sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                                  "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                            cur.execute(sql)
                            tables = cur.fetchall()
                            for table in tables:
                                sql = 'drop table ' + schema + '.' + table[1] + " cascade"
                                cur.execute(sql)

            return ResponseForm(res=True)
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def export_tables_from_schema(self, schema_list, omit_tb_list=[]):
        try:
            with pg2.connect(**self.config) as conn:
                with conn.cursor() as cur:
                    data = dict()
                    for schema in schema_list:
                        sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                              "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                        cur.execute(sql)
                        tables = cur.fetchall()
                        for table in tables:
                            tb_name = schema + '.' + table[1]
                            if tb_name not in omit_tb_list:
                                buffer = self.fetch_all_as_csv(table=tb_name)
                                data[tb_name] = buffer

            return ResponseForm(res=True, data=data)
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def get_table_list_from_schema(self, schema_list):
        try:
            table_list = []
            with pg2.connect(**self.config) as conn:
                with conn.cursor() as cur:
                    for schema in schema_list:
                        sql = "SELECT table_schema,table_name FROM information_schema.tables " \
                              "WHERE table_schema = '%s' ORDER BY table_schema,table_name" % schema
                        cur.execute(sql)
                        tables = cur.fetchall()
                        for table in tables:
                            tb_name = schema + '.' + table[1]
                            table_list.append(tb_name)

            return ResponseForm(res=True, data=table_list)
        except Exception as e:
            return ResponseForm(res=False, msg=str(e))

    def fetch_all_as_csv(self, table):
        buffer = StringIO()
        try:
            with pg2.connect(**self.config) as conn:
                with conn.cursor() as cur:
                    # query = "copy (select * from %s) to stdout with csv" % table
                    # cur.copy_expert(query, buffer)
                    cur.copy_to(buffer, table, sep='\t', null='-99999999999999')
                    return buffer
        except Exception as e:
            return None

    def delete(self, query, args={}):
        with pg2.connect(**self.config) as conn:
            with conn.cursor() as cur:
                cur.execute(query, args)

    def get_df(self):
        return deepcopy(self.df)
