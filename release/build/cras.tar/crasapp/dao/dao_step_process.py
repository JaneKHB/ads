import psycopg2 as pg2
import psycopg2.extras
import inspect

import config.app_config as _config


def connector(func):
    def _wrapper(*args, **kwargs):
        with pg2.connect(**_config.CRAS_DB) as c:
            with c.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                arg_list = [sign for sign in inspect.signature(func).parameters]
                if len(args) > 1:
                    for i in range(1, len(args)):
                        kwargs[arg_list[i]] = args[i]
                if 'conn' in arg_list:
                    kwargs['conn'] = c
                if 'cur' in arg_list:
                    kwargs['cur'] = cur
                return func(*[args[0]], **kwargs)
        raise RuntimeWarning('failed to connect db')
    return _wrapper


class StepProcessDao:

    def __init__(self):
        self.tbl = 'cnvset.step_process'
        self.config = _config.CRAS_DB

    @connector
    def insert(self, pid, client, step, conn, cur):
        init_status = 'running'
        cur.execute("insert into %s (id, client, step, status) values ('%s', '%s', '%s', '%s') returning *" %
                    (self.tbl, pid, client, step, init_status))
        ret = cur.fetchone()
        return dict(ret)

    @connector
    def update(self, pid, status, conn, cur):
        cur.execute("update %s set status = '%s' where id = '%s' returning *" %
                    (self.tbl, status, pid))
        ret = cur.fetchone()
        return dict(ret)

    @connector
    def get(self, pid, conn, cur):
        cur.execute("select * from %s where id = '%s'" % (self.tbl, pid))
        ret = cur.fetchone()
        return dict(ret)

    @connector
    def _find(self, where, order, conn, cur):
        if where is None or where == '':
            where = ''
        else:
            where = 'where %s' % where
        order_option = 'order by created desc' if order else ''

        cur.execute("select * from %s %s %s" % (self.tbl, where, order_option))
        ret = cur.fetchall()
        if ret is None:
            return None
        return [dict(r) for r in ret]

    def find(self, pid=None, client=None, step=None, order=True):
        cons = list()
        if pid is not None:
            cons.append("id = '%s'" % pid)
        if client is not None:
            cons.append("client = '%s'" % client)
        if step is not None:
            cons.append("step = '%s'" % step)

        if len(cons) > 0:
            return self._find(' and '.join(cons), order)
        return self._find('', order)

    @connector
    def delete(self, pid, conn, cur):
        cur.execute("delete from %s where id = '%s'" % (self.tbl, pid))

    @connector
    def delete_by_client(self, client, conn, cur):
        cur.execute("delete from %s where client = '%s'" % (self.tbl, client))
