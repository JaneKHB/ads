from flask import Response, request, make_response
from flask_restx import Resource, Namespace

from controller.converter.v1.convertio import ConvertIoModuleLoader
from dao import ConfigDao
from dao.dao_cras_storage import CrasStorageDao
from dao.utils import get_datetime
from system_logger import SystemLogger

logger = SystemLogger('srv', 'ctrl')

convert_data = Namespace('Convert Data', description='APIs retrieves converted log data or table information')


@convert_data.route('/log/<string:log_name>')
@convert_data.param('log_name', 'Log name what you get information about.')
class ConvertGetLogInfo(Resource, ConvertIoModuleLoader):
    parser = convert_data.parser()
    parser.add_argument('equipment', required=False, help='When you specific this, the server returns information \
                                                          only about the specific equipment.')

    @convert_data.doc(responses={
        200: 'Success',
        400: 'Internal server error',
        500: 'Parameter error'
    })
    def get(self, log_name):
        """
        Get log information like the first and last recorded logs and so on.
        """
        logger.info(f'{request.method} {request.path}')
        param = self.parser.parse_args()

        self.load()
        log = self.cv.get_log_by_name(log_name)
        if log is None:
            return Response(status=500)

        table = log['table_name']
        info = CrasStorageDao(ConfigDao.convert_db()).get_log_info(table, param['equipment'])

        if info is None:
            response = make_response({'count': 0}, 200)
        else:
            response = make_response(info, 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@convert_data.route('/log/dump/<string:log_name>')
class ConvertGetConvertedLog(Resource, ConvertIoModuleLoader):
    parser = convert_data.parser()
    parser.add_argument('start', required=True, help='Dump starting time.')
    parser.add_argument('end', required=True, help='Dump end time.')
    parser.add_argument('equipment', required=False, help='When you specific this, the server returns information \
                                                              only about the specific equipment.')

    @convert_data.doc(responses={
        200: 'Success',
        400: 'Internal server error',
        500: 'Parameter error'
    })
    def get(self, log_name):
        """
        Return converted data in the database.
        """
        logger.info(f'{request.method} {request.path}')
        param = self.parser.parse_args()

        self.load()
        log = self.cv.get_log_by_name(log_name)
        if log is None:
            return Response(status=500)

        table = log['table_name']

        start = get_datetime(param['start'])
        end = get_datetime(param['end'])
        end = end.replace(hour=23, minute=59, second=59)
        dump = CrasStorageDao(ConfigDao.convert_db()).get_converted_data(table, start, end, param['equipment'])
        response = make_response({'data': dump}, 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response
