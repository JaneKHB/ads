import os
import threading
import traceback
import copy
import pandas as pd
import numpy as np
import re
from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace

import config.app_config
from config.app_config import JOB_ROOT
from convert import convert, const
from convert.util import get_table_column_list, delete_line_end, do_query, exist_table
from dao import ConfigDao
from system_logger import SystemLogger
from datetime import datetime

logger = SystemLogger('srv', 'ctrl')

convert_io = Namespace('ConvertIO', description='You have to write descriptions down')

class ConvertIoModuleLoader:
    cv = None

    def load(self):
        self.cv = convert.LogConvert()
        self.cv.set_db_config(**ConfigDao.monitor_db())
        self.cv.set_convert_db(**config.app_config.CRAS_DB, schema='cras_db')


class ConvertIoLogController(ConvertIoModuleLoader):

    def _get_log_by_id(self, log_id):
        self.load()
        logs = self.cv.get_log_list()
        logs = [_ for _ in logs if _['id'] == log_id]
        if len(logs) == 0:
            return error_response({'path': request.path, 'error': 'invalid log-id'})
        logs = build_log_list(logs)

        log = logs[0]
        log['filter'] = list()
        filter_list = self.cv.get_filter_list(log_id)
        if len(filter_list) > 0:
            filters = self.cv.get_filter_items(filter_list[0]['id'])
            for fil in filters:
                log['filter'].append({
                    'name': fil['name'],
                    'type': fil['type'],
                    'condition': fil['condition']
                })

        return json_response(200, logs[0])

    def get_log_list(self):
        self.load()
        logs = self.cv.get_log_list()
        logs = build_log_list(logs)
        return json_response(200, logs)

    def add_log(self, body):
        self.load()
        log = self.cv.create_log(body['log_name'])
        if log is None:
            return error_response({'path': request.path, 'error': 'database connection error or log_name duplicated'})

        # 'select' value means a range of what this log will cover.
        table = body['table_name'] if 'table_name' in body else None
        input_type = body['input_type'] if 'input_type' in body else None
        fab = create_comma_string(body['select']) if 'select' in body else None
        tag = create_comma_string(body['tag']) if 'tag' in body else None
        ignore = create_comma_string(body['ignore']) if 'ignore' in body else None
        retention = int(body['retention']) if 'retention' in body else None

        try:
            ret = self.cv.update_log(log['id'], input_type=input_type, table=table, fab=fab, tag=tag, ignore=ignore,
                                     retention=retention)
            if ret is None:
                # None returned when the module couldn't find the log from database.
                # In this case, we don't rollback the log from database.
                return json_response(500, {'error': 'failed to create a log (server internal error)'})
            return json_response(200, {'id': log['id']})
        except RuntimeError as ex:
            # Rollback
            self.cv.delete_log(log['id'])
            return json_response(400, {'error': 'failed to create a log (%s)' % str(ex)})

    def modify_log(self, log_id, body):
        self.load()
        body = cast_fetch_body(body)
        log = self.cv.update_log(log_id, **body)
        return json_response(200, log)

    def delete_log(self, log_id):
        self.load()
        self.cv.delete_log(log_id)
        return json_response(200, {})

    def get_log_list_pagination(self, page, size, sort, order, search):
        self.load()
        logs, total = self.cv.get_log_list_pagination(page, size, sort, order, search)
        # [SAMPLE] logs = [{ 'id': 10, 'log_name': 'ADCCOMPENSATION', 'input_type': 'csv', 'table_name': 'adccompensation', 'retention': 90, 'rule': True, 'errors': 0, 'select': [], 'tag': ['ADCCOMPENSATION'], 'ignore': []}, ...]
        logs = build_log_list(logs)

        total_pages = 0
        if total != 0:
            if size == 0:
                total_pages = 1
                size = total
            else:
                total_pages = int((total + size - 1) / size)

        return {
            'totalElements': total,
            'pageable': {
                'pageNumber': page,
                'pageSize': size
            },
            'totalPage': total_pages,
            'first': True if page == 0 else False,
            'last': True if (total_pages == page + 1) | (total_pages == 0) else False,
            'content': logs,
        }


class ConvertIoRuleController(ConvertIoModuleLoader):

    class CreateRuleError(Exception):
        pass

    def _create_rule(self, body, modify=False):
        self.load()

        log_name = body['log_name']
        log = self.cv.get_log_by_name(body['log_name'])
        try:
            if log is None:
                raise self.CreateRuleError(f'invalid log-name {log_name}')
            if log['table_name'] != '' and log['table_name'] != body['table_name']:
                raise self.CreateRuleError(f'cannot change table-name')
            if log['input_type'] != '' and log['input_type'] != body['input_type']:
                raise self.CreateRuleError(f'cannot change rule-type')
        except self.CreateRuleError as ex:
            return error_response({'path': request.path, 'error': str(ex)})

        # Test a rule precisely.
        item_df = create_item_df_from_request(body['convert'], columns=self.cv.get_rule_item_form().keys())
        if len(item_df) == 0:
            return error_response({'path': request.path, 'error': 'no rule-item', 'type': 'header'})

        item_df = item_df.drop(['is_new', 'data', 'id', 'index'], axis=1)

        # Test validity of converting rules
        custom_items = item_df[item_df['type'] == "custom"]
        type_list = item_df['type'].unique().tolist()
        for type_info in type_list:
            if type_info == "custom":
                continue
            item = item_df[item_df['type'] == type_info]

            # test_rule_item = header + custom OR no_header_xx + custom
            if len(custom_items) > 0 and type_info != "info":
                item = pd.concat([item, custom_items])

            # change no_header_3,4,5 ...  -> no_header (only test_rule_item)
            if "no_header" in item['type'].values[0]:
                item.loc[item['type'] == item['type'].values[0], 'type'] = "no_header"

            for _, value in item.iterrows():
                report = self.cv.test_rule_item(value, item.drop(_))
                if len(report) > 0:
                    return error_response({'path': request.path, 'error': f"{report[0]['reason']} ({report[0]['name']} / {report[0]['key']})", 'type': f"{value['type']}"})


        # Test filters
        pass

        rule = list()
        filter = None

        try:
            # Create a rule.
            for rule_name in item_df['type'].unique().tolist():
                ret = self.cv.create_rule(log['id'], rule_name, check_exist=not modify)
                if len(ret) != 0:
                    item_df.loc[item_df['type'] == rule_name, 'rule_id'] = ret['id']
                    rule.append(ret['id'])

            # Create items
            for _, elem in item_df.iterrows():
                ret = self.cv.create_rule_item(elem)
                if ret is None:
                    raise RuntimeError('failed to create %s items' % elem['type'])
            # Create filters
            # `clone` means the method is gonna copy filter-items
            # from the filter already committed after a filter has created.
            filter = self.cv.create_filter(log['id'], clone=False)

            for item in body['filter']:
                ret = self.cv.create_filter_item(filter['id'], item['name'], item['type'], item['condition'])
                if ret is None:
                    raise RuntimeError('failed to create filter items')

            if not modify:
                for rule_id in rule:
                    self.cv.commit_rule(rule_id)
                self.cv.commit_filter(filter['id'])
            return json_response(200, {'rule_id': rule, 'filter_id': filter['id']})
            # return json_response(200, {'rule_id': rule['id'], 'filter_id': filter['id']})

        except RuntimeError as ex:
            # Roll back the rule definition.
            if rule is not None:
                for rule_id in rule:
                    self.cv.delete_rule(rule_id)
            if filter is not None:
                self.cv.delete_filter(filter['id'])
            return error_response({'path': request.path, 'error': str(ex)})

    def _modify_rule(self, log_id, body):
        self.load()

        origin_rules = self.cv.get_rule(log_id)
        if len(origin_rules) == 0:
            return error_response({'path': request.path, 'error': 'invalid log_id '+log_id})
        resp = self._create_rule(body, modify=True)
        if resp.status_code == 200:
            for origin_rule in origin_rules:
                self.cv.delete_rule(origin_rule['id'])
            for rule_id in resp.json['rule_id']:
                self.cv.commit_rule(rule_id)
            self.cv.commit_filter(resp.json['filter_id'])
            print('clear convert error for ', log_id)
            self.cv.clear_error(log_id)
        return resp


class ConvertIoRuleController2(ConvertIoModuleLoader):

    def get_rule_list(self, log_id):
        self.load()
        rules = self.cv.get_rule_list(log_id)
        rules = cast_rule_list_response(rules)
        return json_response(200, rules)

    def create_rule(self, log_id, rule_name):
        self.load()
        rule = self.cv.create_rule(log_id, rule_name)
        return json_response(200, rule)

    def commit_rule(self, rule_id):
        self.load()

        rule = self.cv.commit_rule(rule_id)
        if rule is None:
            return error_response({'path': request.path, 'error': 'invalid rule-id'})
        return json_response(200, {'id': rule['id']})

    def delete_rule(self, rule_id):
        self.load()
        self.cv.delete_rule(rule_id)
        return json_response(200, {})

    def get_rule_item_detail_info(self, log_id):

        def set_null_rule_item(target_df, item_type, max_col, row):
            ret = list()
            if max_col != len(target_df["col_index"]):
                col_index_list = target_df["col_index"].to_list()
                for idx in range(target_df["col_index"].max()):
                    if idx + 1 not in col_index_list:
                        data = dict()
                        data['type'] = item_type
                        data['name'] = 'null'
                        data['col_index'] = idx + 1
                        data['row_index'] = 0
                        data['coef'] = 0
                        data['row_index'] = row
                        data['re_group'] = 0
                        data['id'] = 0
                        data['rule_id'] = 0
                        ret.append(data)
            return ret

        self.load()

        rule_list = self.cv.get_rule_list(log_id)
        if rule_list is None:
            return error_response({'path': request.path, 'error': 'invalid rule-id'})

        log = self.cv.get_log_by_id(log_id)
        rule_item_detail = self.cv.get_log_list(log_name=log['log_name'])
        rule_item_detail = build_log_list(rule_item_detail)
        rule_item_detail = dict(rule_item_detail[0])

        items = pd.DataFrame()
        for rule in rule_list:
            items = items.append(self.cv.get_rule_items(rule['id'], df=True))

        # create null data(only no_header / info)
        for item_type in items['type'].unique().tolist():
            if item_type.find(const.item_type_no_header) == 0:
                target_df = items[items['type'] == item_type]
                split_str = item_type.split('_')
                max_col = int(split_str[2])
                null_data_list = set_null_rule_item(target_df, item_type, max_col, 0)
                for null_data in null_data_list:
                    items = items.append(null_data, ignore_index=True)

            if item_type == const.item_type_info:
                info_df = items[items['type'] == const.item_type_info]
                info_row_list = info_df['row_index'].to_list()
                for row in info_row_list:
                    target_df = info_df[info_df['row_index'] == row]
                    max_col = target_df["col_index"].max()
                    null_data_list = set_null_rule_item(target_df, item_type, max_col, row)
                    for null_data in null_data_list:
                        items = items.append(null_data, ignore_index=True)

        items = items.replace({np.nan: None, '': None})
        items = items.sort_values(by=['col_index'], axis=0)
        items = items.reindex()
        items = items.to_dict(orient='records')

        rule_item_detail['convert'] = {
            const.item_type_info: list(),
            const.item_type_header: list(),
            const.item_type_no_header: list(),
            const.item_type_custom: list()
        }

        for item in items:
            if item['type'] == const.item_type_info or item['type'].find(const.item_type_no_header) == 0:
                item_type = item['type']
                key = item['row_index']
                if item['type'].find(const.item_type_no_header) == 0:
                    item_type = const.item_type_no_header
                    split_str = item['type'].split('_')
                    key = int(split_str[2])

                detail = dict()
                idx = 0
                for value in rule_item_detail['convert'][item_type]:
                    # no_header key & info key = row_index
                    if value['key'] == key:
                        value['rule'].append(item)
                        detail = copy.deepcopy(value)
                        rule_item_detail['convert'][item_type][idx] = detail
                        break
                    idx = idx + 1

                if not detail:
                    detail['key'] = key
                    detail['rule'] = list()
                    detail['rule'].append(item)
                    rule_item_detail['convert'][item_type].append(detail)
            else:
                rule_item_detail['convert'][item['type']].append(item)

        return json_response(200, rule_item_detail)

    # def create_rule_item(self, rule_id, body):
    #     self.load()
    #     form = self.cv.get_rule_item_form()
    #     for k in body:
    #         form[k] = body[k]
    #     form['rule_id'] = rule_id
    #     item = self.cv.create_rule_item(form)
    #     return json_response(200, item)

    def clone_rule(self, rule_id):
        self.load()
        rule = self.cv.modify_rule(rule_id)
        if rule is None:
            return error_response({'path': request.path, 'error': 'invalid rule-id'})
        return json_response(200, rule)


class ConvertIoLogPreviewController:

    preview_lines = 30
    max_line_characters = 1000

    def preview_csv(self, files):
        if len(files) == 0:
            logger.error(f"{request.path} no file to preview")
            return error_response({'path': request.path, 'error': 'no file to preview'})

        file_data = files[0].read(self.preview_lines * self.max_line_characters)
        file_data = file_data.decode('utf-8')
        lines = file_data.split('\n')
        if len(lines) < self.preview_lines:
            lines = lines[0:len(lines)]
        else:
            lines = lines[0:self.preview_lines]

        row = dict()
        rows = 1
        max_cols = 0
        for line in lines:
            line = delete_line_end(line)
            if len(line) == 0:
                continue
            elem = [None if len(_) == 0 else _.strip() for _ in line.split(',')]
            row[str(rows)] = dict()
            cols = 1
            for el in elem:
                row[str(rows)][str(cols)] = el
                cols += 1
            if max_cols < cols:
                max_cols = cols
            rows += 1

        data = {
            'disp_order': [str(_) for _ in range(1, max_cols)],
            'row': row,
            'text': None
        }

        return json_response(200, {'data': data})

    def preview_regex(self, files):
        if len(files) == 0:
            logger.error(f"{request.path} no file to preview")
            return error_response({'path': request.path, 'error': 'no file to preview'})

        file_data = files[0].read(self.preview_lines * self.max_line_characters)
        file_data = file_data.decode('utf-8')

        return json_response(200, {'data': {
            'disp_order': None,
            'row': None,
            'text': file_data
        }})


class ConvertIoConvertPreviewController(ConvertIoModuleLoader):
    preview_lines = 30
    max_line_characters = 1000

    def convert_preview_csv(self, body):
        self.load()

        data = body['data']

        item_df = create_item_df_from_request(body['convert'], columns=self.cv.get_rule_item_form().keys())
        if len(item_df) == 0:
            return error_response({'path': request.path, 'error': 'emtpy header table', 'type': 'header'})

        if data is None or data['disp_order'] is None or data['row'] is None:
            convert_df, err = self.cv.create_convert_preview_df(None, item_df)
            if len(err) > 0:
                return error_response({'path': request.path, 'error': err['error'], 'type': err['type']})
            return json_response(200, {})

        data_df = pd.DataFrame(columns=data['disp_order'])
        for i in range(self.preview_lines):
            if str(i) in data['row']:
                data_df = data_df.append(data['row'][str(i)], ignore_index=True)

        convert_df, err = self.cv.create_convert_preview_df(data_df, item_df)
        if len(convert_df) == 0 and len(err) > 0:
            # preview method returned an error report.
            return error_response({'path': request.path, 'error': err['error'], 'type': err['type']})

        if len(convert_df) != 0:
            # 下記の場合はデータとして格納できないので削除
            # ケース１：全rowがnull場合
            # ケース２：log_timeがnull場合
            convert_df = convert_df.dropna(axis=0, how='all')
            convert_df = convert_df[convert_df['log_time'].notna()]
            convert_df.reset_index(inplace=True, drop=True)

        data = {
            'disp_order': convert_df.columns.tolist(),
            'row': dict()
        }
        for irow, row in convert_df.iterrows():
            data['row'][str(irow+1)] = row.to_dict()

        return json_response(200, {'data': data})

    def convert_preview_regex(self, body):
        self.load()

        item_df = create_item_df_from_request(body['convert'], columns=self.cv.get_rule_item_form().keys())

        if body['data'] is None:
            convert_df, report = self.cv.create_convert_regex_preview_df(None, item_df)
            if len(report) > 0:
                return error_response({'path': request.path, 'error': report['error'], 'type': report['type']})
            return json_response(200, {})

        input_raw = body['data']['text']
        convert_df, report = self.cv.create_convert_regex_preview_df(input_raw, item_df)
        if len(convert_df) == 0 and len(report) > 0:
            # preview method returned an error report.
            return error_response({'path': request.path, 'error': report['error'], 'type': report['type']})

        data = {
            'disp_order': convert_df.columns.tolist(),
            'row': {
                '1': convert_df.iloc[0].to_dict()
            }

        }
        return json_response(200, {'data': data})


class ConvertIoDataTransportController(ConvertIoModuleLoader):

    sem = None
    table_list = [
        'log_define_master', 'convert_rule', 'convert_rule_item', 'convert_filter', 'convert_filter_item'
    ]

    @classmethod
    def get_semaphore(cls):
        if cls.sem is None:
            cls.sem = threading.Semaphore()
        cls.sem.acquire()

    @classmethod
    def put_semaphore(cls):
        if cls.sem is not None:
            cls.sem.release()

    def import_convert_data(self, files):
        try:
            if len(files) == 0:
                return error_response({'path': request.path, 'error': 'no files parameter'})

            file = files[0]
            ConvertIoDataTransportController.get_semaphore()
            self.load()

            if '.xlsx' not in file.filename.lower():
                return error_response({'path': request.path, 'error': 'invalid file extension'})

            backup_dict = self.cv.get_table_backup_df(self.table_list)

            table_dict = dict()
            for tbl in self.table_list:
                try:
                    table_dict[tbl] = pd.read_excel(file, sheet_name=tbl, engine='openpyxl')
                except ValueError as ex:
                    print(f'no sheet {tbl}. skip this.')

            try:
                self.cv.restore_table(table_dict)
            except Exception as ex:
                print('failed to restore data from excel. try to recovery the origin')
                print(ex)
                self.cv.restore_table(backup_dict)
                return error_response({'path': request.path, 'error': 'failed to restore data'})

            return json_response(200, {})

        except Exception as ex:
            print(ex)
        finally:
            ConvertIoDataTransportController.put_semaphore()

        return error_response({'path': request.path, 'error': 'unexpected error'})

    def export_convert_data(self):

        try:
            ConvertIoDataTransportController.get_semaphore()
            self.load()

            out_file = os.path.join(JOB_ROOT, f'convert_table_dump.xlsx')
            if os.path.exists(out_file):
                os.remove(out_file)

            table_dict = self.cv.get_table_backup_df(self.table_list)

            writer = pd.ExcelWriter(out_file, engine='openpyxl', mode='w')
            for tbl in table_dict:
                if table_dict[tbl] is not None:
                    table_dict[tbl].to_excel(writer, sheet_name=tbl, index=False, encoding='utf-8')
            writer.save()

            if os.path.exists(out_file):
                return send_file(out_file, as_attachment=True)
            return error_response({'path': request.path, 'error': 'failed to create backup data'})

        except Exception as ex:
            print(ex)
        finally:
            ConvertIoDataTransportController.put_semaphore()

        return error_response({'path': request.path, 'error': 'unexpected error'})

    def import_column_define(self, files):
        try:
            if len(files) == 0:
                return error_response({'path': request.path, 'error': 'no files parameter'})

            file = files[0]
            ConvertIoDataTransportController.get_semaphore()
            self.load()

            if '.xlsx' not in file.filename.lower():
                return error_response({'path': request.path, 'error': 'invalid file extension'})

            table_list = ['column_define']
            backup_dict = self.cv.get_table_backup_df(table_list)

            table_dict = dict()
            for tbl in table_list:
                try:
                    table_dict[tbl] = pd.read_excel(file, sheet_name=tbl, engine='openpyxl')
                except ValueError as ex:
                    print(f'no sheet {tbl}. skip this.')


            try:
                self.cv.restore_table(table_dict)
            except Exception as ex:
                print('failed to restore data from excel. try to recovery the origin')
                print(ex)
                self.cv.restore_table(backup_dict)
                return error_response({'path': request.path, 'error': 'failed to restore data'})

            return json_response(200, {})

        except Exception as ex:
            print(ex)
        finally:
            ConvertIoDataTransportController.put_semaphore()

        return error_response({'path': request.path, 'error': 'unexpected error'})

    def export_column_define(self):
        try:
            ConvertIoDataTransportController.get_semaphore()
            self.load()

            out_file = os.path.join(JOB_ROOT, f'column_define_table_dump.xlsx')
            if os.path.exists(out_file):
                os.remove(out_file)

            table_list = ['column_define']
            table_dict = self.cv.get_table_backup_df(table_list)
            table_dict['column_define'] = table_dict['column_define'].drop(['id'], axis=1)

            writer = pd.ExcelWriter(out_file, engine='openpyxl', mode='w')
            for tbl in table_dict:
                if table_dict[tbl] is not None:
                    table_dict[tbl].to_excel(writer, sheet_name=tbl, index=False, encoding='utf-8')
            writer.save()

            if os.path.exists(out_file):
                return send_file(out_file, as_attachment=True)
            return error_response({'path': request.path, 'error': 'failed to create backup data'})

        except Exception as ex:
            print(ex)
        finally:
            ConvertIoDataTransportController.put_semaphore()

        return error_response({'path': request.path, 'error': 'unexpected error'})


@convert_io.route('/import', methods=['POST'])
class ConvertIoImportRouter(Resource, ConvertIoDataTransportController):

    def post(self):
        return handle_base_exception(self.import_convert_data, {'files': request.files.getlist('files')})


@convert_io.route('/export', methods=['GET'])
class ConvertIoExportRouter(Resource, ConvertIoDataTransportController):

    def get(self):
        return handle_base_exception(self.export_convert_data, {})


@convert_io.route('/define/import', methods=['POST'])
class ConvertIoImportRouter(Resource, ConvertIoDataTransportController):

    def post(self):
        return handle_base_exception(self.import_column_define, {'files': request.files.getlist('files')})


@convert_io.route('/define/export', methods=['GET'])
class ConvertIoExportRouter(Resource, ConvertIoDataTransportController):

    def get(self):
        return handle_base_exception(self.export_column_define, {})


@convert_io.route('/log', methods=['GET', 'POST'])
class ConvertIoLogRouter1(Resource, ConvertIoLogController):
    def get(self):
        # <Request 'http://xxx/api/v1/convert/log?size=10&page=0&sort=log_name,asc' [GET]>
        page = request.args.get('page', default=0, type=int)
        size = request.args.get('size', default=0, type=int)
        sort, order = request.args.get('sort', default='log_name,desc', type=str).split(',')
        search = request.args.getlist('search')
        return handle_base_exception(self.get_log_list_pagination, {'page': page, 'size': size, 'sort': sort, 'order': order, 'search': search})

    def post(self):
        return handle_base_exception(self.add_log, {'body': request.json})


@convert_io.route('/log/<int:log_id>', methods=['PUT', 'DELETE', 'GET'])
class ConvertIoLogRouter2(Resource, ConvertIoLogController):
    def put(self, log_id):
        return handle_base_exception(self.modify_log, {'log_id': log_id, 'body': request.json})

    def delete(self, log_id):
        return handle_base_exception(self.delete_log, {'log_id': log_id})

    def get(self, log_id):
        return handle_base_exception(self._get_log_by_id, {'log_id': log_id})


@convert_io.route('/log/<int:log_id>/error', methods=['GET'])
class ConvertIoErrorController(Resource, ConvertIoModuleLoader):

    def _get_error(self, log_id):
        self.load()
        return json_response(200, {'error': self.cv.get_error_list(log_id)})

    def get(self, log_id):
        return handle_base_exception(self._get_error, {'log_id': log_id})


@convert_io.route('/log/<int:log_id>/error/download/<int:id>')
class ConvertIoErrorDownloadController(Resource, ConvertIoModuleLoader):

    def _download_origin_file(self, id):
        self.load()
        err = self.cv.get_error_by_id(id)
        if err is None:
            raise RuntimeError(f'error(id={id}) does not exist')
        if os.path.exists(err['path']) or not os.path.isfile(err['path']):
            raise RuntimeError(f'log file(id={id}) does not exist')

        return send_file(err['path'], as_attachment=True)

    def get(self, log_id, id):
        return handle_base_exception(self._download_origin_file, {'id': id})


@convert_io.route('/log/<int:log_id>/rule', methods=['POST', 'PUT', 'GET'])
class ConvertIoRulePatchController(Resource, ConvertIoRuleController, ConvertIoRuleController2):
    def post(self, log_id):
        return handle_base_exception(self._create_rule, {'body': request.json})

    def put(self, log_id):
        return handle_base_exception(self._modify_rule, {'log_id': log_id, 'body': request.json})

    def get(self, log_id):
        return handle_base_exception(self.get_rule_item_detail_info, {'log_id': log_id})


@convert_io.route('/log/<int:log_id>/rule/<int:rule_id>/clone', methods=['POST'])
class ConvertIoRule3(Resource, ConvertIoRuleController):
    def post(self, log_id, rule_id):
        return handle_base_exception(self.clone_rule, {'rule_id': rule_id})


@convert_io.route('/log/preview/csv', methods=['POST'])
class ConvertIoLogCsvPreviewRouter(Resource, ConvertIoLogPreviewController):
    def post(self):
        return handle_base_exception(self.preview_csv, {'files': request.files.getlist('files')})


@convert_io.route('/log/preview/regex', methods=['POST'])
class ConvertIoLogRegexPreviewRouter(Resource, ConvertIoLogPreviewController):
    def post(self):
        return handle_base_exception(self.preview_regex, {'files': request.files.getlist('files')})


@convert_io.route('/log/rule/preview/csv', methods=['POST'])
class ConvertIoConvertPreviewRouter1(Resource, ConvertIoConvertPreviewController):
    def post(self):
        return handle_base_exception(self.convert_preview_csv, {'body': request.json})


@convert_io.route('/log/rule/preview/regex', methods=['POST'])
class ConvertIoConvertPreviewRouter2(Resource, ConvertIoConvertPreviewController):

    def post(self):
        return handle_base_exception(self.convert_preview_regex, {'body': request.json})


@convert_io.route('/log/filter/preview', methods=['POST'])
class ConvertIoFilterPreview(Resource, ConvertIoModuleLoader):

    preview_lines = 30

    def post(self):
        return handle_base_exception(self._filter_preview, {'body': request.json})

    def _filter_preview(self, body):
        self.load()

        data = body['data']

        if data is None or data['disp_order'] is None or data['row'] is None:
            return json_response(200, {})

        input_df = pd.DataFrame(columns=data['disp_order'])
        for k in range(self.preview_lines):
            key = str(k+1)
            if key in data['row']:
                input_df = input_df.append(data['row'][key], ignore_index=True)

        output_df = self.cv.create_filter_preview(input_df, body['filter'])
        output_df = output_df.replace({None: np.nan})
        output_df = output_df.replace({np.nan: None})

        data['row'] = dict()
        for irow, row in output_df.iterrows():
            data['row'][str(irow + 1)] = row.to_dict()

        return json_response(200, {'data': data})


class ConvertIoColumnDefineController(ConvertIoModuleLoader):

    def get_column_define(self, col_type, page, size, sort, order, search):
        self.load()

        column_define_list, total = self.cv.get_column_define_list(col_type, page, size, sort, order, search)

        total_pages = 0
        if total != 0:
            if size == 0:
                total_pages = 1
                size = total
            else:
                total_pages = int((total+size-1)/size)

        return {
            'totalElements': total,
            'pageable': {
                'pageNumber': page,
                'pageSize': size
            },
            'totalPage': total_pages,
            'first': True if page == 0 else False,
            'last': True if (total_pages == page+1) | (total_pages == 0) else False,
            'content': column_define_list.to_dict('records'),
        }

    def add_column_define(self, col_type, body):
        self.load()
        self.cv.insert_column_define(col_type, body)
        return json_response(200, {})

    def modify_column_define(self, item_id, col_type, body):
        self.load()
        self.cv.update_column_define(item_id, col_type, body)
        return json_response(200, {})

    def delete_column_define(self, item_id):
        self.load()
        self.cv.delete_column_define(item_id)
        return json_response(200, {})

    def parse_column_define_old(self, log_id, col_type, body):
        def isfloat(param):
            try:
                float(param)
                return True
            except ValueError:
                return False

        def istimestamp(param):
            fmt = [
                '%Y-%m-%d %H:%M:%S',
                '%Y/%m/%d %H:%M:%S',
                '%Y-%m-%d',
                '%m/%d %H:%M:%S',
                '%m/%d %H:%M:%S:%f',
                '%Y/%m/%d',
                '%H:%M:%S',
                '%Y%m%d%H%M%S',
                '%Y/%m/%d %H%M%S%f',
                '%Y/%m/%d %H:%M:%S:%f'
            ]
            for f in fmt:
                try:
                    datetime.strptime(param, f)
                    return True
                except ValueError:
                    continue
            return False

        def is_valid_type(param):
            if param.isdigit() is True:
                return 'integer'
            elif param.isalpha() is True or param.isalnum() is True:
                return 'text'
            elif isfloat(param) is True:
                return 'float'
            elif istimestamp(param) is True:
                return 'timestamp'
            else:
                return 'text'

        def is_valid_name(type, data):
            if data == "":
                return 'null'
            elif type == "timestamp":
                return 'log_time'
            else:
                return data

        def is_valid_output_column(type, data):
            if data == "":
                return 'null'
            elif type == "timestamp":
                return 'log_time'
            elif type == "text":
                data = data.replace(" ", "")
                data = data.replace(".", "")
                data = data.lower()
                return data
            elif type == "integer":
                return f'_{data}'
            elif type == "float":
                data = data.replace(" ", "")
                data = data.replace(".", "")
                return f'_{data.replace("-", "")}'
            else:
                return 'null'

        self.load()
        data = []
        header = []
        rule_item = None
        rule_df = pd.DataFrame()
        find_df = pd.DataFrame()

        for value in body['data']:
            data.append(value)

        for value in body['header']:
            value = value.replace("#", "")
            header.append(value)

        rule_list = self.cv.get_rule_list(log_id)
        for rule in rule_list:
            if rule['rule_name'].lower() == col_type.lower():
                rule_item = self.cv.get_rule_items(rule['id'])
                break

        rule_name_list = list()
        if rule_item is not None:
            rule_df = pd.DataFrame(rule_item)
            rule_df = rule_df.drop(['id', 'rule_id', 'row_index', 'col_index'], axis=1)
            rule_df['new'] = False
            rule_name_list = rule_df['name'].values.tolist()

        column_define_df, total = self.cv.get_column_define_list(col_type, 0, 0, 'id', 'desc', list())

        find_df = pd.DataFrame(columns=column_define_df.columns.to_list())
        search_rule_list = [value for value in header if value not in rule_name_list]
        for value in search_rule_list:
            if len(column_define_df) != 0:
                search_column_define_df = column_define_df[column_define_df['name'].str.lower() == value.lower()]
                if len(search_column_define_df) == 0:
                    custom_dict = dict()
                    custom_dict['data_type'] = is_valid_type(data[search_rule_list.index(value)])
                    custom_dict['name'] = is_valid_name(custom_dict['data_type'], value)
                    custom_dict['output_column'] = is_valid_output_column(custom_dict['data_type'], value)
                    custom_dict['data'] = data[search_rule_list.index(value)]
                    find_df = find_df.append(custom_dict, ignore_index=True)
                    continue

                search_column_define_df = search_column_define_df.drop(['id'], axis=1)
                search_column_define_df['data'] = data[search_rule_list.index(value)]
                search_column_define_df['new'] = True
                find_df = find_df.append(search_column_define_df)
            else:
                custom_dict = dict()
                custom_dict['data_type'] = is_valid_type(data[search_rule_list.index(value)])
                custom_dict['name'] = is_valid_name(custom_dict['data_type'], value)
                custom_dict['output_column'] = is_valid_output_column(custom_dict['data_type'], value)
                custom_dict['data'] = data[search_rule_list.index(value)]
                find_df = find_df.append(custom_dict, ignore_index=True)

        if len(find_df) != 0:
            find_df = find_df.replace({np.nan: None})
            rule_df = rule_df.append(find_df)

        return json_response(200, rule_df.to_dict('records'))

    def parse_column_define(self, log_id, col_type, body):
        def isfloat(param):
            try:
                float(param)
                return True
            except ValueError:
                return False

        def istimestamp(param):
            fmt = [
                '%Y-%m-%d %H:%M:%S',
                '%Y/%m/%d %H:%M:%S',
                '%Y-%m-%d',
                '%m/%d %H:%M:%S',
                '%m/%d %H:%M:%S:%f',
                '%Y/%m/%d',
                '%H:%M:%S',
                '%Y%m%d%H%M%S',
                '%Y/%m/%d %H%M%S%f',
                '%Y/%m/%d %H:%M:%S:%f'
            ]
            for f in fmt:
                try:
                    datetime.strptime(param, f)
                    return True
                except ValueError:
                    continue
            return False

        def is_valid_type(param):
            if param == "" or param is None:
                return 'text'
            elif param.isdigit() is True:
                return 'integer'
            elif param.isalpha() is True or param.isalnum() is True:
                return 'text'
            elif isfloat(param) is True:
                return 'float'
            elif istimestamp(param) is True:
                return 'timestamp'
            else:
                return 'text'

        def is_valid_name(type, data):
            if data == "":
                return 'null'
            elif type == "timestamp":
                return 'log_time'
            else:
                return data

        def is_valid_output_column(type, data):
            if data == "":
                return 'null'
            elif type == "timestamp":
                return 'log_time'
            else:
                data = re.sub('[-=+,#/\?:^$.@*\"※~&%ㆍ!』\\‘|\(\)\[\]\<\>`\'…》]', '', data)
                data = data.replace(" ", "")
                data = data.lower()
                if data == "":
                    return 'null'
                elif data[0].isdigit() is True:
                    return f'_{data}'
                else:
                    return data

        self.load()
        data = []
        header = []
        find_df = pd.DataFrame()

        for value in body['data']:
            data.append(value)

        for value in body['header']:
            if value is None:
                continue
            value = value.replace("#", "")
            header.append(value)

        column_define_df, total = self.cv.get_column_define_list(col_type, 0, 0, 'id', 'desc', list())

        find_df = pd.DataFrame(columns=column_define_df.columns.to_list())
        for value in header:
            if len(column_define_df) != 0:
                search_column_define_df = column_define_df[column_define_df['name'] == value]
                if len(search_column_define_df) == 0:
                    custom_dict = dict()
                    custom_dict['type'] = col_type
                    custom_dict['data_type'] = is_valid_type("" if len(data) == 0 or len(data) <= header.index(value) else data[header.index(value)])
                    custom_dict['name'] = is_valid_name(custom_dict['data_type'], value)
                    custom_dict['output_column'] = is_valid_output_column(custom_dict['data_type'], value)
                    custom_dict['data'] = "" if len(data) == 0 or len(data) <= header.index(value) else data[header.index(value)]
                    find_df = find_df.append(custom_dict, ignore_index=True)
                    continue

                search_column_define_df = search_column_define_df.drop(['id'], axis=1)
                search_column_define_df['data'] = data[header.index(value)]
                search_column_define_df['new'] = True
                find_df = find_df.append(search_column_define_df)
            else:
                custom_dict = dict()
                custom_dict['type'] = col_type
                custom_dict['data_type'] = is_valid_type(data[header.index(value)])
                custom_dict['name'] = is_valid_name(custom_dict['data_type'], value)
                custom_dict['output_column'] = is_valid_output_column(custom_dict['data_type'], value)
                custom_dict['data'] = data[header.index(value)]
                find_df = find_df.append(custom_dict, ignore_index=True)

        if len(find_df) != 0:
            find_df = find_df.replace({np.nan: None})
            # rule_df = rule_df.append(find_df)

        return json_response(200, find_df.to_dict('records'))

@convert_io.route('/define/header', methods=['POST', 'GET'])
class ConvertIoGetHeaderDefine(Resource, ConvertIoColumnDefineController):
    def get(self):
        page = request.args.get('page', default=0, type=int)
        size = request.args.get('size', default=0, type=int)
        sort, order = request.args.get('sort', default='id,desc', type=str).split(',')
        search = request.args.getlist('search')
        col_type = 'header'
        return handle_base_exception(self.get_column_define, {'col_type': col_type, 'page': page, 'size': size, 'sort': sort, 'order': order,'search': search})

    def post(self):
        col_type = 'header'
        return handle_base_exception(self.add_column_define, {'col_type': col_type, 'body': request.json})


@convert_io.route('/define/info', methods=['POST', 'GET'])
class ConvertIoGetInfoDefine(Resource, ConvertIoColumnDefineController):
    def get(self):
        page = request.args.get('page', default=0, type=int)
        size = request.args.get('size', default=0, type=int)
        sort, order = request.args.get('sort', default='id,desc', type=str).split(',')
        search = request.args.getlist('search')
        col_type = 'info'
        return handle_base_exception(self.get_column_define, {'col_type': col_type, 'page': page, 'size': size, 'sort': sort, 'order': order, 'search': search})

    def post(self):
        col_type = 'info'
        return handle_base_exception(self.add_column_define, {'col_type': col_type, 'body': request.json})


@convert_io.route('/define/regex', methods=['POST', 'GET'])
class ConvertIoGetRegexDefine(Resource, ConvertIoColumnDefineController):
    def get(self):
        page = request.args.get('page', default=0, type=int)
        size = request.args.get('size', default=0, type=int)
        sort, order = request.args.get('sort', default='id,desc', type=str).split(',')
        search = request.args.getlist('search')
        col_type = 'regex'
        return handle_base_exception(self.get_column_define, {'col_type': col_type, 'page': page, 'size': size, 'sort': sort, 'order': order, 'search': search})

    def post(self):
        col_type = 'regex'
        return handle_base_exception(self.add_column_define, {'col_type': col_type, 'body': request.json})


@convert_io.route('/define/header/<int:item_id>', methods=['PUT', 'DELETE'])
class ConvertIoHeaderDefine(Resource, ConvertIoColumnDefineController):
    def put(self, item_id):
        col_type = 'header'
        return handle_base_exception(self.modify_column_define, {'item_id': item_id, 'col_type': col_type, 'body': request.json})

    def delete(self, item_id):
        return handle_base_exception(self.delete_column_define, {'item_id': item_id})


@convert_io.route('/define/info/<int:item_id>', methods=['PUT', 'DELETE'])
class ConvertIoInfoDefine(Resource, ConvertIoColumnDefineController):
    def put(self, item_id):
        col_type = 'info'
        return handle_base_exception(self.modify_column_define, {'item_id': item_id, 'col_type': col_type, 'body': request.json})

    def delete(self, item_id):
        return handle_base_exception(self.delete_column_define, {'item_id': item_id})


@convert_io.route('/define/regex/<int:item_id>', methods=['PUT', 'DELETE'])
class ConvertIoRegexDefine(Resource, ConvertIoColumnDefineController):
    def put(self, item_id):
        col_type = 'regex'
        return handle_base_exception(self.modify_column_define, {'item_id': item_id, 'col_type': col_type, 'body': request.json})

    def delete(self, item_id):
        return handle_base_exception(self.delete_column_define, {'item_id': item_id})


@convert_io.route('/define/header/<int:log_id>/parse', methods=['POST'])
class ConvertIoRegexDefine(Resource, ConvertIoColumnDefineController):
    def post(self, log_id):
        col_type = 'header'
        return handle_base_exception(self.parse_column_define, {'log_id': log_id, 'col_type': col_type, 'body': request.json})


@convert_io.route('/option')
class ConvertIoSpecification(Resource):
    def get(self):
        resp = {
            'data_type': const.data_type_list,
            'def_type': const.def_type_list,
            'filter_type': const.filter_type_list
        }
        return json_response(200, resp)


@convert_io.route('/table', methods=['GET'])
class ConvertIoGetTableInf(Resource, ConvertIoModuleLoader):
    # `hidden_column` is information that is for server-side service.
    # When user requests column information in table, the columns that described in below will not included in response.
    hidden_column = ['id', 'request_id', 'created_time']

    def _get_table_and_columns(self, args):
        self.load()

        fab = str(args['fab'])
        log_list = self.cv.get_log_list()
        if log_list is None:
            return error_response({'path': request.path, 'error': 'failed to get log definitions'})
        resp = dict()
        for log in log_list:
            fab_list = [] if log['fab'] is None or log['fab'] else log['fab'].split(',')
            if log['fab'] == '' or len(fab_list) == 0 or fab in fab_list:
                table = log['table_name']
                if table is not None and table != '':
                    if not exist_table(self.cv.convert_db, self.cv.convert_schema, table):
                        continue
                    columns = [_ for _ in get_table_column_list(self.cv.convert_db, self.cv.convert_schema, table)
                               if _ not in self.hidden_column]
                    resp[table] = columns
        return json_response(200, resp)

    def get(self):
        return handle_base_exception(self._get_table_and_columns, {'args': request.args})


@convert_io.route('/query', methods=['POST'])
class ConvertIoTestQuery(Resource, ConvertIoModuleLoader):

    def post(self):
        return handle_base_exception(self._test_query, {'body': request.json})

    def _test_query(self, body):
        self.load()

        columns = ','.join(body['columns'])
        table = body['table']
        where = '' if ('where' not in body or body['where'] == '') else f"where {body['where']}"
        sql = f"select {columns} from {self.cv.convert_schema}.{table} {where}"
        try:
            do_query(self.cv.convert_db, sql)
        except RuntimeError as ex:
            return error_response({'path': request.path, 'error': str(ex)})
        return 200


def handle_base_exception(func, args={}):
    try:
        return func(**args)
    except Exception as ex:
        logger.debug(traceback.format_exc())
        logger.error(f"{request.path} {str(ex)}")
        body = {'path': request.path, 'error': str(ex)}
        return error_response(body)
    return error_response({'error': 'undefined error occurs'})


def cast_fetch_body(body):
    if 'input_type' in body:
        body['input_type'] = body.pop('input_type')
    if 'select' in body:
        body['fab'] = create_comma_string(body.pop('select'))
    if 'table_name' in body:
        body['table'] = body.pop('table_name')
    if 'tag' in body:
        body['tag'] = create_comma_string(body['tag'])
    if 'ignore' in body:
        body['ignore'] = create_comma_string(body['ignore'])
    return body


def cast_rule_list_response(rules):
    for rule in rules:
        rule = cast_rule_response(rule)
    return rules


def cast_rule_response(rule):
    rule['input_type'] = rule.pop('input_type')
    rule.pop('commit')
    return rule


def build_log_list(logs):
    for log in logs:
        log['rule'] = False if log.pop('rule') == 0 else True
        log['errors'] = log.pop('error')
        log['select'] = [int(_) for _ in log.pop('fab').split(',') if _ != '']
        log['tag'] = [str(_) for _ in log.pop('tag').split(',') if _ != '']
        log['ignore'] = [str(_) for _ in log.pop('ignore').split(',') if _ != '']
    return logs


def create_comma_string(fab_list):
    _select = [str(_).strip() for _ in fab_list]
    return ','.join(_select)


def create_item_df_from_request(items: dict, columns):
    item_df = pd.DataFrame(columns=columns)

    def insert_rule_item_into_df(df, item_key):
        for item in items[item_key]:
            if 'type' not in item:
                item['type'] = item_key
            df = df.append(item, ignore_index=True)
        return df

    def insert_rule_item_into_df_with_key(df, item_key):
        for item in items[item_key]:
            for rule in item['rule']:
                if item_key == 'no_header':
                    column_count = item['key']
                    rule['type'] = f'no_header_{column_count}'
                else:
                    rule['row_index'] = item['key']
                    rule['type'] = item_key

                if rule['output_column'] is None:
                    continue
                df = df.append(rule, ignore_index=True)
        return df

    item_df = insert_rule_item_into_df_with_key(item_df, 'info')
    item_df = insert_rule_item_into_df(item_df, 'header')
    item_df = insert_rule_item_into_df(item_df, 'custom')
    item_df = insert_rule_item_into_df_with_key(item_df, 'no_header')

    item_df['rule_id'] = 999999999
    item_df['rule_id'] = item_df['rule_id'].astype(int)
    item_df = item_df.replace({np.nan: None})
    item_df['coef'] = item_df['coef'].replace({'': 0, np.nan: 0, None: 0})
    item_df['re_group'] = item_df['re_group'].replace({'': 0, np.nan: 0, None: 0})
    item_df['row_index'] = item_df['row_index'].replace({np.nan: 999999999})
    item_df['row_index'] = item_df['row_index'].astype(int)
    item_df['col_index'] = item_df['col_index'].replace({np.nan: 999999999})
    item_df['col_index'] = item_df['col_index'].astype(int)
    # item_df['skip'] = item_df['skip'].replace({None: False})

    return item_df


def json_response(status, body):
    response = make_response(jsonify(body), status)
    response.headers['Content-type'] = 'application/json; charset=utf-8'
    return response


def error_response(body):
    ret = {'cras_error': body}
    response = make_response(jsonify(ret), 500)
    response.headers['Content-type'] = 'application/json; charset=utf-8'
    return response
