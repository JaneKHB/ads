from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace
from system_logger import SystemLogger
from controller.step_decorator import response_handler, client_id
from controller.step_exception import StepBadRequest
import service.step.step_service as do
from dao.dao_system_logger import SystemLoggerDao
import json
import os

execute_io = Namespace('ExecuteIO', description='It serves a user to run script executables on server.')
logger = SystemLogger('srv', 'ctrl')


@execute_io.route('/py', methods=['POST'])
class PyExecuteTestScript(Resource):
    @client_id
    @response_handler(True)
    def post(self, client):
        if request.content_type.startswith('multipart/form-data'):
            data = {}
            files = request.files.getlist('files')
            if files is not None:
                data['files'] = files

        else:
            raise StepBadRequest('invalid content-type')

        pid = do.do_test_scripts_process(client, **data)
        return {'rid': pid}


@execute_io.route('/py/<string:rid>', methods=['GET'])
class PyExecuteTestScriptWithParam(Resource):

    @client_id
    @response_handler(True)
    def get(self, client, rid):
        info = do.get_status_by_pid(client, rid)
        if info is not None and 'status' in info:
            if info['status'] == 'error':
                info['error'] = list()
                d_list = do.get_error_list_in_process(rid)
                for d in d_list:
                    info['error'].append('%s: %s: %s' % (d['ts'].strftime('%Y-%m-%d %H:%M:%S'), d['module'], d['msg']))

            elif info['status'] == 'success':
                # Put console output into the response
                info['output'] = do.get_test_output(client, rid)

        return {**info}
