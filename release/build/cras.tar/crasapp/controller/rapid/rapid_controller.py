import logging
import random
from flask import Response, request, make_response, jsonify
from flask_restx import Resource, Namespace
from dao import ConfigDao
from dao.dao_base import DAOBaseClass
from dao.dao_base_server import BaseServerDao
from service.rapid.exception import RapidConnectionError
from service.rapid.rapidconnector import RapidConnector
from system_logger import SystemLogger

logger = SystemLogger('srv', 'ctrl')
Rapid = Namespace('Rapid')


@Rapid.route('/plan')
class RapidCollectorGetPlanList(Resource):
    def get(self):
        """
        Return plans information from the rapid collector.
        """
        logger.info(f'{request.method} {request.path}')
        config = ConfigDao.rapid()
        bad_param = [_bad for _bad in config if config[_bad] is None]
        if len(bad_param):
            return Response(status=400, response='parameter error')

        connector = RapidConnector(config)
        plans = connector.get_plans()
        plans = [_ for _ in plans if _['planType'] == 'ftp']
        response = make_response(jsonify(plans), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


# @Rapid.route('/machine')
class RapidCollectorGetMachineList(Resource):
    # This API will be deprecated.
    # It's planning that all information about equipments(machines) will be got from rapid collector.
    # Rapid collector doesn't supply enough information to fill the equipments table for now,
    # So it services 2 API ('/rc/machine' and '/rc/equipment') at first.
    def get(self):
        """
        Return machines(equipments) information from the rapid collector.
        """
        logger.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        bad_param = [_bad for _bad in config if config[_bad] is None]
        if len(bad_param):
            return Response(status=400, response='parameter error')

        connector = RapidConnector(config)
        machines = connector.get_machines()
        response = make_response(jsonify(machines), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@Rapid.route('/equipment')
class RapidCollectorGetEquipment(Resource):
    def get(self):
        """
        Return equipments information from the database.
        """
        fab = request.args.get('fab', type=str, default=None)
        logger.info(f'{request.method} {request.path} fab={fab}')

        serverDao = BaseServerDao(ConfigDao.monitor_db())
        equipments = serverDao.get_equipment_df(fab)

        equip_list = equipments.to_dict(orient='records')
        response = make_response(jsonify(equip_list), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        """
        [SAMPLE]
        [
        {'equipment_id': 'MPAUltmIKZEBXNcA', 'equipment_name': 'CrasServerhan_Line1_MPA_2', 'fab_name': 'Line1', 'inner_tool_id': '2', 'machinename': 'MPA_2', 'tool_id': 'MPA', 'tool_serial': 'serial', 'tooltype': 'tooltyp', 'user_name': 'CrasServerhan'}, 
        {'equipment_id': 'MPAngygwGBdqgYgX', 'equipment_name': 'CrasServerhan_Line1_MPA_208', 'fab_name': 'Line1', 'inner_tool_id': '208', 'machinename': 'MPA_208', 'tool_id': 'MPA', 'tool_serial': 'qq', 'tooltype': 'tt', 'user_name': 'CrasServerhan'}, 
        {'equipment_id': 'MPAeHc4D6dtqXHdV', 'equipment_name': 'CrasServerhan_Line1_227MPA_2', 'fab_name': 'Line1', 'inner_tool_id': '2', 'machinename': '227MPA_2', 'tool_id': '227MPA', 'tool_serial': 'serial', 'tooltype': 'tooltype', 'user_name': 'CrasServerhan'}
        ]
        """
        return response


@Rapid.route('/valid')
class RapidCollectorConnectionCheck(Resource):
    def get(self):
        """
        Check if the rapid collector available.
        """
        logger.info(f'{request.method} {request.path}')
        config = {
            'host': request.args.get('host', type=str),
            'port': request.args.get('port', default=80, type=int),
            'user': request.args.get('user', type=str),
            'password': request.args.get('pass', type=str)
        }
        # config = ConfigDao.rapid()
        try:
            connect = RapidConnector(config)
            if connect.me():
                return Response(status=200)
        except RapidConnectionError as msg:
            print('rapid valid error', str(msg))
            return Response(status=500, response=str(msg))


@Rapid.route('/category')
class RapidCollectorGetCategory(Resource):
    def get(self):
        rapid_connect = RapidConnector(ConfigDao.rapid())
        category_list = rapid_connect.get_categories()
        response = make_response(jsonify(category_list), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        """
        [SAMPLE]
        [
        {'auto': True, 'categoryCode': '001', 'categoryName': 'RUNNING_STATUS', 'description': '', 'dest': 'Cons', 'display': True, 'fileName': '*', 'filePath': '/LOG/001', 'port': 21}, 
        {'auto': True, 'categoryCode': '002', 'categoryName': 'RUNNING_STATUS(event)', 'description': '', 'dest': 'Cons', 'display': True, 'fileName': '*', 'filePath': '/LOG/002', 'port': 21}, 
        {'auto': True, 'categoryCode': '003', 'categoryName': 'ErrorLog', 'description': '', 'dest': 'Cons', 'display': True, 'fileName': '*', 'filePath': '/LOG/003', 'port': 21}, 
        {'auto': True, 'categoryCode': '004', 'categoryName': 'ADCMEASUREMENT dummy', 'description': '', 'dest': 'Cons', 'display': True, 'fileName': '*', 'filePath': '/LOG/ADCMEASUREMENT', 'port': 21}, 
        {'auto': True, 'categoryCode': '0C9', 'categoryName': 'OperationLog', 'description': '', 'dest': 'Cons', 'display': True, 'fileName': '*', 'filePath': '/LOG/OperationLog', 'port': 21}, 
        {'auto': False, 'categoryCode': '143', 'categoryName': 'logserver', 'description': '', 'dest': 'Logsv', 'display': True, 'fileName': 'YYMMDD/ALL_DATA/*/* ', 'filePath': '/VROOT/COMPAT/LOG', 'port': 22001}, 
        {'auto': True, 'categoryCode': '1F5', 'categoryName': 'Running', 'description': '', 'dest': 'Cons', 'display': True, 'fileName': '*', 'filePath': '/LOG/RUNNING', 'port': 21}, 
        ]
        """
        return response


@Rapid.route('/equipment/sync')
class RapidCollectorGetEquipmentSync(Resource):
    def get(self):
        """
        Return equipments information from the database & Refresh equipment table.
        """
        def generate_equimentid(length):
            prefix = "MPA"
            ramdom_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
                           'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
            random_length = length - len(prefix)
            random_char = random.sample(ramdom_list, random_length)
            random_str = ''.join(str(char) for char in random_char)
            return f'{prefix}{random_str}'

        logger.info(f'{request.method} {request.path}')

        user = ConfigDao.user_name()
        rapid_connect = RapidConnector(ConfigDao.rapid())

        equipments = rapid_connect.get_machines()
        equipments = rapid_connect.machines_to_df(equipments, user=user)

        # equipment table
        eqp_storage_if = DAOBaseClass(**ConfigDao.cras_db())
        stored_equipments_df = eqp_storage_if.execute_by_spl(f"select * from cras_db.equipments")

        column_list = ['machineName', 'fab_name', 'tool_serial', 'toolType', 'tool_id', 'inner_tool_id', 'user_name', 'equipment_name']
        if 'equipment_id' in equipments.columns:
            column_list.append('equipment_id')

        equipments_df = equipments.loc[:, column_list]

        if len(stored_equipments_df) != 0:
            ##################################################################
            # database(equipment id)   --   rapid collector(equipment id)
            #  + mpa_12ab                    + mpa_12ab
            #  + mpa_23ed                    + mpa_23ed
            #  + mpa_34rh                    + mpa_58fc
            #
            #  insert : mpa_58fc
            #  update : mpa_12ab, mpa_23ed
            #  delete : mpa_34rh
            ##################################################################

            stored_equipments_id_list = stored_equipments_df['equipment_id'].tolist()

            # equipmentIdがない旧Rapid Collectorに対しての例外処理
            # ケース１：保存されているmachineNameがある場合、そのequipmentIdを使う
            # ケース２：保存されているmachineNameがない場合、新equipmentIdを発行
            if 'equipment_id' not in equipments_df.columns:
                stored_machine_name_list = stored_equipments_df['machinename'].tolist()
                equipment_id_list = list()
                for idx in range(len(equipments_df)):
                    machine_name = equipments_df['machineName'].values[idx]
                    if machine_name in stored_machine_name_list:
                        equipment_id_list.append(stored_equipments_df[stored_equipments_df['machinename'] == machine_name]['equipment_id'].values[0])
                    else:
                        equipment_id_list.append(generate_equimentid(16))
                equipments_df['equipment_id'] = equipment_id_list

            equipments_id_list = equipments_df['equipment_id'].tolist()

            # insert
            not_included_equipments_df = equipments_df[~equipments_df['equipment_id'].isin(stored_equipments_id_list)]
            if len(not_included_equipments_df) != 0:
                eqp_storage_if.insert_from_df('cras_db.equipments', not_included_equipments_df)

            # update
            included_equipments_df = equipments_df[equipments_df['equipment_id'].isin(stored_equipments_id_list)]
            where_info = dict()
            for idx in range(len(included_equipments_df)):
                equipments_id = included_equipments_df['equipment_id'].values[idx]
                set_info = included_equipments_df[included_equipments_df['equipment_id'] == equipments_id].to_dict(orient='records')[0]
                del set_info['equipment_id']
                where_info['equipment_id'] = equipments_id
                eqp_storage_if.update(table='cras_db.equipments', set=set_info, where=where_info)

            # delete
            not_included_stored_equipment_df = stored_equipments_df[~stored_equipments_df['equipment_id'].isin(equipments_id_list)]
            for idx in range(len(not_included_stored_equipment_df)):
                equipments_id = not_included_stored_equipment_df['equipment_id'].values[idx]
                query = f"delete from cras_db.equipments where equipment_id='%s'" % equipments_id
                eqp_storage_if.delete(query)

        else:
            if 'equipment_id' not in equipments_df.columns:
                equipments_df['equipment_id'] = equipments_df.apply(lambda elem: generate_equimentid(16), axis=1)
            eqp_storage_if.insert_from_df('cras_db.equipments', equipments_df)

        # convert_error table
        cnverr_storage_if = DAOBaseClass(**ConfigDao.monitor_db())
        stored_cnverr_df = cnverr_storage_if.execute_by_spl(f"select * from cnvbase.convert_error")
        if len(stored_cnverr_df) != 0:
            stored_cnverr_df_list = stored_cnverr_df['equipment_id'].unique().tolist()
            equipments_id_list = equipments_df['equipment_id'].tolist()
            # update
            included_cnverr_df = equipments_df[equipments_df['equipment_id'].isin(stored_cnverr_df_list)]
            included_cnverr_df = included_cnverr_df.loc[:, ['equipment_name', 'equipment_id']]
            included_cnverr_df = included_cnverr_df.rename(columns={'equipment_name': 'equipment'})

            where_info = dict()
            for idx in range(len(included_cnverr_df)):
                equipments_id = included_cnverr_df['equipment_id'].values[idx]
                set_info = included_cnverr_df[included_cnverr_df['equipment_id'] == equipments_id].to_dict(orient='records')[0]
                del set_info['equipment_id']
                where_info['equipment_id'] = equipments_id
                cnverr_storage_if.update(table='cnvbase.convert_error', set=set_info, where=where_info)

            # delete
            not_included_stored_cnverr_df = stored_cnverr_df[~stored_cnverr_df['equipment_id'].isin(equipments_id_list)]
            for idx in range(len(not_included_stored_cnverr_df)):
                equipments_id = not_included_stored_cnverr_df['equipment_id'].values[idx]
                query = f"delete from cnvbase.convert_error where equipment_id='%s'" % equipments_id
                cnverr_storage_if.delete(query)

        serverDao = BaseServerDao(ConfigDao.monitor_db())
        equipments = serverDao.get_equipment_df()

        equipments['full_name'] = equipments['equipment_name']
        equipments['equipment_name'] = equipments['machinename']

        equip_list = equipments.to_dict(orient='records')
        response = make_response(jsonify(equip_list), 200)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        """
        [SAMPLE]
        [
        {'equipment_id': 'MPAUltmIKZEBXNcA', 'equipment_name': 'MPA_2', 'fab_name': 'Line1', 'full_name': 'CrasServerhan_Line1_MPA_2', 'inner_tool_id': '2', 'machinename': 'MPA_2', 'tool_id': 'MPA', 'tool_serial': 'serial', 'tooltype': 'tooltyp', 'user_name': 'CrasServerhan'}, 
        {'equipment_id': 'MPAaZIUidekNkJBg', 'equipment_name': 'MPA_222', 'fab_name': 'Line2', 'full_name': 'CrasServerhan_Line2_MPA_222', 'inner_tool_id': '222', 'machinename': 'MPA_222', 'tool_id': 'MPA', 'tool_serial': 'serial', 'tooltype': 'tooltyp', 'user_name': 'CrasServerhan'}, 
        {'equipment_id': 'MPAngygwGBdqgYgX', 'equipment_name': 'MPA_208', 'fab_name': 'Line1', 'full_name': 'CrasServerhan_Line1_MPA_208', 'inner_tool_id': '208', 'machinename': 'MPA_208', 'tool_id': 'MPA', 'tool_serial': 'qq', 'tooltype': 'tt', 'user_name': 'CrasServerhan'} 
        ]
        """
        return response
