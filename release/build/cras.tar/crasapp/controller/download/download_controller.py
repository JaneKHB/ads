import os

from flask import send_file
from flask_restx import Resource, Namespace

import service.step.step_service as do
import config.app_config as config
from controller.step_decorator import client_id, response_handler
from controller.step_exception import StepBadRequest

cras_download = Namespace('Download API(v1)', description='This controller serves Download API(V1) features.')


@cras_download.route('/<string:rid>/<string:filename>')
class StepOutputDownloadControl(Resource):

    @client_id
    @response_handler(False)
    def get(self, client, rid, filename):
        info = do.get_status_by_pid(client, rid)
        if info is not None:
            file_path = os.path.join(config.CLIENT_ROOT, client, info['step'], rid, filename)
            if not os.path.exists(file_path):
                raise StepBadRequest('cannot find the file %s' % filename)
        else:
            raise StepBadRequest('cannot find the rid[%s]  or client id[%s]' % (rid, client))

        return send_file(file_path, as_attachment=True)
