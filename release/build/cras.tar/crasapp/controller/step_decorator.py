from flask import request, make_response, jsonify

from controller.step_exception import StepBadRequest, StepNoDataResponse, StepServerError, StepNoClientId
from system_logger import SystemLogger

logger = SystemLogger('srv', 'ctrl')


def response_handler(json_response=True):
    def _parameter_wrapper(func):
        def _wrapper(*args, **kwargs):
            try:
                logger.info(f"{request.path} {'' if 'client' not in kwargs else kwargs['client']}")
                if json_response:
                    resp_data = func(*args, **kwargs)
                    resp = make_response(jsonify(resp_data), 200)
                    resp.headers['Content-Type'] = 'application/json; charset=utf-8'
                    return resp
                else:
                    return func(*args, **kwargs)
            except StepBadRequest as ex:
                error, status = str(ex), 400
            except StepNoClientId as ex:
                error, status = str(ex), 401
            except StepServerError as ex:
                error, status = str(ex), 500
            except StepNoDataResponse as ex:
                error, status = str(ex), 200
            except Exception as ex:
                error, status = str(ex), 501

            logger.error(f'{request.path} (err={error}, status={status})')

            if status != 200:
                resp = make_response(jsonify({'path': request.path, 'error': error}), status)
            else:
                resp = make_response(jsonify({'path': request.path, 'status': error}), status)
            resp.headers['Content-Type'] = 'application/json; charset=utf-8'
            return resp

        return _wrapper
    return _parameter_wrapper


def client_id(func):
    def _wrapper(*args, **kwargs):
        client = request.headers['client-id'] if 'client-id' in request.headers else None
        if client is None:
            resp = make_response(jsonify({'path': request.path, 'error': 'empty client-id'}), 401)
            resp.headers['Content-Type'] = 'application/json; charset=utf-8'
            return resp
        kwargs['client'] = client
        return func(*args, **kwargs)
    return _wrapper
