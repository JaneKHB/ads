import os
import json

from flask import request
from flask_restx import Resource, Namespace

import service.step.step_service as do
import config.app_config as config
from controller.step_decorator import client_id, response_handler
from controller.step_exception import StepBadRequest, StepServerError

cras_job = Namespace('Job API(v1)', description='This controller serves Job API(V1) features.')


@cras_job.route('', methods=['POST', 'GET'])
class StepJobRouter(Resource):

    @client_id
    @response_handler(True)
    def get(self, client):
        param = request.args.to_dict()
        info = list()
        for key in param.keys():
            if key == 'step':
                step = request.args[key]
                info = do.get_status_list_by_step(client, step)
        return {'list': info}

    @client_id
    @response_handler(True)
    def post(self, client):
        if request.content_type.startswith('application/json'):
            data = request.json
        elif request.content_type.startswith('multipart/form-data'):
            data = json.loads(request.form['data'])
            files = request.files.getlist('files')
            if files is not None:
                data['files'] = files
        else:
            raise StepBadRequest('invalid content-type[%s]' % request.content_type)

        pid = do.do_step_process(client, **data)
        return {'rid': pid}


@cras_job.route('/<string:rid>', methods=['GET', 'DELETE'])
class StepJobWithRequestIdRouter(Resource):

    @client_id
    @response_handler(True)
    def get(self, client, rid):
        info = do.get_status_by_pid(client, rid)
        if info['status'] == 'error':
            info['error'] = list()
            d_list = do.get_error_list_in_process(rid)
            for d in d_list:
                info['error'].append('%s: %s: %s' % (d['ts'].strftime('%Y-%m-%d %H:%M:%S'), d['module'], d['msg']))
        elif info['status'] == 'success':
            output_list = do.get_download_file_list(info)
            if len(output_list) > 0:
                info['download_url'] = create_download_path(request.path, rid, output_list)
            if info['step'] == 'rapidSearch':
                info['lists'] = read_file_list(info)

        return {**info}

    @client_id
    @response_handler(True)
    def delete(self, client):
        pass


def create_download_path(path, pid, output_list):
    path_list = path.split('/')
    try:
        i = path_list.index('v1')
        root_path = path_list[:i + 1]
        path_list = ['/'.join(root_path + ['download', pid, o]) for o in output_list]
        return path_list
    except (ValueError, IndexError):
        raise StepServerError('[create_download_path] error %s' % path)


def read_file_list(process: dict):
    path = os.path.join(config.CLIENT_ROOT, process['client'], process['step'], process['id'])
    file_name = os.path.join(path, 'file_list.json')
    with open(file_name, 'r', encoding='utf-8') as f:
        file_list = json.load(f)
    return file_list
