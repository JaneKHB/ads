import os
import json
from flask import request, send_file
from flask_restx import Resource, Namespace

import service.step.step_service as do
from controller.step_decorator import client_id, response_handler
from controller.step_exception import StepBadRequest


cras_client = Namespace('Client API(v1)', description='This controller serves Client API(V1) features.')


@cras_client.route('', methods=['POST', 'PATCH', 'DELETE'])
class ClientRouter(Resource):
    @client_id
    @response_handler(True)
    def post(self, client):
        if request.content_type.startswith('multipart/form-data'):
            data = json.loads(request.form['data'])
            if 'steps' not in data or data['steps'] is None or len(data['steps']) <= 0:
                raise StepBadRequest('cannot find [steps] key in json')
            files = request.files.getlist('files')
            if files is not None:
                data['files'] = files
            try:
                res_steps = do.create_client(client, **data)
                response = {'client-id': client, 'steps': res_steps}
            except Exception as ex:
                do.delete_client(client, False)
                raise ex
        else:
            raise StepBadRequest('invalid content-type[%s]' % request.content_type)
        return {**response}

    @client_id
    @response_handler(True)
    def patch(self, client):
        if request.content_type.startswith('multipart/form-data'):
            data = json.loads(request.form['data'])
            if 'steps' not in data or data['steps'] is None or len(data['steps']) <= 0:
                raise StepBadRequest('cannot find [steps] key in json')
            files = request.files.getlist('files')
            if files is not None:
                data['files'] = files
            try:
                res_steps = do.update_client(client, **data)
                response = {'client-id': client, 'steps': res_steps}
            except Exception as ex:
                do.delete_client(client, False)
                raise ex
        else:
            raise StepBadRequest('invalid content-type[%s]' % request.content_type)
        return {**response}

    @client_id
    @response_handler(False)
    def delete(self, client):
        do.delete_client(client, True)
        return {'client-id': client}


@cras_client.route('/download/<string:step>', methods=['GET'])
class ScriptDownloadRouter(Resource):

    @client_id
    @response_handler(False)
    def get(self, client, step):
        file_path = do.download_script(client, step)
        if file_path is None:
            raise StepBadRequest(f'Failed to compress the script file[{step}]')
        return send_file(file_path, as_attachment=True)

