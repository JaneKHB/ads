import copy
import json
import os
import zipfile

from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace, fields

import config.app_config as config
from dao import test_db_connection, get_db_config, test_db_connection
from dao.dao_config import ConfigDao

system_io = Namespace('SystemIO', description='You have to write descriptions down')

model_sys_common_json = system_io.model(name='systemio-common-json',
                                        model={'sample': fields.String(example="Edit this json.", required=True)})

model_sys_log_name = system_io.model(name='systemio-log-name',
                                     model={'log-name': fields.String(example="Edit this json.", required=True)})

model_sys_rapid_post = system_io.model(name='systemio-rapid-post',
                                       model={'host': fields.String(example="1.2.3.4", required=True),
                                              'port': fields.String(example="80", required=True),
                                              'user': fields.String(example="Administrator", required=True),
                                              'password': fields.String(example="xxx", required=True)})


class SystemController:
    config = ConfigDao()

    def change_config(self, name, param):
        if type(param) == dict:
            value = json.dumps(param)
        else:
            value = param
        self.config.set_config(name, value)
        return 200

    def get_config_from_db(self, name):
        try:
            conf = self.config.get_config(name)
            if 'password' in conf:
                conf.pop('password')
            response = make_response(jsonify({'config': conf}), 200 if conf is not None else 400)
        except Exception as msg:
            response = make_response(jsonify({'config': None, 'error': str(msg)}), 500)
        response.headers['Content-type'] = 'application/json; charset=utf-8'
        return response


@system_io.route('/config/convert-storage')
class SystemConvertStorageRouter(Resource, SystemController):
    @system_io.expect(model_sys_common_json)
    def post(self):
        return self.change_config(ConfigDao.CONVERT_STORAGE_DB, request.json)

    def get(self):
        return self.get_config_from_db(ConfigDao.CONVERT_STORAGE_DB)


@system_io.route('/config/monitor')
class SystemLogMonitorRouter(Resource, SystemController):
    @system_io.expect(model_sys_common_json)
    def post(self):
        param = request.json
        param['port'] = 5432 if param['host'] == 'Log-Monitor-Database' else 5442
        param['user'] = 'rssadmin'
        param['password'] = 'canon'
        param['dbname'] = 'logdb'
        return self.change_config(ConfigDao.LOG_MONITOR, param)

    def get(self):
        return self.get_config_from_db(ConfigDao.LOG_MONITOR)


@system_io.route('/config/setting-db')
class SystemSettingDatabaseRouter(Resource, SystemController):
    @system_io.expect(model_sys_common_json)
    def post(self):
        return self.change_config(ConfigDao.SETTING_DB, request.json)

    def get(self):
        return self.get_config_from_db(ConfigDao.SETTING_DB)


@system_io.route('/config/rapid')
class SystemRapidCollectorRouter(Resource, SystemController):
    @system_io.expect(model_sys_rapid_post)
    def post(self):
        param = request.json
        # param['password'] = hashlib.md5(param['password'].encode()).hexdigest()
        return self.change_config(ConfigDao.RAPID_COLLECTOR, request.json)

    def get(self):
        return self.get_config_from_db(ConfigDao.RAPID_COLLECTOR)


@system_io.route('/config/log-name/recipe')
@system_io.route('/config/log-name/machine-data')
@system_io.route('/config/log-name/version')
class SystemErrorDownloadLogNameRouter(Resource, SystemController):
    kv_dict = {
        'recipe': ConfigDao.LOG_NAME_RECIPE,
        'machine-data': ConfigDao.LOG_NAME_MACHINE_DATA,
        'version': ConfigDao.LOG_NAME_VERSION
    }

    @system_io.expect(model_sys_log_name)
    def post(self):
        target = request.path.split('/')[-1]
        try:
            key = self.kv_dict[target]
        except KeyError:
            return 400
        return self.change_config(key, request.json['log-name'])

    def get(self):
        target = request.path.split('/')[-1]
        try:
            key = self.kv_dict[target]
        except KeyError:
            return 400
        return self.get_config_from_db(key)


@system_io.route('/config/username')
class SystemUserNameRouter(Resource, SystemController):
    @system_io.expect(model_sys_common_json)
    def post(self):
        return self.change_config(ConfigDao.USER_NAME, request.json['user'])

    def get(self):
        return self.get_config_from_db(ConfigDao.USER_NAME)


@system_io.route('/config/conn_state/<string:db_name>')
@system_io.param('db_name', 'database param')
class SystemGetConnectionState(Resource, SystemController):

    @system_io.doc(responses={
        200: 'Success',
        400: 'Parameter error'
    })
    def get(self, db_name):
        print(db_name)
        config_io = ConfigDao()
        con_db = ''
        if db_name == 'cras_db':
            con_db = get_db_config()
        elif db_name == 'convert_db':
            con_db = copy.deepcopy(config_io.get_config(ConfigDao.CONVERT_STORAGE_DB))
        elif db_name == 'set_db':
            con_db = copy.deepcopy(config_io.get_config(ConfigDao.SETTING_DB))
        if 'schema' in con_db:
            del con_db['schema']

        if test_db_connection(con_db):
            return Response(status=200)
        else:
            return Response(status=400)


@system_io.route('/dbg/download', methods=['GET'])
class SystemDbgFileDownloadController(Resource):

    def get(self):
        file_path = os.path.join(config.FS_ROOT, f'debug.zip')
        file_path = os.path.abspath(file_path)
        if os.path.exists(file_path):
            os.remove(file_path)
        self.make_debug_zip_file(config.CLIENT_ROOT, file_path)
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=True)
        return Response(status=500)

    def make_debug_zip_file(self, source_dir, output_filename):
        relroot = os.path.abspath(os.path.join(source_dir, os.pardir))
        with zipfile.ZipFile(output_filename, "w", zipfile.ZIP_DEFLATED) as zip:
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    filename = os.path.join(root, file)
                    if os.path.isfile(filename):
                        arcname = os.path.join(os.path.relpath(root, relroot), file)
                        zip.write(filename, arcname)


@system_io.route('/app')
class SystemApplicationDownloader(Resource):

    def get(self):
        release_file = os.path.join(config.FS_ROOT, 'cras.tar')
        if os.path.exists(release_file):
            return send_file(release_file, as_attachment=True)
        print('no file to deploy')
        return Response(status=400)
