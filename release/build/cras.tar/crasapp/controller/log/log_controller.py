from flask import request
from flask_restx import Resource, Namespace

import service.step.step_service as do
from controller.step_decorator import client_id, response_handler
from dao.dao_system_logger import SystemLoggerDao
from system_logger import SystemLogger

logger = SystemLogger('srv', 'ctrl')

cras_log = Namespace('Log API(v1)', description='This controller serves Log API(V1) features.')


@cras_log.route('/<string:rid>', methods=['GET', 'DELETE'])
class SystemLogControl(Resource):

    @client_id
    @response_handler(True)
    def get(self, client, rid):
        info = do.get_status_by_pid(client, rid)
        if info is not None:
            after = int(request.args["after"]) if "after" in request.args else 0
            limit = int(request.args["limit"]) if "limit" in request.args else 0

            o = SystemLoggerDao()
            logs = o.get_log_by_id(rid, after=after, limit=limit)
            if len(logs) == 0:
                return {
                    "content": [],
                    "last": after,
                    "length": 0,
                    "status": info["status"]
                }

            log_str, last = logger.to_str_list(logs)
            return {
                "content": log_str,
                "last": last,
                "length": len(log_str),
                "status": info["status"]
            }
