import logging
import os

from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace

from controller.step_decorator import response_handler, client_id
from controller.step_exception import StepBadRequest
from dao import ConfigDao
from dao.dao_cras_storage import CrasStorageDao
from dao.dao_system_logger import SystemLoggerDao
from dao.dao_base_server import BaseServerDao
from service.rapid.rapidconnector import RapidConnector
import config.app_config as config
import service.step.step_service as do
from system_logger import SystemLogger

error_log = Namespace('Error Log API(v1)', description='This controller serves error log features.')
logger = SystemLogger('srv', 'ctrl')


@error_log.route('/list', methods=['GET'])
class ErrorLogListController(Resource):

    @response_handler(True)
    def get(self):
        page = request.args.get('page', default=0, type=int)
        size = request.args.get('size', default=10, type=int)
        sort, order = request.args.get('sort', default='occurred_date,desc', type=str).split(',')
        search = request.args.getlist('search')
        filter = request.args.getlist('filter')

        # Get fab list from rapid-collector
        io = BaseServerDao({**config.CRAS_CONVERT_DB})
        equipments = io.get_equipment_df()
        if equipments is None:
            logger.warn('cannot retrieve equipments from rapid-collector')
            return Response(status=400)

        equipment_name_list = equipments['equipment_id'].drop_duplicates().tolist()
        if len(equipment_name_list) == 0:
            raise RuntimeWarning('no equipment in rapid-collector')

        error_list, total = CrasStorageDao({**config.CRAS_CONVERT_DB}).get_error_log(page, size, sort, order, search, filter)

        if error_list is None:
            raise RuntimeError('error_list return none')

        total_pages = int((total+size-1)/size)
        return {
            'totalElements': total,
            'pageable': {
                'pageNumber': page,
                'pageSize': size
            },
            'totalPage': total_pages,
            'first': True if page == 0 else False,
            'last': True if total_pages == page+1 else False,
            'content': error_list.to_dict('records'),
        }


@error_log.route('/log/<string:rid>', methods=['GET'])
class ErrorLogLoggingController(Resource):

    @client_id
    @response_handler(True)
    def get(self, client, rid):
        info = do.get_status_by_pid(client, rid)
        if info is not None:
            o = SystemLoggerDao()
            logs = o.get_log_by_id(rid)
            return logger.to_str_list(logs)


@error_log.route('/download', methods=['POST'])
class ErrorLogDownloadController(Resource):

    @client_id
    @response_handler(True)
    def post(self, client):
        data = request.json
        if 'start_date' not in data or 'end_date' not in data:
            raise StepBadRequest('no period parameter(start_date or end_date)')
        if 'machine' not in data:
            raise StepBadRequest('no target parameter(fab)')
        if 'ftp_type' not in data:
            raise StepBadRequest('no connect type parameter(ftp_type)')
        if 'command' not in data:
            raise StepBadRequest('no command type parameter')

        pid = do.do_download_process(client, **data)
        return {'rid': pid}


@error_log.route('/download/<string:rid>', methods=['GET'])
class ErrorLogDownloadWithParamController(Resource):

    @client_id
    @response_handler(True)
    def get(self, client, rid):
        info = do.get_status_by_pid(client, rid)
        if info is not None:
            if info['status'] == 'success':
                file_list = do.get_download_file_list(info)
                download_url = [request.path+'/'+f for f in file_list]
                info['download_url'] = download_url
            elif info['status'] == 'error':
                info['error'] = list()
                d_list = do.get_error_list_in_process(rid)
                for d in d_list:
                    info['error'].append('%s: %s: %s' % (d['ts'].strftime('%Y-%m-%d %H:%M:%S'), d['module'], d['msg']))
        return {**info}


@error_log.route('/download/<string:rid>/<string:filename>', methods=['GET'])
class ErrorLogDownloadFileDownloadController(Resource):

    @client_id
    @response_handler(False)
    def get(self, client, rid, filename):
        file_path = os.path.join(config.CLIENT_ROOT, client, 'download', rid, filename)
        if not os.path.exists(file_path):
            raise StepBadRequest('cannot find the file %s' % filename)

        return send_file(file_path, as_attachment=True)
