class StepBadRequest(Exception):
    pass


class StepServerError(Exception):
    pass


class StepNoDataResponse(Exception):
    pass


class StepNoClientId(Exception):
    pass


class StepBusyStatus(Exception):
    pass
