import os

from flask import Response, request, make_response, jsonify, send_file
from flask_restx import Resource, Namespace

from config.app_config import CRAS_ROOT, LEGACY_ROOT, JOB_ROOT, FS_ROOT
from system_logger import SystemLogger


logger = SystemLogger('srv', 'ctrl')
cras_data = Namespace('CRAS Data', description='APIs that get information of CRAS configuration.')


@cras_data.route('/legacy/download')
class CrasLegacyDownload(Resource):
    def get(self):
        """
        Download an legacy cras data.
        """
        logger.info(f'{request.method} {request.path}')

        file_path = os.path.join(LEGACY_ROOT, f'cras_data.xlsx')
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=True)
        else:
            response = make_response(jsonify({'msg': 'no cras data file'}), 204)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response
