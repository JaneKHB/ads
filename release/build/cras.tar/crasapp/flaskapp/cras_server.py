import os
import shutil

from flask import Flask, make_response, send_from_directory
from flask_restx import Api
from flask_cors import CORS

from controller.converter.convert_control import convert_data
from controller.converter.v1.convertio import convert_io
from controller.cras.crasdata_control import cras_data
from controller.errorlog.errorlog_controller import error_log
from controller.executor.exec_controller import execute_io
from controller.rapid.rapid_controller import Rapid
from controller.client.client_controller import cras_client
from controller.job.job_controller import cras_job
from controller.log.log_controller import cras_log
from controller.download.download_controller import cras_download
from controller.system.system_controller import system_io
from dao import init_db
import config.app_config as config
import service.step.step_service as serv

import logging
import logging.handlers
import multiprocessing
from service.logger.service_logger import ServiceLogger


def create_app():
    initialize_log()
    copy_step_script()

    # Instantiate flask.
    app = Flask(__name__, static_folder='../resource/static/', static_url_path='/main')

    # App configuration
    app.config['DEBUG'] = False
    app.config.SWAGGER_UI_DOC_EXPANSION = 'none'  # none, list, full

    api = Api(app,
              doc='/doc/',
              version='2022.3',
              title='CRAS Server',
              description='Application server supporting remote service',
              license='Copyright (c) 2022 CANON Inc. All rights reserved.')

    CORS(app)

    api.add_namespace(Rapid, '/api/rapid')
    api.add_namespace(convert_data, '/api/convert')
    api.add_namespace(cras_data, '/api/cras')

    # Add step namespaces
    api.add_namespace(cras_client, '/api/v1/client')
    api.add_namespace(cras_job, '/api/v1/job')
    api.add_namespace(cras_log, '/api/v1/log')
    api.add_namespace(cras_download, '/api/v1/download')
    api.add_namespace(convert_io, '/api/v1/convert')
    api.add_namespace(system_io, '/api/v1/sys')
    api.add_namespace(execute_io, '/api/v1/exec')
    api.add_namespace(error_log, '/api/v1/errorlog')

    # init db
    init_db()
    serv.init_step_process()

    @app.route('/main', methods=['GET'])
    @app.route('/main/config', methods=['GET'])
    @app.route('/main/brief', methods=['GET'])
    @app.route('/main/notfound', methods=['GET'])
    def new_config_page():
        return send_from_directory(app.static_folder, 'index.html')

    @app.route('/api', methods=['GET'])
    def hello():
        return make_response('2.5.3', 200)

    print_url(app)
    return app


def print_url(app):
    for r in app.url_map.iter_rules():
        print("%-40s %s" % (r.methods, r.rule))


def copy_step_script():
    print('copy mount base scripts')
    if os.path.exists(config.STEP_PROCESS_SCRIPT):
        shutil.rmtree(config.STEP_PROCESS_SCRIPT)
    shutil.copytree('dockerlib', config.STEP_PROCESS_SCRIPT)

    if os.path.exists(config.STEP_COMMON_SCRIPT):
        shutil.rmtree(config.STEP_COMMON_SCRIPT)
    shutil.copytree('common', config.STEP_COMMON_SCRIPT)

    # 【Docker削除によるProcess実行】
    if not config.DOCKER_RUNNER:
        steprunnerhost = config.FS_ROOT+os.sep+config.STEP_RUNNER_SCRIPT_HOST
        if os.path.exists(steprunnerhost):
            os.remove(steprunnerhost)
        shutil.copy('pyrunner'+os.sep+'src'+os.sep+config.STEP_RUNNER_SCRIPT_HOST, steprunnerhost)


def initialize_log():
    """
    LOGをファイル形式に保存する。
    """
    logging_queue = ServiceLogger.instance().queue
    listener = multiprocessing.Process(target=ServiceLogger.instance().logging_process,
                                       args=(logging_queue, False, os.getpid()))
    listener.daemon = True
    listener.start()

    handler = logging.handlers.QueueHandler(logging_queue)  # Just the one handler needed
    logger = logging.getLogger(config.LOG)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    logger_werkzeug = logging.getLogger('werkzeug')
    logger_werkzeug.addHandler(handler)
