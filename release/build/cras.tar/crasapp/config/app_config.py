from sys import platform

_prod = False if platform == 'win32' else True

# Runner in docker
DOCKER_RUNNER = False

# Database config for CRAS server
CRAS_DB = {
    'dbname': "rssdb",
    'user': "rssadmin",
    'host': "Cras-Database" if _prod else 'localhost',
    'password': "canon",
    'port': 5432 if _prod else 5443
}

CRAS_CONVERT_DB = {
    **CRAS_DB,
    'schema': 'cras_db'
}

# Set Zip command.
ZIP_EXEC = '/usr/local/7zz' if _prod else 'C:\\"Program Files"\\7-Zip\\7z.exe'
ZIP_OPTIONS = 'a -p%s' if _prod else 'a -p%s'

# Filesystem Root
FS_ROOT = '/CANON/CRAS'

# Converter settings
CONVERTING_PROCESSES = 4
CONVERTER_ROOT = '/CANON/CRAS/job/convert'

# Set CRAS file path
CRAS_ROOT = '/CANON/CRAS/job/cras'

# Error summary config
SUMMARY_ROOT = '/CANON/CRAS/job/summary'

# Version check config
VERSION_ROOT = '/CANON/CRAS/job/version'

# Legacy data
LEGACY_ROOT = '/CANON/CRAS/job/legacy'

JOB_ROOT = '/CANON/CRAS/job'

CLIENT_ROOT = '/CANON/CRAS/client'

STEP_PROCESS_SCRIPT = '/CANON/CRAS/process'
STEP_COMMON_SCRIPT = '/CANON/CRAS/common'

STEP_RUNNER_SCRIPT_DOCKER = 'steprunner.py'
STEP_RUNNER_SCRIPT_HOST = 'steprunnerhost.py'       # 【Docker削除によるProcess実行】

# History
HISTORY_LIMIT = 1000

# # Log (Analysis Tool)
# LOG = 'unused'

##########################################################################
# Log System Settings
##########################################################################
LOG = 'APP_LOG'
LOG_FILENAME = 'cras_dev.log'
LOG_FILEPATH = '/CANON/CRAS/DEVLOG'
LOG_ERRNAME = 'cras_error.log'
LOG_MAXBYTE = 10 * 1024 * 1024
LOG_BACKUPCOUNT = 100
LOG_FORMAT = '%(asctime)s: %(levelname)s: %(module)s: %(message)s'
LOG_DATEFMT = '%Y-%m-%d %H:%M:%S'