class RapidConnectionError(Exception):
    pass
