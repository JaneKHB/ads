import subprocess
import os
from threading import Thread


class DockerPyExecutor:

    PYTHON_IMAGE = 'pyrun:latest'
    PYTHON_RUNNER_MAIN_PY = 'pyrunner.py'
    CONTAINER_SCRIPT_MOUNT_PATH = '/usr/local/src/proc'

    # Path where python files are.
    script_path = ''

    # File output of executing logs
    output = None

    # Container name
    container_name = ''

    script_args = ''

    thread = True

    def __init__(self, script_path, script_args, output=None, thread=True):
        self.script_path = script_path
        self.script_args = script_args
        self.output = output
        self.container_name = os.path.basename(script_path)
        self.thread = thread

        if not os.path.exists(self.script_path):
            raise RuntimeError('script_path(%s) does not exist' % self.script_path)

    def run(self):
        if self.thread:
            Thread(target=self.__run).start()
        else:
            self.__run()

    def __run(self):
        command = self.__build_command()

        print('command=', command)
        if self.output is None:
            subprocess.call(command, shell=True)

    @staticmethod
    def is_finish(container_name):
        ret = subprocess.check_output(f'docker ps -q --filter="name={container_name}"', shell=True)
        if ret.decode() == '':
            return True
        return False

    def __build_command(self):
        command = f'docker run --rm %s {self.PYTHON_IMAGE} python {self.PYTHON_RUNNER_MAIN_PY} %s'
        options = list()
        options.append(f'--name {self.container_name}')
        # set timezone
        options.append("-e TZ=`echo $TZ`")
        # set option
        options.append(f'-v {os.path.abspath(self.script_path)}:{self.CONTAINER_SCRIPT_MOUNT_PATH}')
        return command % (' '.join(options), self.script_args)
