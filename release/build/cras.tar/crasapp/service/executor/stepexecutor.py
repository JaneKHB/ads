import os
import signal
from sys import platform
import subprocess
from threading import Thread, Event

import psutil

import config.app_config as config
from system_logger import SystemLogger

logger = SystemLogger('srv', 'dockexe')

process_step_pid = dict()


class ProcessStepExecutor:
    TICKET_PATH = None
    output = None
    PYTHON_RUNNER_MAIN_PY = config.STEP_RUNNER_SCRIPT_HOST

    def __init__(self, pid, step, priv, output=None, thread=True):
        self.pid = pid          # self.pid convert-wt7k1x
        self.step = step        # self.step convert_000021
        self.priv = priv        # [SAMPLE] priv = '/CANON/CRAS/client\\remote_000004'
        self.priv_path = f'{config.CLIENT_ROOT}/{priv.split(os.sep)[-1]}'
        # [SAMPLE] self.priv_path = '/CANON/CRAS/client/remote_000004'

        self.output = output    # self.output None
        self.thread = thread    # self.thread True

    def run(self):
        if self.thread:
            started_evt = Event()
            Thread(target=self.__run, args=(started_evt,)).start()
            started_evt.wait()
        else:
            self.__run()

    def __run(self, started_evt=None):
        print('#           ProcessStepExecutor running')

        if started_evt is not None:
            started_evt.set()

        if self.TICKET_PATH is None:
            ticket_file = os.path.join(self.priv, self.step, 'order.json')
        else:
            ticket_file = os.path.join(self.priv, self.step, self.TICKET_PATH, 'order.json')

        if not os.path.exists(ticket_file):
            print('invalid ticket file for pid ', self.pid)
        else:
            # add to PYTHONPATH
            # /CANON/CRAS/process:/CANON/CRAS/common:/CANON/CRAS/client/remote_000004
            my_env = {**os.environ,
                      'PYTHONPATH': f"{self.priv_path}{os.pathsep}{config.STEP_PROCESS_SCRIPT}{os.pathsep}{config.STEP_COMMON_SCRIPT}{os.pathsep}" + os.environ['PYTHONPATH']
                      }
            # print("self.TICKET_PATH", self.TICKET_PATH)
            # print("my_env", my_env)

            if self.output is None:
                if self.TICKET_PATH is not None:
                    process = subprocess.Popen(["python", f'{config.FS_ROOT}/{self.PYTHON_RUNNER_MAIN_PY}', "-s", self.step, "-t", self.TICKET_PATH, "-p", self.priv_path],
                                               env=my_env)
                else:
                    process = subprocess.Popen(["python", f'{config.FS_ROOT}/{self.PYTHON_RUNNER_MAIN_PY}', "-s", self.step, "-p", self.priv_path],
                                               env=my_env)

                # add pid register
                process_step_pid[self.pid] = process.pid
            else:
                if self.TICKET_PATH is not None:
                    process = subprocess.Popen(["python", f'{config.FS_ROOT}/{self.PYTHON_RUNNER_MAIN_PY}', "-s", self.step, "-t", self.TICKET_PATH, "-p", self.priv_path],
                                               env=my_env, stdout=subprocess.PIPE)
                else:
                    process = subprocess.Popen(["python", f'{config.FS_ROOT}/{self.PYTHON_RUNNER_MAIN_PY}', "-s", self.step, "-p", self.priv_path],
                                               env=my_env, stdout=subprocess.PIPE)

                # add pid register
                process_step_pid[self.pid] = process.pid
                f = None
                try:
                    # waiting process to end
                    ret = process.communicate()[0]
                    log = ret.decode()
                    logger.info(log)
                    f = open(os.path.join(self.priv_path, self.step, "console.log"), 'w')
                    f.write(log)
                except:
                    logger.warn('already delete folder by user')
                finally:
                    if f is not None:
                        f.close()

                if self.pid in process_step_pid.keys():
                    del process_step_pid[self.pid]

            print('#           ProcessStepExecutor done')

    def set_ticket_path(self, path):
        self.TICKET_PATH = path

    @staticmethod
    def kill_container(pid):
        """
        元々running statusだけ削除しますので、重複されていても特に問題はなさそう。
        """
        # pid convert-wt7k1x
        if pid in process_step_pid.keys():
            real_process_id = process_step_pid[pid]
            del process_step_pid[pid]
            if psutil.pid_exists(real_process_id):
                os.kill(real_process_id, signal.SIGKILL)
        else:
            return


# class ThreadStepExecutor:
#     ticket_path = None
#     output = None
#
#     def __init__(self, pid, step, priv, output=None, thread=True):
#         self.pid = pid
#         self.step = step
#         self.priv = priv
#
#     def run(self):
#         Thread(target=self.__run).start()
#
#     def __run(self):
#         print('#           ThreadStepExecutor running')
#         if self.ticket_path is None:
#             ticket_file = os.path.join(self.priv, self.step, 'order.json')
#         else:
#             ticket_file = os.path.join(self.priv, self.step, self.ticket_path, 'order.json')
#         if not os.path.exists(ticket_file):
#             print('invalid ticket file for pid ', self.pid)
#         else:
#             import pyrunner.src.steprunner as steprunner
#             # [SAMPLE] 'version_000008' '/CANON/CRAS/client\\remote_000004\\version_000008\\order.json'
#             steprunner.run(self.step, ticket_file)
#             print('#            done')
#
#     def set_ticket_path(self, path):
#         self.ticket_path = path


class DockerStepExecutor:
    PYTHON_IMAGE = 'pyrun:latest'
    PYTHON_RUNNER_MAIN_PY = config.STEP_RUNNER_SCRIPT_DOCKER
    CONTAINER_SCRIPT_MOUNT_PATH = '/usr/local/src/process'
    CONTAINER_SCRIPT_MOUNT_PATH2 = '/usr/local/src/common'
    CONTAINER_PRIVATE_PATH = '/usr/local/src/priv'
    TICKET_PATH = None

    def __init__(self, pid, step, priv, output=None, thread=True):
        self.container_name = pid
        # [SAMPLE] priv = '/CANON/CRAS/client\\remote_000004'
        self.priv = f'{config.CLIENT_ROOT}/{priv.split(os.sep)[-1]}'
        # [SAMPLE] self.priv = '/CANON/CRAS/client/remote_000004'
        self.output = output
        self.thread = thread
        self.step = step

    def set_ticket_path(self, path):
        self.TICKET_PATH = path

    def run(self):
        if self.thread:
            Thread(target=self.__run).start()
        else:
            self.__run()

    def __run(self):
        command = self.__build_command()

        logger.info('command=%s' % command)
        # [SAMPLE] wsl docker run --rm --network rss --name version-nasnv8 -e TZ=`echo $TZ`
        # -v /CANON/CRAS/process:/usr/local/src/process
        # -v /CANON/CRAS/common:/usr/local/src/common
        # -v /CANON/CRAS/client/remote_000004:/usr/local/src/priv
        # pyrun:latest python3 steprunner.py version_000008
        print(command)
        if self.output is None:
            subprocess.call(command, shell=True)
        else:
            ret = subprocess.check_output(command, shell=True)
            log = ret.decode()
            logger.info(log)
            f = open(os.path.join(self.priv, self.step, self.container_name, "console.log"), 'w')
            f.write(log)
            f.close()

    @staticmethod
    def is_finish(container_name):
        base = 'wsl' if platform == 'win32' else ''
        ret = subprocess.check_output(f'{base} docker ps -q --filter="name={container_name}"', shell=True)
        if ret.decode() == '':
            return True
        return False

    @staticmethod
    def kill_container(container_name):
        is_running = not DockerStepExecutor.is_finish(container_name)
        if is_running:
            base = 'wsl' if platform == 'win32' else ''
            subprocess.check_output(f'{base} docker kill {container_name}', shell=True)

    def __build_command(self):
        base = 'wsl' if platform == 'win32' else ''
        command = f'{base} docker run --rm --network rss %s {self.PYTHON_IMAGE} python3 {self.PYTHON_RUNNER_MAIN_PY} %s'
        options = list()
        options.append(f'--name {self.container_name}')

        # set timezone
        options.append("-e TZ=`echo $TZ`")

        if False:
            options.append(f'-v {os.path.abspath(config.STEP_PROCESS_SCRIPT)}:{self.CONTAINER_SCRIPT_MOUNT_PATH}')
            options.append(f'-v {os.path.abspath(config.STEP_COMMON_SCRIPT)}:{self.CONTAINER_SCRIPT_MOUNT_PATH2}')
            options.append(f'-v {os.path.abspath(self.priv)}:{self.CONTAINER_PRIVATE_PATH}')
        else:
            options.append(f'-v {config.STEP_PROCESS_SCRIPT}:{self.CONTAINER_SCRIPT_MOUNT_PATH}')
            options.append(f'-v {config.STEP_COMMON_SCRIPT}:{self.CONTAINER_SCRIPT_MOUNT_PATH2}')
            options.append(f'-v {self.priv}:{self.CONTAINER_PRIVATE_PATH}')

        arg_list = [self.step]
        if self.TICKET_PATH is not None:
            arg_list.append(self.TICKET_PATH)
        return command % (' '.join(options), ' '.join(arg_list))
