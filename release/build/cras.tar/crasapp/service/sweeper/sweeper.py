import datetime
import os
import shutil

import psycopg2 as pg2
import psycopg2.extras

from config.app_config import CONVERTER_ROOT, CRAS_ROOT, SUMMARY_ROOT, VERSION_ROOT
from dao.utils import exist_table, get_db_config


def do_sweep():
    _str = ''
    # Sweep converting jobs
    _removes = sweep_some('job', 'cnvset', 'start', CONVERTER_ROOT, persistence=10000)
    if _removes > 0:
        _str += f' convert-job={_removes}'

    # Sweep cras jobs
    _removes = sweep_some('cras_job', 'cnvset', 'created', CRAS_ROOT)
    if _removes > 0:
        _str += f' cras-job={_removes}'

    # Sweep summary jobs
    _removes = sweep_some('summary_job', 'cnvset', 'created', SUMMARY_ROOT)
    if _removes > 0:
        _str += f' summary-job={_removes}'

    # Sweep version jobs
    _removes = sweep_some('version_job', 'cnvset', 'created', VERSION_ROOT)
    if _removes > 0:
        _str += f' version-job={_removes}'

    # Sweep files
    with pg2.connect(**get_db_config()) as connect:
        with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            if exist_table('file', schema_name='cnvset'):
                _date = datetime.datetime.today() - datetime.timedelta(7)
                _date = _date.strftime('%Y-%m-%d')
                cursor.execute(f"select * from cnvset.file where created < '{_date}'")
                _ret = cursor.fetchall()
                target = [str(_['id']) for _ in _ret]

                if len(_ret) > 0:
                    for f in _ret:
                        file = os.path.join(f['path'])
                        if os.path.exists(file):
                            os.remove(file)
                    cursor.execute(f"delete from cnvset.file where id in ({','.join(target)})")
                    _str += f' file={len(_ret)}'

    if _str != '':
        print(f'sweeper: {_str}')


def sweep_some(table, schema, order_column, root_dir, persistence=100):
    with pg2.connect(**get_db_config()) as connect:
        with connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            if exist_table(table, schema_name=schema):
                _table = f'{schema}.{table}'
                cursor.execute(f"select id from {_table} order by {order_column} desc offset {persistence}")
                _ret = cursor.fetchall()
                target = [_['id'] for _ in _ret]
                target_str = [f"'{_['id']}'" for _ in _ret]

                print(f"sweep {table} : {target_str}")
                if len(_ret) > 0:
                    for _id in target:
                        _dir = os.path.join(root_dir, _id)
                        if os.path.exists(_dir):
                            shutil.rmtree(_dir)

                    _in = ','.join(target_str)
                    cursor.execute(f"delete from {_table} where id in ({_in})")
                    return len(_ret)
    return 0
