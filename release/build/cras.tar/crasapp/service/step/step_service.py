import os
import json
import random
import shutil
import string

import config.app_config as config
from controller.step_exception import StepBadRequest, StepServerError, StepBusyStatus
from dao.dao_step_process import StepProcessDao
from dao.dao_system_logger import SystemLoggerDao
from dao.dao_cras_storage import CrasStorageDao
from service.executor.stepexecutor import DockerStepExecutor, ProcessStepExecutor
from system_logger import SystemLogger

logger = SystemLogger('srv', 'service')

process_dao = StepProcessDao()
logger_dao = SystemLoggerDao()

process_context = {
    'id': None,
    'client': None,
    'path': None,
    'step': None
}

step_list = ['collect', 'convert', 'summary', 'cras', 'version', 'purge', 'custom', 'script']


def create_dir(path: str) -> None:
    cur = '/'
    for p in path.split(os.sep):
        cur = os.path.join(cur, p)
        if not os.path.exists(cur):
            os.mkdir(cur)


def create_client(client, **kwargs):
    client_path = os.path.join(config.CLIENT_ROOT, client)
    logger.info('create job | client=%s, path=%s' % (client, client_path))
    ret = []
    # create job directory structure
    for step_info in kwargs['steps']:
        step = step_info['step']
        step_path = os.path.join(client_path, step)
        # create directory
        create_dir(step_path)
        ret.append({"step": step})

        # create script file in custom step
        step_type = get_step_type(step)
        if step_type == 'custom':
            if 'script_filename' not in step_info or step_info['script_filename'] is None:
                raise StepBadRequest('missing parameters [script_filename] in %s' % step)
            if kwargs['files'] is None:
                raise StepBadRequest('missing parameters [files] in %s' % step)
            upload_step_script(client, step, step_info['script_filename'], kwargs['files'])
    return ret


def delete_client(client, is_del_db=False):
    """
    実行しているpyrun Clientを
    1．process(docker)削除
    2．clientフォルダなかのファイル削除
    3．dbからLOGも削除
    """
    client_path = os.path.join(config.CLIENT_ROOT, client)
    logger.info('delete job | client=%s, path=%s' % (client, client_path))

    # kill pyrun container
    job_info_list = get_rid_list_by_client(client)
    kill_pyrun_container(job_info_list)

    # delete client folder
    if os.path.exists(client_path):
        shutil.rmtree(client_path)

    # delete record
    if is_del_db:
        delete_record_in_db(client, job_info_list)


def update_client(client, **kwargs):
    delete_client(client, False)
    ret = create_client(client, **kwargs)
    return ret


def download_script(client, step):
    zip_file_path = None
    script_path = os.path.join(config.CLIENT_ROOT, client, step, '_script')
    if os.path.exists(script_path):
        dst_path = os.path.join(config.CLIENT_ROOT, client, step, f'{step}_script.zip')
        zip_file_path = shutil.make_archive(dst_path.replace('.zip', ''), 'zip', script_path)
    return zip_file_path


def kill_pyrun_container(job_info_list):
    """
    実行中のpyrun process(docker)をKillする。
    """
    for info in job_info_list:
        if 'status' in info and info['status'] == 'running':
            try:
                # 【Docker削除によるProcess実行】
                if not config.DOCKER_RUNNER:
                    ProcessStepExecutor.kill_container(info['id'])
                else:
                    DockerStepExecutor.kill_container(info['id'])
            except Exception as ex:
                logger.warn(str(ex))


def delete_record_in_db(client, job_info_list):
    try:
        # delete log in system_log table
        for info in job_info_list:
            delete_log_by_rid(info['id'])

        # delete client in step_process table
        delete_client_in_process(client)
    except Exception as ex:
        logger.warn(str(ex))


def get_step_type(step: str):
    step_id_sep = '_'
    return step.split(step_id_sep)[0]


def do_step_process(client: str, **kwargs) -> str:
    def _check(key):
        return key not in kwargs or kwargs[key] is None

    # Check step key
    if _check('step'):
        raise StepBusyStatus('missing parameters [step]')
    step = kwargs['step']
    step_type = get_step_type(step)

    client_path = os.path.join(config.CLIENT_ROOT, client)

    # Check if client path(client api) in step job.
    if step_type in step_list:
        if not os.path.exists(client_path):
            raise StepBadRequest('[%s] does not exist.' % client_path)

    try:
        logger.info('do_step_process| client=%s, step=%s' % (client, step))
        if is_step_running(client, step):
            raise StepBusyStatus('%s:%s busy' % (client, step))

        pid = create_pid(client, step_type)

        try:
            if step_type == 'collect':
                service_info = dict()
                for must in ['plan_id']:
                    if must not in kwargs:
                        raise RuntimeError('%s must have %s param' % (step, must))
                    service_info[must] = kwargs[must]

                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'plan_id': service_info['plan_id'],
                           'retention_period': 7 if _check('retention_period') else kwargs['retention_period']}

            elif step_type == 'convert':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step}
            elif step_type == 'summary':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'password': 'password' if _check('password') else kwargs['password'],
                           'period': 7 if _check('period') else int(kwargs['period'])}
            elif step_type == 'cras':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'password': 'password' if _check('password') else kwargs['password'],
                           'period': 7 if _check('period') else int(kwargs['period']),
                           'rule': kwargs['rule']}
            elif step_type == 'version':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'period': 7 if _check('period') else int(kwargs['period'])}
            elif step_type == 'purge':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step}
            elif step_type == 'custom':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step
                           }
            elif step_type == 'rapidSearch':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'start_date': kwargs['start_date'],
                           'end_date': kwargs['end_date'],
                           'machine': kwargs['machine'],
                           'ftp_type': kwargs['ftp_type'],
                           'command': kwargs['command']
                           }
            elif step_type == 'rapidDownload':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'ftp_type': kwargs['ftp_type'],
                           'lists': kwargs['lists'],
                           'command': kwargs['command'],
                           'machine': kwargs['machine']
                           }
            elif step_type == 'script':
                context = {**process_context,
                           'id': pid,
                           'client': client,
                           'path': client_path,
                           'step': step,
                           'script_type': 'unknown' if _check('script_type') else kwargs['script_type'],
                           'args': '' if _check('args') else kwargs['args']
                           }
            else:
                raise RuntimeError('cannot find step service %s' % step)
        except KeyError as ex:
            raise StepBadRequest('missing parameters %s' + str(ex))

        path = os.path.join(config.CLIENT_ROOT, client, step)

        # If there are input files in parameter, store them into the path
        if 'files' in kwargs:
            process_path = os.path.join(path, pid)
            if not os.path.exists(process_path):
                create_dir(process_path)
            context['file'] = list()
            for f in kwargs['files']:
                f.save(os.path.join(process_path, f.filename))
                context['file'].append(f.filename)
                logger.info('save file %s' % f.filename)

        # Create json file to pass in docker
        if context['step'] in ['rapidSearch', 'rapidDownload']:
            path = os.path.join(path, context['id'])
            context['context_path'] = store_context(path, context)
            run_docker_executor(context, pid)
        else:
            context['context_path'] = store_context(path, context)
            run_docker_executor(context)
        insert_process(pid, client, step)
        return pid
    except Exception as ex:
        ex.args = ('do_step_process(%s, %s)' % (client, step),) + ex.args
        raise


def do_download_process(client: str, **kwargs) -> str:
    pid = create_pid(client, 'download')
    logger.info('do_download_process| client=%s' % client)

    # Select an equipment information in database.
    cras_db = CrasStorageDao({**config.CRAS_CONVERT_DB})
    equipments = cras_db.get_equipment_by_id(kwargs['machine'])
    if equipments is None or len(equipments)==0:
        logger.warn(f"do_download_process| invalid equipments (param={kwargs['machine']})")
        return None

    equipment_list = [e['machinename'] for e in equipments]

    try:
        context = {
            'id': pid,
            'client': client,
            'step': 'download',
            'start_date': kwargs['start_date'],
            'end_date': kwargs['end_date'],
            'machine': equipment_list,
            'path': os.path.join(config.CLIENT_ROOT, client),
            'ftp_type': kwargs['ftp_type'],
            'command': kwargs['command'],
            'device': kwargs['device'],
            'process': kwargs['process']
        }

    except KeyError as ex:
        logger.warn('key error occurs. %s' % str(ex))
        StepBadRequest('cannot find key %s from param' % str(ex))

    path = os.path.join(config.CLIENT_ROOT, client, 'download', pid)
    store_context(path, context)

    run_docker_executor(context, ticket_path=pid)
    insert_process(pid, client, 'download')
    return pid


def do_test_scripts_process(client: str, **kwargs) -> str:
    pid = create_pid(client, 'test')
    logger.info('do_download_process| client=%s' % client)

    try:
        context = {
            'id': pid,
            'client': client,
            'step': 'test',
            'path': os.path.join(config.CLIENT_ROOT, client),
        }

    except KeyError as ex:
        logger.warn('key error occurs. %s' % str(ex))
        StepBadRequest('cannot find key %s from param' % str(ex))

    path = os.path.join(config.CLIENT_ROOT, client, 'test', pid)

    # If there are input files in parameter, store them into the path
    if 'files' in kwargs:
        process_path = os.path.join(path)
        if not os.path.exists(process_path):
            create_dir(process_path)
        context['file'] = list()
        for f in kwargs['files']:
            f.save(os.path.join(process_path, f.filename))
            context['file'].append(f.filename)
            logger.info('save file %s' % f.filename)

    # Create json file to pass in docker
    context['context_path'] = store_context(path, context)

    run_docker_executor_with_log(context, ticket_path=pid)
    insert_process(pid, client, 'test')
    return pid


def get_test_output(client, pid):
    logger.trace('get_test_output| client=%s, pid=%s' % (client, pid))

    path = os.path.join(config.CLIENT_ROOT, client, 'test', pid, 'console.log')
    if not os.path.exists(path):
        logger.warn('get_test_output| no output data in %s' % path)
        return ''

    output = open(path, 'r')
    return output.read()


def upload_step_script(client, step, step_file_name, script_zip_files):
    logger.trace('upload_%s_script| client=%s' % (step, client))
    for file in script_zip_files:
        if file.filename == step_file_name:
            path = os.path.join(config.CLIENT_ROOT, client, step, "_script")
            if os.path.exists(path):
                shutil.rmtree(path)
            create_dir(path)
            zip_file_path = os.path.join(path, file.filename)
            file.save(zip_file_path)
            shutil.unpack_archive(zip_file_path, path, "zip")
            os.remove(zip_file_path)


def get_step_script(client, step, position):
    logger.trace('get_step_script| client=%s, step=%s, position=%s' % (client, step, position))
    path = os.path.join(config.CLIENT_ROOT, client, 'script')
    if not os.path.exists(path):
        return list()
    return [os.path.join(path, f) for f in os.listdir(path) if f.startswith('%s_%s_' % (step, position))]


def init_step_process():
    logger.info('init_step_process| initialize step_process table')

    try:
        process_list = list_all_process()
        for p in process_list:
            if not is_finish(p):
                process_dao.update(p['id'], 'halt')
                logger.warn('change the process %s status halted' % p['id'])
    except Exception as ex:
        # Should not raise an exception here.
        # An exception here causes application stop.
        logger.warn(f'init_step_process| failed to initialize step_process. msg={str(ex)}')


def store_context(path, ctx):
    logger.info('store_context(path=%s)' % path)
    if not os.path.exists(path):
        create_dir(path)
    if ctx is None:
        raise RuntimeError('context none')

    context_path = os.path.join(path, 'order.json')
    with open(context_path, 'w') as f:
        f.write(json.dumps(ctx))
    return context_path


def create_pid(client: str, step: str):
    rn = ''.join(random.choices(string.digits + string.ascii_lowercase, k=6))
    pid = '%s-%s' % (step, rn)
    return pid


def run_docker_executor(ctx, ticket_path=None):
    # 【Docker削除によるProcess実行】
    if not config.DOCKER_RUNNER:
        executor = ProcessStepExecutor(ctx['id'], ctx['step'], ctx['path'])
    else:
        executor = DockerStepExecutor(ctx['id'], ctx['step'], ctx['path'])
    if ticket_path is not None:
        executor.set_ticket_path(ticket_path)
    executor.run()


def run_docker_executor_with_log(ctx, ticket_path=None):
    # 【Docker削除によるProcess実行】
    if not config.DOCKER_RUNNER:
        executor = ProcessStepExecutor(ctx['id'], ctx['step'], ctx['path'], output=True)
    else:
        executor = DockerStepExecutor(ctx['id'], ctx['step'], ctx['path'], output=True)
    if ticket_path is not None:
        executor.set_ticket_path(ticket_path)
    executor.run()


def db_exception_decorator(func):
    def _wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except RuntimeWarning as ex:
            logger.warn(f'failed to execute {func.__name__}. msg={str(ex)}')
            raise StepBadRequest(str(ex))
        except RuntimeError as ex:
            logger.error(f'failed to execute {func.__name__}. msg={str(ex)}')
            raise StepServerError(str(ex))
        except Exception as ex:
            ex.args = (func.__name__,) + ex.args
            raise

    return _wrapper


@db_exception_decorator
def is_step_running(client: str, step: str) -> bool:
    process = process_dao.find(client=client, step=step)
    if process is None or len(process) == 0:
        return False
    for p in process:
        if not is_finish(p):
            return True
    return False


@db_exception_decorator
def insert_process(pid: str, client: str, step: str):
    process = process_dao.find(pid=pid)
    if process is not None and len(process) > 0:
        raise StepServerError('process %s already exists' % pid)
    if is_step_running(client, step):
        raise StepBusyStatus('%s/%s busy' % (client, step))
    return process_dao.insert(pid, client, step)


@db_exception_decorator
def list_all_process():
    return process_dao.find()


def is_finish(process: dict) -> bool:
    if process['status'] in ['error', 'success', 'halt', 'nodata']:
        return True
    else:
        return False


def get_download_file_list(process: dict) -> list:
    step_type = get_step_type(process['step'])
    if step_type not in ['cras', 'summary', 'version', 'download', 'rapidDownload']:
        return list()

    path = os.path.join(config.CLIENT_ROOT, process['client'], process['step'], process['id'])
    if not os.path.exists(path):
        raise StepBadRequest('[get_download_file_list] invalid request %s' % path)

    def file_filter(_step_type, _file):
        if _step_type == 'summary' or _step_type == 'cras' or _step_type == 'version':
            return _file.endswith('.html') or _file.endswith('.zip')
        return True

    file_path = [f for f in os.listdir(path) if not f.endswith('.json') and file_filter(step_type, f)]

    return file_path


@db_exception_decorator
def get_status_by_pid(client: str, pid: str) -> dict:
    p_list = process_dao.find(client=client, pid=pid)
    if p_list is None or len(p_list) == 0:
        raise StepBadRequest('invalid client or pid (client=%s, pid=%s)' % (client, pid))
    return p_list[0]


@db_exception_decorator
def get_status_list_by_step(client: str, step: str) -> dict:
    p_list = process_dao.find(client=client, step=step)
    if p_list is None or len(p_list) == 0:
        return list()
    return p_list


@db_exception_decorator
def get_rid_list_by_client(client: str) -> dict:
    p_list = process_dao.find(client=client)
    if p_list is None or len(p_list) == 0:
        return dict()
    return p_list


@db_exception_decorator
def delete_client_in_process(client: str):
    process_dao.delete_by_client(client)


@db_exception_decorator
def delete_log_by_rid(pid: str):
    logger_dao.delete_log_by_id(pid)


@db_exception_decorator
def get_error_list_in_process(pid: str) -> list:
    return logger_dao.get_error_log_by_id(pid)
