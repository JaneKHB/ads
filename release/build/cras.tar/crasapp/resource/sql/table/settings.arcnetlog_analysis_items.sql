create table settings.arcnetlog_analysis_items
(
    target                  boolean,
    no                      integer      not null,
    name                    varchar(128) not null,
    unit                    varchar(8)   not null,
    start_condition_command varchar(32),
    start_condition_io      varchar(32),
    start_command           varchar(32),
    start_io                varchar(32),
    end_command             varchar(32),
    end_io                  varchar(32),
    cancel_command          varchar(32),
    cancel_io               varchar(32),
    primary key (no, name, unit)
);