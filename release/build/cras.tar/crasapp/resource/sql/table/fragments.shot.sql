create table fragments.shot
(
    shot_key            varchar(128)             not null
        primary key,
    glass_id            varchar(32)              not null,
    datetime_shot       timestamp with time zone not null,
    shot_no             integer                  not null,
    errorjudgement_shot boolean                  not null,
    errorfactor_id      integer,
    errorfactor_names   varchar(128),
    imagefilter_id      integer,
    imagefilter_name    varchar(128),
    plate_key           varchar(128)             not null,
    datetime_shot_error timestamp with time zone
);

create index shot_shot_key_219c79d6_like
    on fragments.shot (shot_key varchar_pattern_ops);