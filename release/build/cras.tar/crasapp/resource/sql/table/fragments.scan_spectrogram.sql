create table fragments.scan_spectrogram
(
    spectrogram_path varchar(256)             not null
        primary key,
    datetime_scan    timestamp with time zone not null,
    index_num        integer                  not null,
    errorjudgement   boolean                  not null,
    shot_key         varchar(128)             not null
);

create index scan_spectrogram_spectrogram_path_2f39b651_like
    on fragments.scan_spectrogram (spectrogram_path varchar_pattern_ops);