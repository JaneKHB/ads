create table fragments.image
(
    bmp_path          varchar(256)             not null
        primary key,
    raw_path          varchar(256),
    jpeg_path         varchar(256)             not null,
    datetime_image    timestamp with time zone not null,
    scope             varchar(16)              not null,
    position          varchar(16)              not null,
    l_or_r            varchar(16)              not null,
    average_num       integer                  not null,
    errorjudgement    boolean                  not null,
    errorfactor_names varchar(128),
    errorbefore_num   integer,
    parameter_path    varchar(256),
    shot_key          varchar(128)             not null
);

create index image_bmp_path_297c3dc9_like
    on fragments.image (bmp_path varchar_pattern_ops);