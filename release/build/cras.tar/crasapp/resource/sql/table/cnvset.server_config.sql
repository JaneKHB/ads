create table cnvset.server_config
(
    key   varchar(50)                                not null
        constraint server_config_pk
            primary key,
    value varchar(255) default ''::character varying not null
);