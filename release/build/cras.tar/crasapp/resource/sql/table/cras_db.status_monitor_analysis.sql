create table cras_db.status_monitor_analysis
(
    equipment_id text not null,
    event          text not null,
    start_time     timestamp(6) not null,
    end_time       timestamp(6) not null,
    elapsed        double precision,
    device         text,
    process        text,
    lot_id         text,
    plate_id       text,
    plate_no       integer,
    constraint status_monitor_analysis_pkey primary key (equipment_id, event, start_time),
    foreign key(equipment_id) references cras_db.equipments(equipment_id) on delete cascade
);

