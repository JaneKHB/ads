create table settings.arcnetlog_last_exec_time
(
    user_name      varchar(32) not null,
    fab            varchar(32) not null,
    last_exec_time varchar(32),
    primary key (user_name, fab)
);