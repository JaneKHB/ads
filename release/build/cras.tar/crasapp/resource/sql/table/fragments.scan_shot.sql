create table fragments.scan_shot
(
    shot_key            varchar(128)             not null
        primary key,
    glass_id            varchar(32)              not null,
    datetime_shot       timestamp with time zone not null,
    shot_no             integer                  not null,
    errorjudgement_shot boolean                  not null,
    fdacq_flag_shot     boolean                  not null,
    plate_key           varchar(128)             not null
);

create index scan_shot_shot_key_de09ba5d_like
    on fragments.scan_shot (shot_key varchar_pattern_ops);