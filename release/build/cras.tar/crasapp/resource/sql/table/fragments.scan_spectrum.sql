create table fragments.scan_spectrum
(
    spectrum_path  varchar(256)             not null
        primary key,
    datetime_scan  timestamp with time zone not null,
    errorjudgement boolean                  not null,
    shot_key       varchar(128)             not null
);

create index scan_spectrum_spectrum_path_77b29fa6_like
    on fragments.scan_spectrum (spectrum_path varchar_pattern_ops);