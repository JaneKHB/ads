create table cras_db.error_summary
(
    equipment_id text       not null,
    log_date       date       not null,
    error_no       text not null,
    error_name     text,
    elapsed        time default '00:00:00'::time without time zone,
    error_rank     text,
    error_count    integer,
    error_category text,
    constraint error_summary_pkey   primary key (equipment_id, log_date, error_no),
    foreign key(equipment_id) references cras_db.equipments(equipment_id) on delete cascade
);