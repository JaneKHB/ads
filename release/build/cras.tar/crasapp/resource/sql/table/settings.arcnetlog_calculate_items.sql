create table settings.arcnetlog_calculate_items
(
    calculate_name text,
    items          text
);