create table cras_db.equipments
(
    machineName     text,
    fab_name        text,
    tool_serial     text,
    toolType        text,
    tool_id         text,
    inner_tool_id   text,
    user_name       text,
    equipment_name  text,
    equipment_id    text not null constraint equipments_pkey primary key
);