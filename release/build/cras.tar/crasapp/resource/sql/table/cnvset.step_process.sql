create table cnvset.step_process
(
    id      varchar(50)                                      not null
        constraint step_process_pk
            primary key,
    created timestamp   default now()                        not null,
    step    varchar(20)                                      not null,
    client  varchar(50)                                      not null,
    status  varchar(20) default 'unknown'::character varying not null
);

create unique index step_process_id_uindex
    on cnvset.step_process (id);
