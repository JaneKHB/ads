create table fragments.mpsync_error_collected
(
    unique_key     varchar(256)             not null
        primary key,
    equipment_name varchar(128)             not null,
    step           integer,
    glass_id       varchar(128)             not null,
    log_time       timestamp with time zone not null,
    parameter_name varchar(128)             not null,
    tolerance      integer,
    parameter_num  integer,
    is_collected   boolean
);

create index mpsync_error_collected_unique_key_a6730247_like
    on fragments.mpsync_error_collected (unique_key varchar_pattern_ops);