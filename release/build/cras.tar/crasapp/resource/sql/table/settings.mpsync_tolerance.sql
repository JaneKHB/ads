create table settings.mpsync_tolerance
(
    equipment_type varchar(32),
    parameter_name varchar(128),
    detail         varchar(128),
    tolerance      integer
);