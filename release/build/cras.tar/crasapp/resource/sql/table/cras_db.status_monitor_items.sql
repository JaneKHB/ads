create table cras_db.status_monitor_items
(
    name        text,
    start_state text,
    end_state   text
);