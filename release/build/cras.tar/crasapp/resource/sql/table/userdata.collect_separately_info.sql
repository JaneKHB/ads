create table userdata.collect_separately_info
(
    equipment_name                      varchar(64) not null
        primary key,
    iscollect_ai                        boolean,
    iscollect_liplus                    boolean,
    iscollect_scan                      boolean,
    ai_collected_time                   varchar(64),
    liplus_normallog_collected_time     varchar(64),
    liplus_process_collected_time       varchar(64),
    liplus_focuslog_collected_time      varchar(64),
    liplus_statusmonitor_collected_time varchar(64),
    liplus_cras_collected_time          varchar(64),
    liplus_error_summary_collected_time varchar(64),
    liplus_running_rate_collected_time  varchar(64),
    scan_collected_time                 varchar(64),
    scan_cog_collected_time             varchar(64),
    scan_mpsync_collected_time          varchar(64),
    iscollect_arcnetlog                 boolean,
    arcnetlog_collected_time            varchar(64),
    arcnetlog_analysis_time             varchar(64),
    liplus_vftp_collected_time          varchar(64),
    iscollect_liftbarvac                boolean     default false,
    liftbarvac_collected_time           varchar(64) default '2021-12-01 00:00:00'::character varying,
    liftbarvac_last_analysis_logtime    varchar(64) default '2021-12-01 00:00:00.0000'::character varying
);