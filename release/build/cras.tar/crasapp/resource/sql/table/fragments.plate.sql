create table fragments.plate
(
    plate_key            varchar(128)             not null
        primary key,
    user_fab             varchar(32)              not null,
    equipment_name       varchar(128)             not null,
    mark_type            varchar(32)              not null,
    datetime_plate       timestamp with time zone not null,
    glass_id             varchar(32)              not null,
    plate_no             integer                  not null,
    job_name             varchar(128),
    errorjudgement_plate boolean                  not null,
    equipment_key        varchar(128)             not null
);