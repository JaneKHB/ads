create table settings.mahalanobis_distance
(
    log_time       timestamp   not null,
    equipment_name varchar(32) not null,
    item           varchar(64) not null,
    distance       real,
    primary key (log_time, equipment_name, item)
);