create table fragments.scan_plate
(
    plate_key            varchar(128)             not null
        primary key,
    user_fab             varchar(32)              not null,
    equipment_name       varchar(128)             not null,
    datetime_plate       timestamp with time zone not null,
    glass_id             varchar(32)              not null,
    plate_no             integer                  not null,
    job_name             varchar(128),
    errorjudgement_plate boolean                  not null,
    fdacq_flag_plate     boolean                  not null,
    equipment_key        varchar(128)             not null,
    normal_flag_plate    boolean                  not null
);

create index scan_plate_plate_key_5e2984fd_like
    on fragments.scan_plate (plate_key varchar_pattern_ops);