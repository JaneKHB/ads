create table settings.mahalanobis_settings
(
    id             serial
        constraint mahalanobis_pkey
            primary key,
    equipment_name varchar(32) not null,
    table_name     varchar(64) not null,
    item           varchar(64) not null,
    colname1       varchar(64) not null,
    colname2       varchar(64) not null,
    covariance     real        not null,
    mean1          real        not null,
    mean2          real        not null,
    variance1      real        not null,
    variance2      real        not null,
    last_exec_time timestamp default '2018-01-01 00:00:00'::timestamp without time zone,
    constraint cras_unique
        unique (equipment_name, item)
);