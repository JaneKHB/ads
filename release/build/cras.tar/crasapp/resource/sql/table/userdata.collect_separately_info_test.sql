create table userdata.collect_separately_info_test
(
    equipment_name                      varchar(128),
    iscollect_ai                        boolean,
    iscollect_liplus                    boolean,
    iscollect_scan                      boolean,
    ai_collected_time                   varchar(128),
    liplus_normallog_collected_time     varchar(128),
    liplus_process_collected_time       varchar(128),
    liplus_focuslog_collected_time      varchar(128),
    liplus_statusmonitor_collected_time varchar(128),
    liplus_cras_collected_time          varchar(128),
    liplus_error_summary_collected_time varchar(128),
    liplus_running_rate_collected_time  varchar(128),
    scan_collected_time                 varchar(128),
    scan_cog_collected_time             varchar(128),
    scan_mpsync_collected_time          varchar(128),
    scan_before_job                     varchar(128),
    scan_before_job_lack                integer,
    iscollect_arcnetlog                 boolean,
    arcnetlog_collected_time            varchar(128),
    arcnetlog_analysis_time             varchar(128),
    arcnetlog_collected_limited_day     varchar(128)
);