import argparse
import os
import json
import sys
import shutil
from pathlib import Path

import env
import extlogger
from stage.collect_stage import CollectStage
from stage.convert_stage import ConvertStage
from stage.cras_stage import CrasStage
from stage.download_stage import DownloadStage
from stage.purge_stage import PurgeStage
from stage.rapid_download_stage import RapidDownloadStage
from stage.rapid_search_stage import RapidSearchStage
from stage.summary_stage import SummaryStage
from stage.test_stage import TestStage
from stage.version_stage import VersionStage
from stage.custom_stage import CustomStage


def get_context(step=None, ticket=None):
    if ticket is None:
        context_path = os.path.join(env.PRIV_PATH, step, env.CONTEXT_FILE_NAME)
    else:
        context_path = os.path.join(env.PRIV_PATH, step, ticket, env.CONTEXT_FILE_NAME)
    if not os.path.exists(context_path):
        raise RuntimeError('##[steprunner] cannot find a context file in %s' % context_path)
    ctx = open(context_path, 'r').read()
    return json.loads(ctx)


def run(step=None, ticket=None):
    print('##[steprunner] process application launched', sys.argv)

    env.init()

    print('##[steprunner] env.PRIV_PATH ', env.PRIV_PATH)
    print('##[steprunner] env.USER_PATH ', env.USER_PATH)
    print('##[steprunner] env.STORAGE_FILE ', env.STORAGE_FILE)

    if step is None:
        print('##[steprunner] unknown step error : exit(1)')
        exit(1)

    if not os.path.exists(env.PRIV_PATH):
        print('##[steprunner] cannot find private directory : exit(1)')
        exit(1)

    ctx = get_context(step, ticket)

    print('##[steprunner] context=', ctx)
    step_type = ctx['step'].split('_')[0]
    # Initialize a debugging logger
    extlogger.init_logger('cont', step_type)
    extlogger.gger.set_default_key(ctx['id'])

    if step_type == 'collect':
        service = CollectStage(ctx)
    elif step_type == 'convert':
        service = ConvertStage(ctx)
    elif step_type == 'summary':
        service = SummaryStage(ctx)
    elif step_type == 'cras':
        service = CrasStage(ctx)
    elif step_type == 'version':
        service = VersionStage(ctx)
    elif step_type == 'purge':
        service = PurgeStage(ctx)
    elif step_type == 'download':
        service = DownloadStage(ctx)
    elif step_type == 'custom':
        service = CustomStage(ctx)
    elif step_type == 'test':
        if ticket is not None:
            pid = ticket
            service = TestStage(ctx, pid)
        else:
            extlogger.gger.error('pid is missing.')
    elif ctx['step'] == 'rapidSearch':
        service = RapidSearchStage(ctx)
    elif ctx['step'] == 'rapidDownload':
        service = RapidDownloadStage(ctx)
    else:
        extlogger.gger.error('##[steprunner] cannot find proper service process for %s' % ctx['step'])
        exit(1)

    service.start()


if __name__ == '__main__':
    # 【Docker削除によるProcess実行】
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", "--step", help="")
    parser.add_argument("-t", "--ticket", help="")
    parser.add_argument("-p", "--priv", help="")
    args = parser.parse_args()

    env.PRIV_PATH = args.priv
    env.USER_PATH = args.priv + '/usr'
    env.STORAGE_FILE = args.priv + '/usr/__storage/storage.json'
    run(args.step, args.ticket)

    print("##[steprunner] end")
