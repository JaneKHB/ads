import os
import sys
import ssl
import flaskapp.cras_server


BASE_DIR = os.path.dirname(os.path.abspath(__file__)) + os.path.sep
sys.path.append(BASE_DIR)
os.chdir(BASE_DIR)

app = flaskapp.cras_server.create_app()
#app.run(threaded=True)

if __name__ == '__main__':
  print("main")    
#    # ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS)
#    # ssl_context.load_cert_chain(certfile='domain.crt', keyfile='domain.key', password='1234')
#    # app.run(threaded=True, host="0.0.0.0", port=443, ssl_context=ssl_context)

