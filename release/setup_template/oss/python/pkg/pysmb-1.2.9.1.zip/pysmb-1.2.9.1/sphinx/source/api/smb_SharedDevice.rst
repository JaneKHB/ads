
SharedDevice Class
==================

.. autoclass:: smb.base.SharedDevice
    :members:
