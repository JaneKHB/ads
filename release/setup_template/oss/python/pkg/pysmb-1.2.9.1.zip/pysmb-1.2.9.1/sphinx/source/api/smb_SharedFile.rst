
SharedFile Class
================

.. autoclass:: smb.base.SharedFile
    :members:
